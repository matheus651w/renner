
	<footer>
		<div class="container">
			<p>Versão 1.0</p>
			<p>MAFIA tropa do mister Lara <?php echo date('Y'); ?></p>
		</div>
	</footer>
